import { Routes } from '@angular/router';
import { AppGuardService } from '@modules/guards/app.guard.service';
import { LayoutMain } from '@modules/navigation/layouts/layout-main/layout-main';

export const routes: Routes = [
    {
        path: '',
        component: LayoutMain,
        canActivate: [AppGuardService],
        canLoad: [AppGuardService],
        children: [
            {
                path: 'home',
                loadChildren: () => import("@modules/dashboard/dashboard-routes.module"),
            },
            {
                path: 'management',
                loadChildren: () => import("@modules/management/management-routes.module"),
            },
            {
                // path: 'management',
                // loadChildren: () => import("@modules/management/management-routes.module"),
            }
        ]
    },
    {
        path: 'auth',
        loadChildren: () => import("@modules/auth/auth-routes.module"),
    }
];
