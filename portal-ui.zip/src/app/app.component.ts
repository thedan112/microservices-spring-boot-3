import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterOutlet } from '@angular/router';
import { InputTextModule } from 'primeng/inputtext';
import { MessageModule } from 'primeng/message';
import { CommonModule } from '@angular/common';
import { ConfirmationService, MessageService } from 'primeng/api';
import { CookieService } from 'ngx-cookie-service';
import { JwtHelperService, JWT_OPTIONS } from '@auth0/angular-jwt';
import { ToastModule } from 'primeng/toast';
import { ToastService } from '@modules/common/services/toast.service';
import { LocalStorageService } from '@modules/common/services/app.local-storage.service';
import { CommonUserService } from '@modules/common/services/app.user.service';

@Component({
  selector: 'app-root',
  standalone: true,
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss',
  imports: [
    CommonModule,
    RouterOutlet,
    InputTextModule,
    MessageModule,
    FormsModule,
    ToastModule,
  ],
  providers: [MessageService, CookieService, ToastService, ConfirmationService, LocalStorageService, CommonUserService,
    { provide: JWT_OPTIONS, useValue: JWT_OPTIONS }, JwtHelperService],
})
export class App {
  title = 'Portal';
}
