import { Routes } from '@angular/router';
import { RoleManagementContainer } from './users/containers/users/role-management.component';
import { UserManagementContainer } from './users/containers/users/user-management.component';

export default [
    { path: 'users', title: 'Users Management', component: UserManagementContainer },
    { path: 'roles', component: RoleManagementContainer },
    { path: 'departments', component: RoleManagementContainer },
    { path: '**', redirectTo: '/notfound' }
] as Routes;