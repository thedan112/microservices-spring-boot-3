import { Component, OnInit } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { IPagedModel, PagedModel } from "@modules/common/models/page.model";
import { ToastService } from "@modules/common/services/toast.service";
import { lastValueFrom } from "rxjs";
import { AppCommonModule } from "@modules/common/app.common.module";
import { UserCreateRequest } from "../../models/user-create-request.model";
import { RoleLstComponent } from "../../components/role-lst.component";
import { RoleEditComponent } from "../../components/role-edit.component";
import { RoleCreateComponent } from "../../components/role-create.component";
import { ApiRoleService } from "../../services/api.role.service";
import { RoleResponse } from "../../models/role-response.model";

@Component({
    selector: 'app-role-management',
    templateUrl: './role-management.component.html',
    styleUrls: ['./role-management.component.scss'],
    imports: [RoleLstComponent, RoleCreateComponent, RoleEditComponent, AppCommonModule],
    providers: [ApiRoleService],
})
export class RoleManagementContainer implements OnInit {
    display: boolean = false;
    isCreateDialog: boolean = false;
    isDetailDialog: boolean = false;
    loading: boolean = false;
    page: number = 0;
    size: number = 10;
    totalRecords: number = 0;
    searchForm!: FormGroup;
    createForm!: FormGroup;
    detailForm!: FormGroup;
    pagedData: IPagedModel<RoleResponse> = new PagedModel();
    roleDetail: RoleResponse = new RoleResponse();
    filter!: string;

    column: any[] = [
        { field: 'name', header: 'Name', dataType: 'text' },
        { field: 'createdBy', header: 'Created By', dataType: 'text' },
        { field: 'createdDate', header: 'Created Date', dataType: 'datetime' },
        { field: 'active', header: 'Active', dataType: 'status' },
        { field: 'id', header: 'Action', dataType: 'action' },
    ];

    constructor(private fb: FormBuilder,
        private toast: ToastService,
        private api: ApiRoleService) { }

    ngOnInit(): void {
        this.formBuilderSearch();
        this.formBuilderCreate();
        this.formBuilderDetail();
        this.loadData();
    }

    formBuilderSearch() {
        this.searchForm = this.fb.group({ name: [null] })
    }

    formBuilderCreate() {
        this.createForm = this.fb.group({
            name: [null, Validators.required],
        });
    }

    formBuilderDetail() {
        this.detailForm = this.fb.group({
            id: [null, Validators.required],
            name: [null, Validators.required],
            createdBy: [null],
            createdDate: [null]
        });
    }

    onSearch(event: string) {
        this.page = 0;
        this.size = 10;
        this.filter = event;
        this.loadData();
    }

    async loadData() {
        this.loading = true;
        let res = await lastValueFrom(this.api.pages(this.page, this.size, this.filter));
        if (res.status == '000' && res.data) {
            this.pagedData = res.data;
        } else {
            this.toast.error('Thất bại', res.message);
        }
        this.loading = false;
    }

    async loadDetail(id: any) { 
        this.loading = true;
        let res = await lastValueFrom(this.api.detail(id));
        if (res.status == '000' && res.data) {
            this.roleDetail = res.data;
        } else {
            this.toast.error('Thất bại', res.message);
        }
        this.loading = false;
    }

    onVisibleCreate(event: boolean) {
        if (event) { this.formBuilderCreate(); }
        this.isCreateDialog = event;
    }

    onVisibleDetail(event: {id: string, visible: boolean}) {
        if (event.visible) { 
            this.formBuilderDetail();
            this.loadDetail(event.id);
        }
        this.isDetailDialog = event.visible;
    }

    async onCreate(model: UserCreateRequest) {
        this.loading = true;
        let res = await lastValueFrom(this.api.create(model));
        if (res.status == '000') {
            this.onVisibleCreate(false);
            this.loadData();
            this.toast.success('Thành công');
        } else {
            this.toast.error('Thất bại', res.message);
        }
        this.loading = false;
    }

    onUpdate(model: any) { }

    onPageChange($event: any): void {
        this.page = $event.page;
        this.size = $event.rows;
        this.loadData();
    }
}