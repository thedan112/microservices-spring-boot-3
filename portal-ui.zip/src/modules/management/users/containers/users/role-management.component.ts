import { Component, OnInit } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { IPagedModel, PagedModel } from "@modules/common/models/page.model";
import { ApiUserService } from "../../services/api.user.service";
import { UserResponse } from "../../models/user-response.model";
import { ToastService } from "@modules/common/services/toast.service";
import { lastValueFrom } from "rxjs";
import { ManagementModule } from "@modules/management/management.module";
import { RoleLstComponent } from "../../components/role-lst.component";

@Component({
    selector: 'app-role-management',
    templateUrl: './role-management.component.html',
    styleUrls: ['./role-management.component.scss'],
    imports: [ManagementModule, RoleLstComponent],
    providers: [ApiUserService],
})
export class RoleManagementContainer implements OnInit {
    display: boolean = false;
    isCreateForm: boolean = false;
    isEditForm: boolean = false;
    loading: boolean = false;
    page: number = 0;
    size: number = 10;
    totalRecords: number = 0;
    searchForm!: FormGroup;
    createForm!: FormGroup;
    editForm!: FormGroup;
    pagedData: IPagedModel<UserResponse> = new PagedModel();
    email!: string;

    column: any[] = [
        { field: 'code', header: 'Username', dataType: 'text' },
        { field: 'name', header: 'Email', dataType: 'text' },
        { field: 'description', header: 'Full name', dataType: 'text' },
        { field: 'active', header: 'Active', dataType: 'active' },
        { field: 'id', header: 'Action', dataType: 'action' },
    ];

    constructor(private fb: FormBuilder,
        private toast: ToastService,
        private api: ApiUserService) { }

    ngOnInit(): void {
        this.formBuilder();
        this.loadData();
    }

    formBuilder() {
        this.searchForm = this.fb.group({
            code: ['', Validators.required],
            name: ['', Validators.required],
            id: [null, Validators.required],
        });

        this.createForm = this.fb.group({
            code: ['', Validators.required],
            name: ['', Validators.required],
            description: ['', Validators.required],
            id: [null, Validators.required],
        });
    }

    onSearch(event: string) {
        this.page = 0;
        this.size = 10;
        this.email = event;
        this.loadData();
    }

    async loadData() {
        this.loading = true;
        let res = await lastValueFrom(this.api.pages(this.page, this.size, this.email));
        if (res.status == '000' && res.data) {
            this.pagedData = res.data;
        } else {
            this.toast.error('Thất bại', res.message);
        }
        this.loading = false;
    }

    loadDetail(id: string) { }
    create(model: any) { }
    update(model: any) { }

    onPageChange($event: any): void {
        this.page = $event.page;
        this.size = $event.rows;
        this.loadData();
    }
}