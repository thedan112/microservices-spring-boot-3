import { Component, OnInit } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { IPagedModel, PagedModel } from "@modules/common/models/page.model";
import { UserCreateComponent } from "../../components/user-create.component";
import { UserEditComponent } from "../../components/user-edit.component";
import { UserLstComponent } from "../../components/user-lst.component";
import { ApiUserService } from "../../services/api.user.service";
import { UserResponse } from "../../models/user-response.model";
import { ToastService } from "@modules/common/services/toast.service";
import { lastValueFrom } from "rxjs";
import { AppCommonModule } from "@modules/common/app.common.module";
import { UserCreateRequest } from "../../models/user-create-request.model";

@Component({
    selector: 'app-user-management',
    templateUrl: './user-management.component.html',
    styleUrls: ['./user-management.component.scss'],
    imports: [UserLstComponent, UserEditComponent, UserCreateComponent, AppCommonModule],
    providers: [ApiUserService],
})
export class UserManagementContainer implements OnInit {
    display: boolean = false;
    isCreateDialog: boolean = false;
    isDetailDialog: boolean = false;
    loading: boolean = false;
    page: number = 0;
    size: number = 10;
    totalRecords: number = 0;
    searchForm!: FormGroup;
    createForm!: FormGroup;
    detailForm!: FormGroup;
    pagedData: IPagedModel<UserResponse> = new PagedModel();
    userDetail: UserResponse = new UserResponse();
    filter!: string;

    column: any[] = [
        { field: 'username', header: 'Username', dataType: 'text' },
        { field: 'email', header: 'Email', dataType: 'text' },
        { field: 'fullName', header: 'Full name', dataType: 'text' },
        { field: 'department', header: 'Department', dataType: 'text' },
        { field: 'active', header: 'Active', dataType: 'active' },
        { field: 'locked', header: 'Locked', dataType: 'locked' },
        { field: 'id', header: 'Action', dataType: 'action' },
    ];

    constructor(private fb: FormBuilder,
        private toast: ToastService,
        private api: ApiUserService) { }

    ngOnInit(): void {
        this.formBuilderSearch();
        this.formBuilderCreate();
        this.formBuilderDetail();
        this.loadData();
    }

    formBuilderSearch() {
        this.searchForm = this.fb.group({ email: [null] })
    }

    formBuilderCreate() {
        this.createForm = this.fb.group({
            username: [null, Validators.required],
            fullName: [null, Validators.required],
            email: [null, Validators.required],
            employeeCode: [null, Validators.required],
            departmentId: [null, Validators.required],
            type: [null, Validators.required]
        });
    }

    formBuilderDetail() {
        this.detailForm = this.fb.group({
            id: [null, Validators.required],
            username: [null, Validators.required],
            fullName: [null, Validators.required],
            email: [null, Validators.required],
            employeeCode: [null, Validators.required],
            departmentId: [null, Validators.required],
            type: [null, Validators.required],
            createdBy: [null],
            createdDate: [null]
        });
    }

    onSearch(event: string) {
        this.page = 0;
        this.size = 10;
        this.filter = event;
        this.loadData();
    }

    async loadData() {
        this.loading = true;
        let res = await lastValueFrom(this.api.pages(this.page, this.size, this.filter));
        if (res.status == '000' && res.data) {
            this.pagedData = res.data;
        } else {
            this.toast.error('Thất bại', res.message);
        }
        this.loading = false;
    }

    onDetail(id: any) { }

    onVisibleCreate(event: boolean) {
        if (event) { this.formBuilderCreate(); }
        this.isCreateDialog = event;
    }

    onVisibleDetail(event: {model: UserResponse, visible: boolean}) {
        if (event.visible) { 
            this.formBuilderDetail();
            this.userDetail = event.model;
        }
        this.isDetailDialog = event.visible;
    }

    async onCreate(model: UserCreateRequest) {
        this.loading = true;
        let res = await lastValueFrom(this.api.create(model));
        if (res.status == '000') {
            this.onVisibleCreate(false);
            this.loadData();
            this.toast.success('Thành công');
        } else {
            this.toast.error('Thất bại', res.message);
        }
        this.loading = false;
    }

    onUpdate(model: any) { }

    onPageChange($event: any): void {
        this.page = $event.page;
        this.size = $event.rows;
        this.loadData();
    }
}