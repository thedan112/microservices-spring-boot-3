import { Component, OnInit } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { IPagedModel, PagedModel } from "@modules/common/models/page.model";
import { UserCreateComponent } from "../../components/user-create.component";
import { UserEditComponent } from "../../components/user-edit.component";
import { UserLstComponent } from "../../components/user-lst.component";
import { ApiUserService } from "../../services/api.user.service";
import { ManagementModule } from "@modules/management/management.module";
import { UserResponse } from "../../models/user-response.model";
import { ToastService } from "@modules/common/services/toast.service";
import { lastValueFrom } from "rxjs";

@Component({
    selector: 'app-user-management',
    templateUrl: './user-management.component.html',
    styleUrls: ['./user-management.component.scss'],
    imports: [UserLstComponent, UserEditComponent, UserCreateComponent, ManagementModule],
    providers: [ApiUserService],
})
export class UserManagementContainer implements OnInit {
    display: boolean = false;
    isCreateForm: boolean = false;
    isEditForm: boolean = false;
    loading: boolean = false;
    page: number = 0;
    size: number = 10;
    totalRecords: number = 0;
    searchForm!: FormGroup;
    createForm!: FormGroup;
    editForm!: FormGroup;
    pagedData: IPagedModel<UserResponse> = new PagedModel();
    email!: string;

    column: any[] = [
        { field: 'username', header: 'Username', dataType: 'text' },
        { field: 'email', header: 'Email', dataType: 'text' },
        { field: 'fullName', header: 'Full name', dataType: 'text' },
        { field: 'department', header: 'Department', dataType: 'text' },
        { field: 'active', header: 'Active', dataType: 'active' },
        { field: 'locked', header: 'Locked', dataType: 'locked' },
        { field: 'id', header: 'Action', dataType: 'action' },
    ];

    constructor(private fb: FormBuilder,
        private toast: ToastService,
        private api: ApiUserService) { }

    ngOnInit(): void {
        this.formBuilder();
        this.loadData();
    }

    formBuilder() {
        this.searchForm = this.fb.group({ email: ['', Validators.required] })

        this.createForm = this.fb.group({
            username: ['', Validators.required],
            password: ['', Validators.required],
            email: ['', Validators.required],
            employeeCode: ['', Validators.required],
            departmentId: [null, Validators.required],
            type: ['', Validators.required]
        });
    }

    onSearch(event: string) {
        this.page = 0;
        this.size = 10;
        this.email = event;
        this.loadData();
    }

    async loadData() {
        this.loading = true;
        let res = await lastValueFrom(this.api.pages(this.page, this.size, this.email));
        if (res.status == '000' && res.data) {
            this.pagedData = res.data;
        } else {
            this.toast.error('Thất bại', res.message);
        }
        this.loading = false;
    }

    loadDetail(id: string) { }
    create(model: any) { }
    update(model: any) { }

    onPageChange($event: any): void {
        this.page = $event.page;
        this.size = $event.rows;
        this.loadData();
    }
}