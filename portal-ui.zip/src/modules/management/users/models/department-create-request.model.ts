export class DepartmentCreateRequest {
    id?: string;
    name?: string;
    description?: string;
    roleIds?: Array<string>;
}