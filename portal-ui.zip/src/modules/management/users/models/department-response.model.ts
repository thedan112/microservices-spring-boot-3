export class DepartmentResponse {
    id?: string;
    name?: string;
    description?: string;
    createdBy?: string;
    createdDate?: Date;
}