export class DepartmentUpdateRequest {
    id?: string;
    name?: string;
    description?: string;
    roleIds?: Array<string>;
}