export class RoleUpdateRequest {
    id?: string;
    name?: string;
}