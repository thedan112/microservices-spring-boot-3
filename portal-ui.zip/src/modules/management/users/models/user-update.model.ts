export class UserUpdateRequest {
    id?: string;
    username?: string;
    email?: string;
    fullName?: string;
    department?: string;
    createdBy?: string;
    createdDate?: Date;
}