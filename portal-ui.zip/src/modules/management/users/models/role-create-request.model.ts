export class RoleCreateRequest {
    name?: string;
}