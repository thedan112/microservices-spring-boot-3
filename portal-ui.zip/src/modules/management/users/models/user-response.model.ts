export class UserResponse {
    id?: number;
    username?: string;
    email?: string;
    fullName?: string;
    department?: string;
    active?: boolean;
    locked?: boolean;

}