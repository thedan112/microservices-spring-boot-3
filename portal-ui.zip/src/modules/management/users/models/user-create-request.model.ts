export class UserCreateRq {
    
}