export class UserCreateRequest {
    
    email?: string;
    username?: string;
    fullName?: string;
    employeeCode?: string;
    departmentId?: string;
    type?: string;
}