import { Component, EventEmitter, Input, OnInit, Output } from "@angular/core";
import { FormGroup } from "@angular/forms";
import { AppCommonModule } from "@modules/common/app.common.module";
import { ToastService } from "@modules/common/services/toast.service";
import { UserCreateRequest } from "../models/user-create-request.model";

@Component({
    selector: 'app-user-create',
    templateUrl: './user-create.component.html',
    styleUrls: ['./user-create.component.scss'],
    imports: [AppCommonModule],
})
export class UserCreateComponent implements OnInit {
    @Input() isCreate!: boolean;
    @Input() createForm!: FormGroup;
    @Output() hidden = new EventEmitter<boolean>();
    @Output() submitCreate = new EventEmitter<any>();
    type: any[]  = [
        { label: 'USER', value: 'USER'},
        { label: 'ADMIN', value: 'ADMIN'}
    ];

    department: any[]  = [
        { label: 'CARDOPS', value: 'CARDOPS'},
    ];

    constructor(private toast: ToastService) { }

    ngOnInit(): void {
    }

    onHidden() { this.hidden.emit(false); }

    onSave() {
        if (this.createForm.valid) {
            let model = { ...this.createForm.value } as UserCreateRequest;
            this.submitCreate.emit(model);
        }
    }
}