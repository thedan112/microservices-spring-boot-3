import { Component, EventEmitter, Input, OnInit, Output } from "@angular/core";
import { FormGroup } from "@angular/forms";
import { AppCommonModule } from "@modules/common/app.common.module";
import { ToastService } from "@modules/common/services/toast.service";
import { PaginatorState } from "primeng/paginator";

@Component({
    selector: 'app-department-lst',
    templateUrl: './department-lst.component.html',
    styleUrls: ['./department-lst.component.scss'],
    imports: [AppCommonModule],
})
export class DepartmentLstComponent implements OnInit {
    @Input() colData?: any[];
    @Input() content!: any[];
    @Input() currPage!: number;
    @Input() totalPages!: number;
    @Input() totalElements!: number;
    @Input() rows!: number;
    @Input() numberOfElements?: number;
    @Input() searchForm!: FormGroup;
    @Output() search = new EventEmitter<string>();
    @Output() pageChange = new EventEmitter<PaginatorState>();
    @Output() create = new EventEmitter<boolean>();
    @Output() detail = new EventEmitter<{ id: string, visible: boolean }>();

    constructor(private toast: ToastService) { }

    ngOnInit(): void { }

    onCreate() {
        this.create.emit(true);
    }

    onDetail(id: string) {
        this.detail.emit({ id: id, visible: true });
    }

    onSearch() {
        let email = this.searchForm.value.email;
        this.search.emit(email);
    }

    onPageChange(event: PaginatorState) {
        this.pageChange.emit(event);
    }
}