import { Component, EventEmitter, Input, OnInit, Output } from "@angular/core";
import { FormGroup } from "@angular/forms";
import { AppCommonModule } from "@modules/common/app.common.module";
import { ToastService } from "@modules/common/services/toast.service";
import { RoleCreateRequest } from "../models/role-create-request.model";

@Component({
    selector: 'app-department-create',
    templateUrl: './department-create.component.html',
    styleUrls: ['./department-create.component.scss'],
    imports: [AppCommonModule],
})
export class DepartmentCreateComponent implements OnInit {
    @Input() isCreate!: boolean;
    @Input() createForm!: FormGroup;
    @Output() hidden = new EventEmitter<boolean>();
    @Output() submitCreate = new EventEmitter<any>();

    constructor(private toast: ToastService) { }

    ngOnInit(): void {}

    onHidden() { this.hidden.emit(false); }

    onSave() {
        if (this.createForm.valid) {
            let model = { ...this.createForm.value } as RoleCreateRequest;
            this.submitCreate.emit(model);
        }
    }
}