import { Component, EventEmitter, Input, OnInit, Output } from "@angular/core";
import { FormGroup } from "@angular/forms";
import { ToastService } from "@modules/common/services/toast.service";
import { ManagementModule } from "@modules/management/management.module";
import { PaginatorState } from "primeng/paginator";

@Component({
    selector: 'app-user-lst',
    templateUrl: './user-lst.component.html',
    styleUrls: ['./user-lst.component.scss'],
    imports: [ManagementModule],
})
export class UserLstComponent implements OnInit {
    @Input() colData?: any[];
    @Input() content!: any[];
    @Input() currPage!: number;
    @Input() totalPages!: number;
    @Input() totalElements!: number;
    @Input() rows!: number;
    @Input() numberOfElements?: number;
    @Input() searchForm!: FormGroup;
    @Output() search = new EventEmitter<string>();
    @Output() pageChange = new EventEmitter<PaginatorState>();
    @Output() create = new EventEmitter<boolean>();

    constructor(private toast: ToastService) { }

    ngOnInit(): void {
    }

    // ngOnChanges(changes: SimpleChanges) {
    //     if (this.users) {
    //         this.formGroup?.patchValue(this.users);
    //     }
    // }

    onSearch() {
        // if(this.searchForm.valid){
        //     let email = { ...this.searchForm.value } as string;
        //     this.search.emit(email);
        // } else {
        //     this.toast.error('Thất bại', 'Vui lòng nhập thông tin');
        // }
        let email = { ...this.searchForm.value } as string;
        this.search.emit(email);
    }

    onPageChange(event: PaginatorState) {
        this.pageChange.emit(event);
    }
}