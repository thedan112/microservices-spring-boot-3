import { Component, EventEmitter, Input, OnInit, Output } from "@angular/core";
import { FormGroup } from "@angular/forms";
import { ToastService } from "@modules/common/services/toast.service";
import { ManagementModule } from "@modules/management/management.module";
import { PaginatorState } from "primeng/paginator";

@Component({
    selector: 'app-role-lst',
    templateUrl: './role-lst.component.html',
    styleUrls: ['./role-lst.component.scss'],
    imports: [ManagementModule],
})
export class RoleLstComponent implements OnInit {
    @Input() colData?: any[];
    @Input() content!: any[];
    @Input() currPage!: number;
    @Input() totalPages!: number;
    @Input() totalElements!: number;
    @Input() rows!: number;
    @Input() numberOfElements?: number;
    @Input() searchForm!: FormGroup;
    @Output() search = new EventEmitter<string>();
    @Output() pageChange = new EventEmitter<PaginatorState>();
    @Output() create = new EventEmitter<boolean>();

    constructor(private toast: ToastService) { }

    ngOnInit(): void {
    }

    onSearch() {
        // if(this.searchForm.valid){
        //     let email = { ...this.searchForm.value } as string;
        //     this.search.emit(email);
        // } else {
        //     this.toast.error('Thất bại', 'Vui lòng nhập thông tin');
        // }
        // let email = { ...this.searchForm.value } as string;
        // this.search.emit(email);
    }

    onExport() {
        // if(this.searchForm.valid){
        //     let email = { ...this.searchForm.value } as string;
        //     this.search.emit(email);
        // } else {
        //     this.toast.error('Thất bại', 'Vui lòng nhập thông tin');
        // }
        // let email = { ...this.searchForm.value } as string;
        // this.search.emit(email);
        this.toast.success('Thành công', 'Xuất dữ liệu');
    }

    onPageChange(event: PaginatorState) {
        this.pageChange.emit(event);
    }
}