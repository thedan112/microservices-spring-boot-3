import { HttpClient, HttpParams } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { ResponseModel } from "@modules/common/models/api.response.model";
import { ApiBaseService } from "@modules/common/services/api.base.service";
import { catchError, Observable } from "rxjs";
import { environments } from "src/environments/enviroment";

@Injectable()
export class ApiUserService extends ApiBaseService {
    constructor(private http: HttpClient) { super(); }

    pages(page: number, size: number, filter: string): Observable<ResponseModel<any>> {
        const url = environments.serivce + "/api/management/users";
        let params = new HttpParams();
        if (filter) {
            params = new HttpParams().set('page', page).set('size', size).set('email', filter);
        } else {
            params = new HttpParams().set('page', page).set('size', size);
        }
        return this.http.get<ResponseModel<any>>(url, { headers: this.getHeaders() })
            .pipe(catchError(this.handleError('pages', new ResponseModel<any>())));
    }
}