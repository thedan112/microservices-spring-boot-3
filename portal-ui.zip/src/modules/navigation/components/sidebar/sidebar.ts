import { Component, ElementRef } from "@angular/core";
import { AppMenu } from "../menu/app.menu";

@Component({
    selector: 'app-sidebar',
    templateUrl: './sidebar.html',
    styleUrls: ['./sidebar.scss'],
    imports: [AppMenu],
})
export class SidebarComponent {
    constructor(public el: ElementRef) {}
}