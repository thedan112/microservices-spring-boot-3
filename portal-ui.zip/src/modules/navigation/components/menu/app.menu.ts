import { CommonModule } from "@angular/common";
import { Component } from "@angular/core";
import { RouterModule } from "@angular/router";
import { ManagementSideNav } from "@modules/navigation/data/management.sidebar.data";
import { SideNavItem } from "@modules/navigation/models/sidebar.model";
import { AppMenuItem } from "./app.menuitem";

@Component({
    selector: 'app-menu',
    templateUrl: './app.menu.html',
    styleUrls: ['./app.menu.scss'],
    imports: [CommonModule, RouterModule, AppMenuItem],
})
export class AppMenu {
    model: SideNavItem[] = [];

    ngOnInit() {
        this.model = [
            {
                label: 'Home',
                visible: true,
                items: [{ label: 'Dashboard', icon: 'pi pi-fw pi-home', visible: true, routerLink: ['/home/dashboard'] }]
            },
            ...ManagementSideNav,
        ];
    }
}