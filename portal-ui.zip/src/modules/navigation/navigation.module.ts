// import { CommonModule } from "@angular/common";
// import { NgModule } from "@angular/core";
// import { RouterModule } from "@angular/router";
// import { ToastModule } from 'primeng/toast';
// import { BlockUIModule } from "primeng/blockui";
// import { ConfirmDialogModule } from "primeng/confirmdialog";
// import { ProgressSpinnerModule } from "primeng/progressspinner";
// import { AutoCompleteModule } from "primeng/autocomplete";
// import { FormsModule } from "@angular/forms";
// import { LayoutService } from "./services/layout.service";
// import { LayoutMain } from "./layouts/layout-main/layout-main";


// @NgModule({
//     imports: [CommonModule, RouterModule, ToastModule, BlockUIModule, ConfirmDialogModule, ProgressSpinnerModule, AutoCompleteModule, FormsModule],
//     providers: [LayoutService],
//     declarations: [LayoutMain],
//     exports: [LayoutMain]
// })
// export class NavigationModule { }
