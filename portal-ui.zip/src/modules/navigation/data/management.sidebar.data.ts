import { SideNavItem } from "../models/sidebar.model";

export const ManagementSideNav: SideNavItem[] = [{
    label: 'Access Control',
    items: [
        {
            label: 'Management',
            icon: 'pi pi-fw pi-spin pi-cog',
            visible: true,
            items: [
                { label: 'User', visible: true, icon: 'pi pi-fw pi-users', routerLink: ['/management/users'] },
                { label: 'Department', visible: true, icon: 'pi pi-fw pi-warehouse', routerLink: ['/management/departments'] },
                { label: 'Role', visible: true, icon: 'pi pi-fw pi-wrench', routerLink: ['/management/roles'] },
                { label: 'Group', visible: true, icon: 'pi pi-fw pi-sitemap', routerLink: ['/management/groups'] },
            ]
        },
    ]
},
]