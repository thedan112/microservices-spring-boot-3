import { Routes } from '@angular/router';
import { DashboardComponent } from './components/dashboard';

export default [
    { path: 'dashboard', component: DashboardComponent },
    { path: '**', redirectTo: '/notfound' }
] as Routes;
