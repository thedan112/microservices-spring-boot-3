import { HttpHandlerFn, HttpInterceptorFn, HttpRequest } from "@angular/common/http";
import { LocalStorageService } from "@modules/common/services/app.local-storage.service";
import { inject } from '@angular/core';

// Đây là một Functional Interceptor
export const authInterceptor: HttpInterceptorFn = (req: HttpRequest<unknown>, next: HttpHandlerFn) => {
  // Inject AuthService để lấy token
  const storageService = inject(LocalStorageService);
  const sessionUser = storageService.getSessionUser();
  // Kiểm tra xem có cần thêm token cho request này không
  // Ví dụ: không cần token cho API đăng nhập hoặc đăng ký
  if (req.url.includes('/api/auth/login')) {
    return next(req);
  }

  // Nếu có token, clone request và thêm header Authorization
  if (sessionUser) {
    const clonedReq = req.clone({
      headers: req.headers.set('Authorization', `Bearer ${sessionUser.token}`)
      // Hoặc dùng setHeaders object
      // setHeaders: {
      //   Authorization: `Bearer ${authToken}`
      // }
    });
    return next(clonedReq);
  }
  // Nếu không có token, cho request đi tiếp mà không chỉnh sửa
  return next(req);
};