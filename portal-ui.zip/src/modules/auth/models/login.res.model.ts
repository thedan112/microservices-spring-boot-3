export class LoginResponseModel {
    username?: string;
    token?: string;
    expiry?: number;
}