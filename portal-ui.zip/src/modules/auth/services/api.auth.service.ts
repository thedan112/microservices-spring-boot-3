import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { ResponseModel } from "@modules/common/models/api.response.model";
import { ApiBaseService } from "@modules/common/services/api.base.service";
import { catchError, Observable } from "rxjs";
import { environments } from "src/environments/enviroment";
import { LoginRequestModel } from "../models/login.req.model";
import { LoginResponseModel } from "../models/login.res.model";

@Injectable()
export class ApiAuthService extends ApiBaseService {
    constructor(private http: HttpClient) {
        super();
    }

    login(model: LoginRequestModel): Observable<ResponseModel<LoginResponseModel>> {
        const url = environments.serivce + "/api/auth/login";
        return this.http.post<ResponseModel<LoginResponseModel>>(url, model, { headers: new HttpHeaders() })
            .pipe(catchError(this.handleError('login', new ResponseModel<LoginResponseModel>())));
    }

    logout(): Observable<ResponseModel<any>> {
        const url = environments.serivce + "/api/auth/logout";
        return this.http.get<ResponseModel<any>>(url, { headers: new HttpHeaders() })
            .pipe(catchError(this.handleError('logout', new ResponseModel<any>())));
    }
}