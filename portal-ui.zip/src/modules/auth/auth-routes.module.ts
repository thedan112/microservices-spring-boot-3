import { Routes } from '@angular/router';
import { AuthComponent } from './components/app.auth';

export default [
    { path: 'login', component: AuthComponent },
    { path: '**', redirectTo: '/notfound' }
] as Routes;
