import { NgModule } from "@angular/core";
import { ButtonModule } from 'primeng/button';
import { PasswordModule } from 'primeng/password';
import { InputText } from 'primeng/inputtext';
import { RouterLink } from '@angular/router';
import { IconFieldModule } from 'primeng/iconfield';
import { InputIconModule } from 'primeng/inputicon';
import { InputTextModule } from 'primeng/inputtext';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Toast, ToastModule } from 'primeng/toast';
import { PaginatorModule } from 'primeng/paginator';
import { TableModule } from 'primeng/table';
import { ToolbarModule } from 'primeng/toolbar';
import { CommonModule } from "@angular/common";
import { InputGroupModule } from 'primeng/inputgroup';
import { InputSwitchModule } from 'primeng/inputswitch';
import { FloatLabelModule } from 'primeng/floatlabel';
import { DividerModule } from "primeng/divider";
import { TooltipModule } from "primeng/tooltip";
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { DialogModule } from 'primeng/dialog';
import { Fluid } from 'primeng/fluid';
import { SelectModule } from 'primeng/select';

@NgModule({
    imports: [
        CommonModule,
        FormsModule, 
        ToastModule,
        Toast,
        RouterLink, 
        ButtonModule,
        PasswordModule, 
        InputText,
        IconFieldModule,
        InputIconModule,
        InputTextModule,
        ReactiveFormsModule,
        PaginatorModule,
        TableModule,
        ToolbarModule,
        InputGroupModule,
        InputSwitchModule,
        FloatLabelModule,
        DividerModule,
        TooltipModule,
        PaginatorModule,
        ConfirmDialogModule,
        DialogModule,
        Fluid,
        SelectModule,
    ],
    exports: [
        CommonModule,
        FormsModule, 
        ToastModule,
        RouterLink, 
        ButtonModule,
        PasswordModule, 
        InputText,
        IconFieldModule,
        InputIconModule,
        InputTextModule,
        ReactiveFormsModule,
        PaginatorModule,
        TableModule,
        ToolbarModule,
        InputGroupModule,
        InputSwitchModule,
        FloatLabelModule,
        DividerModule,
        TooltipModule,
        PaginatorModule,
        ConfirmDialogModule,
        DialogModule,
        Fluid,
        SelectModule,
    ],
    providers: []
})
export class AppCommonModule { }