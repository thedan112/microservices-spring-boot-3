export interface IResponseModel<TData> {
    message?: string;
    status?: string;
    data?: TData;
}

export class ResponseModel<TData> implements IResponseModel<TData> {
    constructor() {}
    message?: string;
    status?: string;
    data?: TData;
}