export interface UserModel {
    expiry: number;
    username: string;
    token: string;
}