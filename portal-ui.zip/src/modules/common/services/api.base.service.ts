import {HttpHeaders} from "@angular/common/http";
import {Observable, of} from "rxjs";

export class ApiBaseService {

  public getHeaders(includeJsonContentType?: boolean): HttpHeaders {
    return new HttpHeaders();
  }

  public handleError<T>(operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {
      return of(result as T)
    };
  }
}
