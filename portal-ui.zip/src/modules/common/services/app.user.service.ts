import {Observable} from "rxjs";
import {Injectable} from "@angular/core";
import { LocalStorageService } from "./app.local-storage.service";
import { UserModel } from "../models/user.model";
import { AppContanstData } from "../constant/app.constant.data";

@Injectable({providedIn: 'root'})
export class CommonUserService {

  constructor(private storageService: LocalStorageService) {
  }

  set user(user: UserModel) {
    this.storageService.saveSessionUser(user);
  }

  get user$(): Observable<UserModel> {
    return new Observable<UserModel>((o) => {
      let data = this.storageService.getSessionUser();
      let user: UserModel = {
        username: data?.username || '',
        token: data?.token || '',
        expiry: Number(data?.expiry || 0)
      }
      o.next(user);
      o.complete();
    })
  }

  public getUsername(): string{
    return this.storageService.getSessionUser()?.username || '';
  }

  public validSession(): boolean {
    let cache = this.storageService.getSessionUser();
    return !!cache;
  }
}