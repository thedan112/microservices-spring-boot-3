export const UriConstant: any ={
    error: {
      accessDenied: '/403'
    },
    auth: {
      login: '/auth/login',
      unauthorized: '/401',
      accessDenied: '/403',
      notFound: '/404'
    },
    home: {
      dashboard: '/home/dashboard',
    }
  }
  