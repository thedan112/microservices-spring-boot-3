export const environments = {
    production: false,
    serivce: 'http://localhost:8082'
}