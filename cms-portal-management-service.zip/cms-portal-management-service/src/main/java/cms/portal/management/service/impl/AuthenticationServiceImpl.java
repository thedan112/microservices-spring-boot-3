package cms.portal.management.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.stereotype.Service;

import cms.portal.management.dto.ResponseData;
import cms.portal.management.dto.UserDetailDto;
import cms.portal.management.enums.Messages;
import cms.portal.management.enums.UserTypeEnum;
import cms.portal.management.filter.JwtSessionFilter;
import cms.portal.management.filter.JwtTokenFilter;
import cms.portal.management.model.request.LoginRequest;
import cms.portal.management.model.response.LoginResponse;
import cms.portal.management.repository.FunctionResourceRepository;
import cms.portal.management.repository.PermissionRepository;
import cms.portal.management.repository.UserRepository;
import cms.portal.management.service.IAuthenticationService;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class AuthenticationServiceImpl implements IAuthenticationService {
	@Autowired
	AuthenticationManager authenticationManager;
	@Autowired
	JwtTokenFilter tokenFilter;
	@Autowired
	JwtSessionFilter sessionFilter;
	@Autowired
	UserRepository userRepository;
	@Autowired
	PermissionRepository permissionRepository;
	@Autowired
	FunctionResourceRepository functionResourceRepository;
	
	@Override
	public ResponseData<?> login(LoginRequest req) {
		try {
			Authentication authenticatetion = authenicate(req.getUsername(), req.getPassword());
			UserDetailDto userPrincal = (UserDetailDto) authenticatetion.getPrincipal();
			if (userPrincal.isLocked())
				return ResponseData.error(Messages.USER_LOCKED);
			if (!userPrincal.isActive())
				return ResponseData.error(Messages.USER_NOT_ACTIVE);
			String token = tokenFilter.doGenerateToken(userPrincal);
			activeToken(req.getUsername());
			return ResponseData.success(new LoginResponse(req.getUsername(), userPrincal.getExpiry().getTime(), token));
		} catch (AuthenticationException ex) {
			Messages errorMessage = Messages.UNAUTHORIZED;
			if (ex.getMessage().equalsIgnoreCase("user not found with username: " + req.getUsername())) {
				errorMessage = Messages.USER_BAD_CREDENTIAL;
			} else if (ex.getMessage().equalsIgnoreCase("Bad credentials")) {
				errorMessage = Messages.USER_BAD_CREDENTIAL;
//				sessionFilter.processFailureAuthen(req.getUsername());
			} else if (ex.getMessage().equalsIgnoreCase("User is disabled")) {
				errorMessage = Messages.USER_EXISTED;
			} else if (ex.getMessage().equalsIgnoreCase("User account has expired")) {
				errorMessage = Messages.PASSWORD_EXPIRED;
			} else if (ex.getMessage().equalsIgnoreCase("User account is locked")) {
				errorMessage = Messages.USER_LOCKED;
			}
			log.error("username: {}, Login failed by: {}", req.getUsername(), ex.getMessage());
			return ResponseData.error(errorMessage);
		}
	}

	private Authentication authenicate(String username, String password) {
		return authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(username, password));
	}

	@Override
	public ResponseData<?> isPermission(String uri) {
		UserDetailDto userDetail = sessionFilter.getUserDetail();
		if (userDetail == null)
			return ResponseData.error(Messages.UNAUTHORIZED);
		if (UserTypeEnum.ADMIN.toString().equals(userDetail.getType()))
			return ResponseData.success(true);
//		var permissionEntities = permissionRepository.findAllByGroupIdAndRoleId(userDetail(),
//				userDetail.getRoles());
//		if (CollectionUtils.isEmpty(permissionEntities))
//			return ResponseData.error(Messages.UNAUTHORIZED);
//		var functionResourceEntities = functionResourceRepository.findByResoruceUrl(uri);
//		if (CollectionUtils.isEmpty(functionResourceEntities))
//			return ResponseData.error(Messages.UNAUTHORIZED);
//		boolean hasPermission = permissionEntities.stream().flatMap(
//				per -> functionResourceEntities.stream().filter(f -> f.getFunctionId().equals(per.getFunctionId())))
//				.findAny().isPresent();
//		if(!hasPermission)
//			return ResponseData.error(Messages.UNAUTHORIZED);
		return ResponseData.success(true);
	}

	@Async
	private void activeToken(String username) {
		userRepository.updateTokenByUsername(1, username);
	}

	@Override
	public ResponseData<?> logout() {
		String username = sessionFilter.getSessionUsername();
		if (username == null || username == "")
			return ResponseData.error(Messages.UNAUTHORIZED);
		userRepository.updateTokenByUsername(0, username);
		return ResponseData.success(true);
	}
}
