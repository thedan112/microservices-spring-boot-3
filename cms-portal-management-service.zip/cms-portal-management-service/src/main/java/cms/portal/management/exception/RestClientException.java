package cms.portal.management.exception;

public class RestClientException extends RuntimeException {
	private static final long serialVersionUID = -4106860278997780017L;

	private String message;

	public RestClientException(String endpoint, String message) {
		this.message = "Endpoint: " + endpoint + "; " + "Message: " + message;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

}
