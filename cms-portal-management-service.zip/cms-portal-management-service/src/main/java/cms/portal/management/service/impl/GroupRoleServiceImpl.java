package cms.portal.management.service.impl;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import cms.portal.management.entity.GroupRoleEntity;
import cms.portal.management.repository.GroupRoleRepository;
import cms.portal.management.service.IGroupRoleService;

@Service
public class GroupRoleServiceImpl implements IGroupRoleService {

	@Autowired
	GroupRoleRepository groupRoleRepository;

	@Override
	public List<String> findRoleIdsByGroupId(String groupId) {
		var entities = groupRoleRepository.findByGroupId(groupId);
		if (CollectionUtils.isEmpty(entities))
			return null;
		return entities.stream().map(GroupRoleEntity::getRoleId).toList();
	}

	@Override
	public void saveAll(String groupId, List<String> roleIds) {
		var entities = roleIds.stream().map(s -> new GroupRoleEntity(UUID.randomUUID().toString(), groupId, s))
				.toList();
		if (!CollectionUtils.isEmpty(entities))
			groupRoleRepository.saveAll(entities);
	}

	@Override
	public void updateByResourceUrl(String groupId, List<String> roleIds) {
		if (CollectionUtils.isEmpty(roleIds)) {
			groupRoleRepository.deleteByGroupId(groupId);
		} else {
			var entities = groupRoleRepository.findByGroupId(groupId);
			Set<GroupRoleEntity> newItems = new HashSet<>();
			Set<String> deleteItems = new HashSet<>();
			if (CollectionUtils.isEmpty(entities)) {
				newItems = roleIds.stream().map(s -> new GroupRoleEntity(UUID.randomUUID().toString(), groupId, s))
						.collect(Collectors.toSet());
			} else {
				var existItems = entities.stream().map(GroupRoleEntity::getRoleId).collect(Collectors.toSet());
				newItems = roleIds.stream().filter(f -> !existItems.contains(f))
						.map(s -> new GroupRoleEntity(UUID.randomUUID().toString(), groupId, s))
						.collect(Collectors.toSet());
				deleteItems = entities.stream().filter(f -> roleIds.contains(f.getRoleId())).map(s -> s.getId())
						.collect(Collectors.toSet());
			}
			if (!CollectionUtils.isEmpty(newItems))
				groupRoleRepository.saveAll(newItems);
			if (!CollectionUtils.isEmpty(deleteItems))
				groupRoleRepository.deleteAllById(deleteItems);
		}
	}
}