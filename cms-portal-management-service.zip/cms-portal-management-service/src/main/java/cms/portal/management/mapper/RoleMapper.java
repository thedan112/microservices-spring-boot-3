package cms.portal.management.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import cms.portal.management.entity.RoleEntity;
import cms.portal.management.model.request.RoleActionRequest;

@Mapper
public interface RoleMapper {

	@Mapping(target = "id", expression = "java(java.util.UUID.randomUUID().toString())")
	RoleEntity createEntity(RoleActionRequest source);
}
