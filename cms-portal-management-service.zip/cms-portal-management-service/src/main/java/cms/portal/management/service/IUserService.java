package cms.portal.management.service;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import cms.portal.management.dto.ResponseData;
import cms.portal.management.model.request.UserCreateRequest;
import cms.portal.management.model.request.UserUpdateRequest;

public interface IUserService {

	public ResponseData<?> pages(int page, int size, String filter);

	public ResponseData<?> create(UserCreateRequest req);

	public ResponseData<?> detail(String id);

	public ResponseData<?> update(UserUpdateRequest req);

	public ResponseData<?> changeActive(String id, boolean status);

	public ResponseData<?> changeLocked(String id, boolean status);

	public ResponseData<?> upload(MultipartFile multipartFile);

	public ResponseData<?> saveUpload(List<?> items);

	public ResponseData<?> loadByDepartmentId(int page, int size, String departmentId);
}