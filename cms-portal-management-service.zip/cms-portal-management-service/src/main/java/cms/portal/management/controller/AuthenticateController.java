package cms.portal.management.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import cms.portal.management.model.request.LoginRequest;
import cms.portal.management.model.request.ValidatePermissionRequest;
import cms.portal.management.service.IAuthenticationService;
import jakarta.validation.Valid;

@RestController
@RequestMapping(value = "/auth")
public class AuthenticateController {

	@Autowired
	IAuthenticationService authenticationService;

	@PostMapping(value = "/login")
	public ResponseEntity<?> login(@RequestBody @Valid LoginRequest req) {
		return ResponseEntity.ok(authenticationService.login(req));
	}

	@GetMapping(value = "/logout")
	public ResponseEntity<?> login() {
		return ResponseEntity.ok(authenticationService.logout());
	}

	@PostMapping(value = "/validate-permission")
	public ResponseEntity<?> validatePermission(@RequestBody @Valid ValidatePermissionRequest req) {
		return ResponseEntity.ok(authenticationService.isPermission(req.getUri()));
	}
}
