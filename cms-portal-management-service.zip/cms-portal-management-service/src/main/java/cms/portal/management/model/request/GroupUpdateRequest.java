package cms.portal.management.model.request;

import java.util.List;

import lombok.Data;

@Data
public class GroupUpdateRequest {

	private String id;
	private String name;
	private boolean addRole;
	private List<String> roleIds;
}
