package cms.portal.management.service.impl;

import java.time.LocalDateTime;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.mapstruct.factory.Mappers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import cms.portal.management.dto.ResponseData;
import cms.portal.management.dto.SelectItem;
import cms.portal.management.dto.UserDetailDto;
import cms.portal.management.entity.UserEntity;
import cms.portal.management.enums.Messages;
import cms.portal.management.enums.UserTypeEnum;
import cms.portal.management.filter.JwtSessionFilter;
import cms.portal.management.mapper.UserMapper;
import cms.portal.management.model.request.UserCreateRequest;
import cms.portal.management.model.request.UserUpdateRequest;
import cms.portal.management.repository.UserRepository;
import cms.portal.management.service.IUserService;
import cms.portal.management.util.HelperUtil;

@Service
public class UserServiceImpl implements IUserService {
	private final UserMapper mapper = Mappers.getMapper(UserMapper.class);
	
	@Autowired
	UserRepository userRepository;
	@Autowired
	JwtSessionFilter sessionFilter;

	@Override
	public ResponseData<?> pages(int page, int size, String filter) {
		UserDetailDto userPrincipal = sessionFilter.getUserDetail();
		if (userPrincipal == null)
			return ResponseData.error(Messages.UNAUTHORIZED);
		Pageable paging = PageRequest.of(page, size, Sort.by(Sort.Direction.ASC, "username"));
		Page<UserEntity> pageEntity;
		if (StringUtils.isNotBlank(filter)) {
			pageEntity = userRepository.findByEmailContainingIgnoreCase(filter, paging);
		} else {
			pageEntity = userRepository.findAll(paging);
		}
		var users = pageEntity.getContent().stream().filter(f -> !UserTypeEnum.ADMIN.toString().equals(f.getType()))
				.map(s -> mapper.userResponse(s)).toList();
		var pagedData = new PageImpl<>(users, paging, pageEntity.getTotalElements());
		return ResponseData.success(pagedData);
	}

	@Override
	public ResponseData<?> create(UserCreateRequest req) {
		var userPrincipal = sessionFilter.getUserDetail();
		if (userPrincipal == null)
			return ResponseData.unauthorized();
		var optional = userRepository.findByEmail(req.getEmail().toLowerCase());
		if (optional.isPresent())
			return ResponseData.error(Messages.USER_EXISTED);
		var entity = mapper.createEntity(req);
		entity.setCreatedBy(userPrincipal.getUsername());
		userRepository.save(entity);
		return ResponseData.success(entity.getEmail());
	}

	@Override
	public ResponseData<?> detail(String id) {
		if (StringUtils.isBlank(id))
			return ResponseData.error(Messages.BAD_REQUEST);
		var optional = userRepository.findById(id);
		if (optional.isEmpty())
			return ResponseData.error(Messages.ROLE_NOT_FOUND);
		return ResponseData.success(optional.get());
	}

	@Override
	public ResponseData<?> update(UserUpdateRequest req) {
		var userPrincipal = sessionFilter.getUserDetail();
		if (userPrincipal == null)
			return ResponseData.unauthorized();
		if (UserTypeEnum.ADMIN.toString().equals(req.getType())
				&& !UserTypeEnum.ADMIN.toString().equals(userPrincipal.getType()))
			return ResponseData.error(Messages.BAD_REQUEST);
		var optional = userRepository.findById(req.getId());
		if (optional.isEmpty())
			return ResponseData.error(Messages.USER_NOT_FOUND);
		var entity = optional.get();
		entity.setUpdatedDate(LocalDateTime.now());
		entity.setUpdatedBy(userPrincipal.getUsername());
		HelperUtil.updateIfChanged(entity::setDepartmentId, entity.getDepartmentId(), req.getDepartmentId());
		HelperUtil.updateIfChanged(entity::setType, entity.getType(), req.getType());
		userRepository.save(entity);
		return ResponseData.success(entity.getEmail());
	}

	@Override
	public ResponseData<?> changeActive(String id, boolean status) {
		var userPrincipal = sessionFilter.getUserDetail();
		if (userPrincipal == null)
			return ResponseData.unauthorized();
		if (StringUtils.isBlank(id))
			return ResponseData.error(Messages.BAD_REQUEST);
		var optional = userRepository.findById(id);
		if (optional.isEmpty())
			return ResponseData.error(Messages.USER_NOT_FOUND);
		var entity = optional.get();
		entity.setActive(status);
		userRepository.save(entity);
		return ResponseData.success(true);
	}

	@Override
	public ResponseData<?> changeLocked(String id, boolean status) {
		var userPrincipal = sessionFilter.getUserDetail();
		if (userPrincipal == null)
			return ResponseData.unauthorized();
		if (StringUtils.isBlank(id))
			return ResponseData.error(Messages.BAD_REQUEST);
		var optional = userRepository.findById(id);
		if (optional.isEmpty())
			return ResponseData.error(Messages.USER_NOT_FOUND);
		var entity = optional.get();
		entity.setLocked(status);
		userRepository.save(entity);
		return ResponseData.success(true);
	}

	@Override
	public ResponseData<?> upload(MultipartFile multipartFile) {
		return ResponseData.success(true);
	}

	@Override
	public ResponseData<?> saveUpload(List<?> items) {
		return ResponseData.success(true);
	}

	@Override
	public ResponseData<?> loadByDepartmentId(int page, int size, String departmentId) {
		UserDetailDto userPrincipal = sessionFilter.getUserDetail();
		if (userPrincipal == null)
			return ResponseData.error(Messages.UNAUTHORIZED);
		Pageable paging = PageRequest.of(page, size, Sort.by(Sort.Direction.ASC, "username"));
		Page<UserEntity> pageEntity = userRepository.findByDepartmentId(departmentId, paging);
		var users = pageEntity.getContent().stream().map(s -> new SelectItem<>(s.getUsername(), s.getUsername()))
				.toList();
		var pagedData = new PageImpl<>(users, paging, pageEntity.getTotalElements());
		return ResponseData.success(pagedData);
	}
}