package cms.portal.management.service.impl;

import java.util.List;
import java.util.UUID;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import cms.portal.management.dto.ResponseData;
import cms.portal.management.dto.SelectItem;
import cms.portal.management.dto.UserDetailDto;
import cms.portal.management.entity.ScopeEntity;
import cms.portal.management.enums.Messages;
import cms.portal.management.filter.JwtSessionFilter;
import cms.portal.management.model.request.ScopeCreateRequest;
import cms.portal.management.model.request.ScopeUpdateRequest;
import cms.portal.management.repository.ScopeRepository;
import cms.portal.management.service.IScopeService;
import cms.portal.management.util.HelperUtil;

@Service
public class ScopeServiceImpl implements IScopeService {

	@Autowired
	JwtSessionFilter sessionFilter;

	@Autowired
	ScopeRepository scopeRepository;

	@Override
	public ResponseData<?> all() {
		var items = scopeRepository.findByOrderByNameAsc().stream().map(s -> new SelectItem<>(s.getName(), s.getId()))
				.toList();
		return ResponseData.success(items);
	}

	@Override
	public ResponseData<?> pages(int page, int size, String filter) {
		UserDetailDto userPrincipal = sessionFilter.getUserDetail();
		if (userPrincipal == null)
			return ResponseData.error(Messages.UNAUTHORIZED);
		Pageable paging = PageRequest.of(page, size);
		Page<ScopeEntity> pageEntity;
		if (StringUtils.isNotBlank(filter)) {
			pageEntity = scopeRepository.findByNameContainingIgnoreCase(filter, paging);
		} else {
			pageEntity = scopeRepository.findAll(paging);
		}
		return ResponseData.success(pageEntity);
	}

	@Override
	public ResponseData<?> create(ScopeCreateRequest req) {
		UserDetailDto userPrincipal = sessionFilter.getUserDetail();
		if (userPrincipal == null)
			return ResponseData.error(Messages.UNAUTHORIZED);
		var optional = scopeRepository.findByName(req.getName());
		if (optional.isPresent())
			return ResponseData.error(Messages.SCOPE_EXISTED);
		var entity = ScopeEntity.builder().id(UUID.randomUUID().toString()).name(req.getName()).build();
		scopeRepository.save(entity);
		return ResponseData.success(entity.getName());
	}

	@Override
	public ResponseData<?> update(ScopeUpdateRequest req) {
		var userPrincipal = sessionFilter.getUserDetail();
		if (userPrincipal == null)
			return ResponseData.unauthorized();
		var optional = scopeRepository.findById(req.getId());
		if (optional.isEmpty())
			return ResponseData.error(Messages.SCOPE_NOT_FOUND);
		var entity = optional.get();
		HelperUtil.updateIfChanged(entity::setName, entity.getName(), req.getName());
		scopeRepository.save(entity);
		return ResponseData.success(true);
	}

	@Override
	public ResponseData<?> detail(String id) {
		if (StringUtils.isBlank(id))
			return ResponseData.error(Messages.BAD_REQUEST);
		var optional = scopeRepository.findById(id);
		if (optional.isEmpty())
			return ResponseData.error(Messages.NOT_FOUND_DATA);
		var entity = optional.get();
		return ResponseData.success(entity);
	}

	@Override
	public List<ScopeEntity> loadAllByIds(List<String> ids) {
		return scopeRepository.findAllById(ids);
	}
}