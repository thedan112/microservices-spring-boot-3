package cms.portal.management.dto;

import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import cms.portal.management.entity.UserEntity;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonDeserialize
public class UserDetailDto implements UserDetails {
	private static final long serialVersionUID = 3682176321918423618L;

	private String id;
	private String username;
	private String email;
	@JsonIgnore
	private String password;
	private Date expiry;
	private boolean locked;
	private boolean active;
	private String type;
	private String department;
	private List<SelectItem<String>> groups;
	private List<SelectItem<String>> roles;
	@JsonIgnore
	private Collection<? extends GrantedAuthority> authorities;

	public UserDetailDto(UserEntity userEntity, List<SelectItem<String>> groups, List<SelectItem<String>> roles) {
		this.id = UUID.randomUUID().toString();
		this.username = userEntity.getUsername();
		this.email = userEntity.getEmail();
		this.password = userEntity.getPassword();
		this.locked = userEntity.isLocked();
		this.active = userEntity.isActive();
		this.type = userEntity.getType();
		this.department = userEntity.getDepartmentId();
		this.roles = roles;
		this.groups = groups;
		this.expiry = Date.from(Instant.now().plus(1, ChronoUnit.HOURS));
		this.authorities = null;
	}
}