package cms.portal.management.model.request;

import java.util.List;

import lombok.Data;

@Data
public class PermissionUpdateSelecteRequest {

	private String departmentId;
	private String groupId;
	private String roleId;
	private List<String> items;
}