package cms.portal.management.model.response;

import java.util.List;

import cms.portal.management.entity.ResourceEntity;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
public class FunctionResourceResponse {

	private List<ResourceEntity> sources;
	private List<ResourceEntity> targets;
}
