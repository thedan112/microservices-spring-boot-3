package cms.portal.management.enums;

public enum Messages {
	SUCCESS("000", "Successfully"), 
	BAD_REQUEST("400", "Bad Request"),
	ACCESS_DENIED("403", "Access denined."),
	NOT_FOUND_DATA("404", "Not found data"), 
	UNAUTHORIZED("401", "Your session has expired"),
	PROCESSING_ERROR("500", "Processing error, please check again !"), 
	
	USER_LOCKED("1000", "User has locked"), 
	USER_EXISTED("1001", "User existed in portal"),
	USER_NOT_ACTIVE("1002", "User not active"),
	USER_NOT_FOUND("1003", "User not found"),
	USER_BAD_CREDENTIAL("1004", "Username or password incorrect"),
	PASSWORD_EXPIRED("1005", "Your password has expired"),
	
	ROLE_EXISTED("1004", "Role existed."),
	ROLE_NOT_FOUND("1005", "Role not found."),
	
	DEPARTMENT_EXISTED("2000", "Department existed"),
	DEPARTMENT_NOT_FOUND("2001", "Department not found."),
	
	FUNCTION_EXISTED("3000", "Function existed."),
	FUNCTION_NOT_FOUND("3001", "Function not found."),
	
	RESOURCE_EXISTED("4000", "Resource exited."),
	RESOURCE_NOT_FOUND("4001", "Resource nout found."),
	
	SCOPE_EXISTED("5000", "Scope exited."),
	SCOPE_NOT_FOUND("5001", "Scope nout found."),
	;
	
	private final String status;
	private final String message;

	Messages(String status, String message) {
		this.status = status;
		this.message = message;
	}

	public String getMessage() {
		return message;
	}

	public String getStatus() {
		return status;
	}

	@Override
	public String toString() {
		return message;
	}
}