package cms.portal.management.model.response;

import java.util.Date;
import java.util.List;

import lombok.Data;

@Data
public class FunctionDetailResponse {

	private String id;
	private String name;
	private String description;
	private String type;
	private Boolean active;
	private String createdBy;
	private Date createdDate;
	private String updatedBy;
	private Date updatedDate;
	private String resourceView;
	private List<String> resourceIds;
}
