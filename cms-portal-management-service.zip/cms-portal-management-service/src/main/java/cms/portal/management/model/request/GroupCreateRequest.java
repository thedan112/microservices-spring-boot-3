package cms.portal.management.model.request;

import java.util.List;

import lombok.Data;

@Data
public class GroupCreateRequest {

	private String name;
	private boolean addRole;
	private List<String> roleIds;
}
