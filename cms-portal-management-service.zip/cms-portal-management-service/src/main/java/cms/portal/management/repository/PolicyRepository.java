package cms.portal.management.repository;

import java.util.List;
import java.util.Set;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;

import cms.portal.management.entity.PolicyEntity;
import jakarta.transaction.Transactional;

public interface PolicyRepository extends JpaRepository<PolicyEntity, String>{

	List<PolicyEntity> findByGroupIdAndRoleIdIn(String groupId, Set<String> roleIds);
	
	List<PolicyEntity> findAllByGroupIdAndRoleId(String groupId, String roleId);
	
	@Modifying
	@Transactional
	void deleteByGroupIdAndRoleId(String groupId, String roleId);
}