package cms.portal.management.model.request;

import lombok.Data;

@Data
public class ValidatePermissionRequest {

	private String uri;
}