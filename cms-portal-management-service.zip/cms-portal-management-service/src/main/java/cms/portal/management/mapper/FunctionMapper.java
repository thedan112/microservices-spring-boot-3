package cms.portal.management.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import cms.portal.management.entity.FunctionEntity;
import cms.portal.management.model.request.FunctionCreateRequest;
import cms.portal.management.model.response.FunctionDetailResponse;

@Mapper
public interface FunctionMapper {

	@Mapping(target = "id", expression = "java(java.util.UUID.randomUUID().toString())")
	@Mapping(target = "active", expression = "java(true)")
	FunctionEntity createEntity(FunctionCreateRequest source);
	
	FunctionDetailResponse funtionDetailResponse(FunctionEntity source);
}
