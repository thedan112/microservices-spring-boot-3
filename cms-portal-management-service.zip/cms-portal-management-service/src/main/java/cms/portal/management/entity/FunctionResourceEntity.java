package cms.portal.management.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "FUNCTION_RESOURCE_MAPPING")
public class FunctionResourceEntity {

	@Id
	@Column(name = "ID")
	private String id;
	
	@Column(name = "FUNCTION_ID")
	private String functionId;

	@Column(name = "RESOURCE_ID")
	private String resourceId;
	
	@Column(name = "RESOURCE_URL")
	private String resourceUrl;
	
	@Column(name = "RESOURCE_TYPE")
	private String resourceType;
}