package cms.portal.management.service;

import cms.portal.management.dto.ResponseData;
import cms.portal.management.model.request.DepartmentCreateRequest;
import cms.portal.management.model.request.DepartmentUpdateRequest;

public interface IDepartmentService {

	public ResponseData<?> all();
	
	public ResponseData<?> pages(int page, int size, String filter);
	
	public ResponseData<?> create(DepartmentCreateRequest req);

	public ResponseData<?> detail(String id);

	public ResponseData<?> update(DepartmentUpdateRequest req);
}
