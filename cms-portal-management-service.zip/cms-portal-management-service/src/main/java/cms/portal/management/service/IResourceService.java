package cms.portal.management.service;

import java.util.List;

import cms.portal.management.dto.ResponseData;
import cms.portal.management.entity.ResourceEntity;
import cms.portal.management.model.request.ResourceCreateRequest;
import cms.portal.management.model.request.ResourceUpdateRequest;

public interface IResourceService {

	public ResponseData<?> apis();
	
	public ResponseData<?> views();
	
	public ResponseData<?> pages(int page, int size, String filter);

	public ResponseData<?> create(ResourceCreateRequest req);

	public ResponseData<?> update(ResourceUpdateRequest req);

	public ResponseData<?> detail(String id);

	public ResponseData<?> changeActive(String id, boolean status);
	
	public List<ResourceEntity> findAllByIds(List<String> ids);
	
	public ResourceEntity findById(String id);
}