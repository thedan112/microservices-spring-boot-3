package cms.portal.management.model.request;

import lombok.Data;

@Data
public class RoleActionRequest {

	private String id;
	private String name;
}
