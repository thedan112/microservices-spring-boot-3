package cms.portal.management.model.request;

import lombok.Data;

@Data
public class UserUpdateRequest {

	private String id;
	private String departmentId;
	private String type;
}
