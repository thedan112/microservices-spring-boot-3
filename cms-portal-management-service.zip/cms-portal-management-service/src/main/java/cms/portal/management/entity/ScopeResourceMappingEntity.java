package cms.portal.management.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "SCOPE_RESOURCE_MAPPING")
public class ScopeResourceMappingEntity {

	@Id
	@Column(name = "ID")
	private String id;
	
	@Column(name = "SCOPE_ID")
	private String scopeId;
	
	@Column(name = "RESOURCE_URL")
	private String resourceUrl;
}