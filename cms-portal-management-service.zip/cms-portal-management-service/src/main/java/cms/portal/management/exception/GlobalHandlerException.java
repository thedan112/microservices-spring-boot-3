package cms.portal.management.exception;

import java.util.HashMap;
import java.util.Map;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import cms.portal.management.dto.ResponseData;
import cms.portal.management.enums.Messages;
import lombok.extern.slf4j.Slf4j;

@RestControllerAdvice
@Slf4j
public class GlobalHandlerException {

	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<?> methodArgumentNotValidException(MethodArgumentNotValidException ex) {
		Map<String, String> errors = new HashMap<>();
		ex.getBindingResult().getFieldErrors().forEach(error -> {
			errors.put(error.getField(), error.getDefaultMessage());
		});
		String errorFirst = ex.getBindingResult().getAllErrors().get(0).getDefaultMessage();
		var response = ResponseData.error(Messages.BAD_REQUEST.getStatus(), errorFirst);
		return ResponseEntity.ok(response);
	}

	@ExceptionHandler(RestClientException.class)
	public void restClientExceltpion(RestClientException ex) {
		log.error(ex.getMessage());

	}
}