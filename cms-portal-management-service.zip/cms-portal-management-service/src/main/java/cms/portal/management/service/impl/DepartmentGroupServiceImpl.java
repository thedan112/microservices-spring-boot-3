package cms.portal.management.service.impl;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import cms.portal.management.entity.DepartmentGroupMappingEntity;
import cms.portal.management.filter.JwtSessionFilter;
import cms.portal.management.repository.DepartmentGroupMappingRepository;
import cms.portal.management.service.IDepartmentGroupService;

@Service
public class DepartmentGroupServiceImpl implements IDepartmentGroupService {
	@Autowired
	DepartmentGroupMappingRepository departmentGroupMappingRepository;
	@Autowired
	JwtSessionFilter sessionFilter;

	@Override
	public List<String> findGroupIdsByDepartmentId(String departmentId) {
		var entities = departmentGroupMappingRepository.findByDepartmentId(departmentId);
		if (CollectionUtils.isEmpty(entities))
			return new ArrayList<>();
		return entities.stream().map(DepartmentGroupMappingEntity::getGroupId).toList();
	}

	@Override
	public void updateByDepartmentIdAndGroupIdIn(String departmentId, List<String> groupIds) {
		if (CollectionUtils.isEmpty(groupIds)) {
			departmentGroupMappingRepository.deleteByDepartmentId(departmentId);
		} else {
			var entities = departmentGroupMappingRepository.findByDepartmentId(departmentId);
			Set<DepartmentGroupMappingEntity> newItems = new HashSet<>();
			Set<String> deleteItems = new HashSet<>();
			if (CollectionUtils.isEmpty(entities)) {
				newItems = groupIds.stream()
						.map(s -> new DepartmentGroupMappingEntity(UUID.randomUUID().toString(), departmentId, s))
						.collect(Collectors.toSet());
			} else {
				var existItems = entities.stream().map(DepartmentGroupMappingEntity::getGroupId)
						.collect(Collectors.toSet());
				newItems = groupIds.stream().filter(f -> !existItems.contains(f))
						.map(s -> new DepartmentGroupMappingEntity(UUID.randomUUID().toString(), departmentId, s))
						.collect(Collectors.toSet());
				deleteItems = entities.stream().filter(f -> !groupIds.contains(f.getGroupId())).map(s -> s.getId())
						.collect(Collectors.toSet());
			}
			if (!newItems.isEmpty())
				departmentGroupMappingRepository.saveAll(newItems);
			if (!deleteItems.isEmpty())
				departmentGroupMappingRepository.deleteAllById(deleteItems);
		}
	}

	@Override
	public void saveAllByDepartmentId(String departmentId, List<String> groupIds) {
		var entities = groupIds.stream()
				.map(s -> new DepartmentGroupMappingEntity(UUID.randomUUID().toString(), departmentId, s)).toList();
		if (!CollectionUtils.isEmpty(entities))
			departmentGroupMappingRepository.saveAll(entities);
	}
}