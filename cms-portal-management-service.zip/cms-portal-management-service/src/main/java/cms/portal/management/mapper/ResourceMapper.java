package cms.portal.management.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import cms.portal.management.entity.ResourceEntity;
import cms.portal.management.model.request.ResourceCreateRequest;
import cms.portal.management.model.response.ResourceDetailResponse;

@Mapper
public interface ResourceMapper {

	@Mapping(target = "id", expression = "java(java.util.UUID.randomUUID().toString())")
	@Mapping(target = "active", expression = "java(true)")
	ResourceEntity createEntity(ResourceCreateRequest source);
	
	ResourceDetailResponse detailResponse(ResourceEntity source);
}
