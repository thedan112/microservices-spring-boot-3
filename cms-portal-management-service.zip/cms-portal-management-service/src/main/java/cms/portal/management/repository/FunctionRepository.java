package cms.portal.management.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import cms.portal.management.entity.FunctionEntity;

public interface FunctionRepository extends JpaRepository<FunctionEntity, String>{

	Page<FunctionEntity> findByNameContainingIgnoreCase(String name, Pageable pageable);
	
	Page<FunctionEntity> findAllByIdIn(List<String> ids, Pageable pageable);
	
	Optional<FunctionEntity> findByName(String name);
}
