package cms.portal.management.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import cms.portal.management.model.request.PermissionRequest;
import cms.portal.management.model.request.PermissionUpdateSelecteRequest;
import cms.portal.management.service.IPermissionService;
import jakarta.validation.Valid;

@RestController
@RequestMapping(value = "/permission")
public class PermissionController {

	@Autowired
	IPermissionService permissionService;

	@GetMapping(value = "/groups")
	public ResponseEntity<?> findGroupByDepartment(@RequestParam(value = "id") String departmentId) {
		return ResponseEntity.ok(permissionService.findAllGroupByDepartmentId(departmentId));
	}

	@GetMapping(value = "/roles")
	public ResponseEntity<?> findRoleSelectByGroupId(@RequestParam(value = "id") String groupId) {
		return ResponseEntity.ok(permissionService.findAllRoleSelectByGroup(groupId));
	}

	@PostMapping(value = "/members")
	public ResponseEntity<?> findUserByGroupIdAndRoleId(@RequestBody PermissionRequest req) {
		return ResponseEntity.ok(permissionService.findAllUserByGroupIdAndRoleIdAndDepartmentId(req));
	}

	@PostMapping(value = "/functions")
	public ResponseEntity<?> findAllFunctionByGroupIdAndRoleId(@RequestBody PermissionRequest req) {
		return ResponseEntity.ok(permissionService.findAllFunctionByGroupIdAndRoleId(req));
	}

	@PostMapping(value = "/scopes")
	public ResponseEntity<?> findScopeByGroupIdAndRoleId(@RequestBody PermissionRequest req) {
		return ResponseEntity.ok(permissionService.findAllScopeByGroupIdAndRoleId(req));
	}

	@PostMapping(value = "/functions/update")
	public ResponseEntity<?> updateChangeFunction(@RequestBody @Valid PermissionUpdateSelecteRequest req) {
		return ResponseEntity.ok(permissionService.updateChangeSelectFunction(req));
	}

	@PostMapping(value = "/scopes/update")
	public ResponseEntity<?> updateChangeScope(@RequestBody @Valid PermissionUpdateSelecteRequest req) {
		return ResponseEntity.ok(permissionService.updateChangeSelectScope(req));
	}

	@PostMapping(value = "/members/update")
	public ResponseEntity<?> updateChangeMember(@RequestBody @Valid PermissionUpdateSelecteRequest req) {
		return ResponseEntity.ok(permissionService.updateChangeSelectMember(req));
	}
}