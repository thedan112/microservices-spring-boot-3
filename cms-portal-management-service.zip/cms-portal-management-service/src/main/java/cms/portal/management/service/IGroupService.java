package cms.portal.management.service;

import java.util.List;

import cms.portal.management.dto.ResponseData;
import cms.portal.management.entity.GroupEntity;
import cms.portal.management.model.request.GroupCreateRequest;
import cms.portal.management.model.request.GroupUpdateRequest;

public interface IGroupService {

	public ResponseData<?> all();

	public ResponseData<?> pages(int page, int size, String filter);

	public ResponseData<?> create(GroupCreateRequest req);

	public ResponseData<?> update(GroupUpdateRequest req);

	public ResponseData<?> detail(String id);

	public ResponseData<?> changeActive(String id, boolean status);
	
	public List<GroupEntity> findAllById(List<String> ids);
}