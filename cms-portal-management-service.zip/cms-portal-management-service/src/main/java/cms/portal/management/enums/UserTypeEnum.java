package cms.portal.management.enums;

public enum UserTypeEnum {
	ADMIN,
	USER,
	OPERATION,
	;
}
