package cms.portal.management.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import cms.portal.management.enums.Messages;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class ResponseData<T> {

	private String status;
	private String message;
	private T data;

	public static <T> ResponseData<T> success(T data) {
		return new ResponseData<T>(Messages.SUCCESS.getStatus(), Messages.SUCCESS.getMessage(), data);
	}

	public static <T> ResponseData<T> error(String status, String message) {
		return new ResponseData<T>(status, message, null);
	}

	public static <T> ResponseData<T> error(Messages message) {
		return new ResponseData<T>(message.getStatus(), message.getMessage(), null);
	}

	public static <T> ResponseData<T> internalServerError() {
		return new ResponseData<T>(Messages.PROCESSING_ERROR.getStatus(), Messages.PROCESSING_ERROR.getMessage(), null);
	}

	public static <T> ResponseData<T> unauthorized() {
		return new ResponseData<T>(Messages.UNAUTHORIZED.getStatus(), Messages.UNAUTHORIZED.getMessage(), null);
	}

	public static <T> ResponseData<T> accessDenied() {
		return new ResponseData<T>(Messages.ACCESS_DENIED.getStatus(), Messages.ACCESS_DENIED.getMessage(), null);
	}

	@JsonIgnore
	public boolean isError() {
		return !Messages.SUCCESS.getStatus().equals("000");
	}
}
