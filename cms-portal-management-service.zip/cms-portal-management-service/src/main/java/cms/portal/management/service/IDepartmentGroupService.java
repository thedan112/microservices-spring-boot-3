package cms.portal.management.service;

import java.util.List;

public interface IDepartmentGroupService {

	public List<String> findGroupIdsByDepartmentId(String departmentId);

	public void updateByDepartmentIdAndGroupIdIn(String departmentId, List<String> groupIds);
	
	public void saveAllByDepartmentId(String departmentId, List<String> groupIds);
}
