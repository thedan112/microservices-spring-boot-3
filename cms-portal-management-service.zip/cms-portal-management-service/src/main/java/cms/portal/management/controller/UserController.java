package cms.portal.management.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import cms.portal.management.model.request.UserCreateRequest;
import cms.portal.management.service.IUserService;
import jakarta.validation.Valid;

@RestController
@RequestMapping(value = "/user")
public class UserController {

	@Autowired
	IUserService service;

	@PostMapping(value = "/pages")
	public ResponseEntity<?> pages(@RequestParam(required = false, defaultValue = "0") int page,
			@RequestParam(required = false, defaultValue = "10") int size,
			@RequestParam(required = false, name = "email") String email) {
		return ResponseEntity.ok(service.pages(page, size, email));
	}

	@PostMapping(value = "/department")
	public ResponseEntity<?> loadByDepartmentId(@RequestParam(required = false, defaultValue = "0") int page,
			@RequestParam(required = false, defaultValue = "10") int size,
			@RequestParam(value = "id") String departmentId) {
		return ResponseEntity.ok(service.loadByDepartmentId(page, size, departmentId));
	}

	@GetMapping(value = "/validate")
	public ResponseEntity<?> validateEmail(@RequestParam(required = false, name = "email") String email) {
		return ResponseEntity.ok(null);
	}

	@PostMapping(value = "/create")
	public ResponseEntity<?> create(@RequestBody @Valid UserCreateRequest req) {
		return ResponseEntity.ok(service.create(req));
	}

	@GetMapping(value = "/detail")
	public ResponseEntity<?> detail(@RequestParam(required = false, name = "id") String id) {
		return ResponseEntity.ok(null);
	}

	@PostMapping(value = "/update")
	public ResponseEntity<?> update() {
		return ResponseEntity.ok(null);
	}

	@PostMapping(value = "/change-active")
	public ResponseEntity<?> changeActive(@RequestParam(required = false, name = "id") String id,
			@RequestParam(required = false, name = "status", defaultValue = "false") boolean status) {
		return ResponseEntity.ok(service.changeActive(id, status));
	}

	@PostMapping(value = "/change-locked")
	public ResponseEntity<?> changeLocked(@RequestParam(required = false, name = "id") String id,
			@RequestParam(required = false, name = "status", defaultValue = "false") boolean status) {
		return ResponseEntity.ok(service.changeLocked(id, status));
	}
}