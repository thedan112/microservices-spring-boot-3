package cms.portal.management.service.impl;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import cms.portal.management.entity.FunctionResourceEntity;
import cms.portal.management.enums.ResourceEnum;
import cms.portal.management.repository.FunctionResourceRepository;
import cms.portal.management.service.IFunctionResourceService;
import cms.portal.management.service.IResourceService;

@Service
public class FunctionResourceServiceImpl implements IFunctionResourceService {

	@Autowired
	FunctionResourceRepository functionResourceRepository;

	@Autowired
	IResourceService resourceService;

	@Override
	public List<FunctionResourceEntity> findByFunctionId(String functionId) {
		return functionResourceRepository.findByFunctionId(functionId);
	}

	@Override
	public void updateResourceByFunctionId(String functionId, List<String> resourceIds) {
		List<String> newItems = new ArrayList<>();
		Set<String> deleteItems = new HashSet<>();
		var entities = functionResourceRepository.findByFunctionIdAndResourceType(functionId,
				ResourceEnum.API.toString());
		if (CollectionUtils.isEmpty(resourceIds)) {
			deleteItems = entities.stream().map(FunctionResourceEntity::getId).collect(Collectors.toSet());
		} else {
			var existItems = entities.stream().map(FunctionResourceEntity::getResourceId).collect(Collectors.toSet());
			newItems = resourceIds.stream().filter(f -> !existItems.contains(f)).map(String::new).toList();
			deleteItems = entities.stream().filter(f -> !resourceIds.contains(f.getResourceId())).map(s -> s.getId())
					.collect(Collectors.toSet());
		}
		if (!CollectionUtils.isEmpty(newItems))
			saveAll(functionId, newItems);
		if (!CollectionUtils.isEmpty(deleteItems))
			functionResourceRepository.deleteAllById(deleteItems);
	}

	@Override
	public void updateResourceView(String functionId, String resourceView) {
		var entities = functionResourceRepository.findByFunctionIdAndResourceType(functionId,
				ResourceEnum.VIEW.toString());
		if (!CollectionUtils.isEmpty(entities)) {
			var entity = entities.get(0);
			var resourceEntity = resourceService.findById(resourceView);
			if (!entity.getResourceUrl().equalsIgnoreCase(resourceEntity.getUrl())) {
				entity.setResourceId(resourceEntity.getId());
				entity.setResourceUrl(resourceEntity.getUrl());
				functionResourceRepository.save(entity);
			}
		}
	}

	@Override
	public void saveAll(String functionId, List<String> resourceIds) {
		var resourceEntities = resourceService.findAllByIds(resourceIds);
		if (CollectionUtils.isEmpty(resourceEntities))
			return;
		var createEntities = resourceEntities.stream()
				.map(s -> FunctionResourceEntity.builder().id(UUID.randomUUID().toString()).functionId(functionId)
						.resourceId(s.getId()).resourceUrl(s.getUrl()).resourceType(s.getType()).build())
				.toList();
		if (!CollectionUtils.isEmpty(createEntities))
			functionResourceRepository.saveAll(createEntities);
	}
}
