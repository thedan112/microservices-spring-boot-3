package cms.portal.management.mapper;

import java.time.LocalDateTime;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;

import cms.portal.management.entity.DepartmentEntity;
import cms.portal.management.model.request.DepartmentCreateRequest;

@Mapper
public interface DepartmentMapper {

	@Mapping(target = "id", expression = "java(java.util.UUID.randomUUID().toString())")
	@Mapping(target = "createdDate", expression = "java(today())")
	DepartmentEntity createEntity(DepartmentCreateRequest source);
	
	@Named("today")
	default LocalDateTime today() {
		return LocalDateTime.now();
	}
}
