package cms.portal.management.service.impl;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import cms.portal.management.dto.ResponseData;
import cms.portal.management.dto.SelectItem;
import cms.portal.management.dto.UserDetailDto;
import cms.portal.management.entity.GroupEntity;
import cms.portal.management.enums.Messages;
import cms.portal.management.filter.JwtSessionFilter;
import cms.portal.management.model.request.GroupCreateRequest;
import cms.portal.management.model.request.GroupUpdateRequest;
import cms.portal.management.model.response.GroupDetailResponse;
import cms.portal.management.repository.GroupRepository;
import cms.portal.management.service.IGroupRoleService;
import cms.portal.management.service.IGroupService;
import cms.portal.management.util.HelperUtil;

@Service
public class GroupServiceImpl implements IGroupService {

	@Autowired
	JwtSessionFilter sessionFilter;

	@Autowired
	GroupRepository groupRepository;

	@Autowired
	IGroupRoleService groupRoleService;

	@Override
	public ResponseData<?> all() {
		var entities = groupRepository.findByActiveOrderByNameAsc(true).stream()
				.map(s -> new SelectItem<>(s.getName(), s.getId())).toList();
		return ResponseData.success(entities);
	}

	@Override
	public ResponseData<?> pages(int page, int size, String filter) {
		UserDetailDto userPrincipal = sessionFilter.getUserDetail();
		if (userPrincipal == null)
			return ResponseData.error(Messages.UNAUTHORIZED);
		Pageable paging = PageRequest.of(page, size);
		Page<GroupEntity> pageEntity;
		if (StringUtils.isNotBlank(filter)) {
			pageEntity = groupRepository.findByNameContainingIgnoreCase(filter, paging);
		} else {
			pageEntity = groupRepository.findAll(paging);
		}
		return ResponseData.success(pageEntity);
	}

	@Override
	public ResponseData<?> create(GroupCreateRequest req) {
		UserDetailDto userPrincipal = sessionFilter.getUserDetail();
		if (userPrincipal == null)
			return ResponseData.error(Messages.UNAUTHORIZED);
		var optional = groupRepository.findByName(req.getName());
		if (optional.isPresent())
			return ResponseData.error(null);
		GroupEntity entity = GroupEntity.builder().id(UUID.randomUUID().toString()).name(req.getName())
				.createdBy(userPrincipal.getUsername()).createdDate(LocalDateTime.now()).active(true).build();
		groupRepository.save(entity);
		if (req.isAddRole())
			groupRoleService.saveAll(entity.getId(), req.getRoleIds());
		return ResponseData.success(entity.getName());
	}

	@Override
	public ResponseData<?> update(GroupUpdateRequest req) {
		var userPrincipal = sessionFilter.getUserDetail();
		if (userPrincipal == null)
			return ResponseData.unauthorized();
		var optional = groupRepository.findById(req.getId());
		if (optional.isEmpty())
			return ResponseData.error(null);
		var entity = optional.get();
		HelperUtil.updateIfChanged(entity::setName, entity.getName(), req.getName());
		groupRepository.save(entity);
		if (req.isAddRole())
			groupRoleService.updateByResourceUrl(entity.getId(), req.getRoleIds());
		return ResponseData.success(true);
	}

	@Override
	public ResponseData<?> detail(String id) {
		if (StringUtils.isBlank(id))
			return ResponseData.error(Messages.BAD_REQUEST);
		var optional = groupRepository.findById(id);
		if (optional.isEmpty())
			return ResponseData.error(Messages.NOT_FOUND_DATA);
		var entity = optional.get();
		var roleIds = groupRoleService.findRoleIdsByGroupId(entity.getId());
		var response = GroupDetailResponse.builder().id(entity.getId()).name(entity.getName()).roleIds(roleIds).build();
		return ResponseData.success(response);
	}

	@Override
	public ResponseData<?> changeActive(String id, boolean status) {
		if (StringUtils.isBlank(id))
			return ResponseData.error(Messages.BAD_REQUEST);
		var optional = groupRepository.findById(id);
		if (optional.isEmpty())
			return ResponseData.error(Messages.NOT_FOUND_DATA);
		var entity = optional.get();
		entity.setActive(status);
		groupRepository.save(entity);
		return ResponseData.success(true);
	}

	@Override
	public List<GroupEntity> findAllById(List<String> ids) {
		if(ids.isEmpty())
			return new ArrayList<>();
		var entities = groupRepository.findAllById(ids);
		return entities;
	}
}