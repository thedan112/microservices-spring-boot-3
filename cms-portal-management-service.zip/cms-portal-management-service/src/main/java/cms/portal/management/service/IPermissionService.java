package cms.portal.management.service;

import cms.portal.management.dto.ResponseData;
import cms.portal.management.model.request.PermissionRequest;
import cms.portal.management.model.request.PermissionUpdateSelecteRequest;

public interface IPermissionService {

	public ResponseData<?> findAllGroupByDepartmentId(String departmentId);
	
	public ResponseData<?> findAllRoleSelectByGroup(String groupId);
	
	public ResponseData<?> findAllFunctionByGroupIdAndRoleId(PermissionRequest req);
	
	public ResponseData<?> findAllScopeByGroupIdAndRoleId(PermissionRequest req);
	
	public ResponseData<?> findAllUserByGroupIdAndRoleIdAndDepartmentId(PermissionRequest req);
	
	public ResponseData<?> updateChangeSelectMember(PermissionUpdateSelecteRequest req);
	
	public ResponseData<?> updateChangeSelectFunction(PermissionUpdateSelecteRequest req);
	
	public ResponseData<?> updateChangeSelectScope(PermissionUpdateSelecteRequest req);
}