package cms.portal.management.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;

import cms.portal.management.entity.UserEntity;
import cms.portal.management.model.request.UserCreateRequest;
import cms.portal.management.model.response.UserResponse;

@Mapper
public interface UserMapper {

	@Mapping(target = "id", expression = "java(java.util.UUID.randomUUID().toString())")
	@Mapping(target = "token", expression = "java(0)")
	@Mapping(target = "loginFailure", expression = "java(0)")
	@Mapping(target = "active", expression = "java(true)")
	UserEntity createEntity(UserCreateRequest source);

	UserResponse userResponse(UserEntity source);

	@Named("boolParserFromInt")
	default Boolean boolParserFromInt(int bool) {
		return bool == 0 ? false : true;
	}
}