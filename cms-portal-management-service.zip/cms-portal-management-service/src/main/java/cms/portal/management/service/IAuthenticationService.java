package cms.portal.management.service;

import cms.portal.management.dto.ResponseData;
import cms.portal.management.model.request.LoginRequest;

public interface IAuthenticationService {

	public ResponseData<?> login(LoginRequest req);

	public ResponseData<?> logout();
	
	public ResponseData<?> isPermission(String uri);
}
