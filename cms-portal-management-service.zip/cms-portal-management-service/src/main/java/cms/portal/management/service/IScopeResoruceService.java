package cms.portal.management.service;

import java.util.List;

public interface IScopeResoruceService {

	public List<String> findScopeIdByResourceUrl(String resourceUrl);
	
	public void saveAll(String resourceUrl, List<String> scopeIds);
	
	public void updateByResourceUrl(String resourceUrl, List<String> scopeIds);
}