package cms.portal.management.model.request;

import lombok.Data;

@Data
public class PermissionRequest {

	private String departmentId;
	private String groupId;
	private String roleId;
}
