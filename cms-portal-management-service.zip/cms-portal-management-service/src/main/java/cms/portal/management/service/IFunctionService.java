package cms.portal.management.service;

import java.util.List;

import cms.portal.management.dto.ResponseData;
import cms.portal.management.entity.FunctionEntity;
import cms.portal.management.model.request.FunctionCreateRequest;
import cms.portal.management.model.request.FunctionUpdateRequest;

public interface IFunctionService {

	public ResponseData<?> all();

	public ResponseData<?> pages(int page, int size, String filter);

	public ResponseData<?> create(FunctionCreateRequest req);

	public ResponseData<?> update(FunctionUpdateRequest req);

	public ResponseData<?> detail(String id);

	public ResponseData<?> changeActive(String id, boolean status);
	
	public List<FunctionEntity> loadAllByIds(List<String> ids);
}