package cms.portal.management.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "PERMISSION_ENTITY")
public class PermissionEntity {

	@Id
	@Column(name = "ID")
	private String id;
	
	@Column(name = "GROUP_ID")
	private String groupId;
	
	@Column(name = "ROLE_ID")
	private String roleId;
	
	@Column(name = "FUNCTION_ID")
	private String functionId;
}
