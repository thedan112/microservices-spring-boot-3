package cms.portal.management.filter;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import cms.portal.management.dto.UserDetailDto;
import cms.portal.management.repository.UserRepository;

@Service
public class JwtSessionFilter {
	@Autowired
	UserRepository userRepository;

	public UserDetailDto getUserDetail() {
		SecurityContext securityContext = SecurityContextHolder.getContext();
		Authentication authentication = securityContext.getAuthentication();
		if (authentication != null) {
			Object obj = authentication.getPrincipal();
			return obj instanceof UserDetailDto ? (UserDetailDto) obj : null;
		}
		return null;
	}

	public String getSessionUsername() {
		Object obj = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		if (obj instanceof UserDetailDto) {
			return ((UserDetailDto) obj).getUsername();
		}
		return null;
	}

	@Async
	public void processFailureAuthen(String username) {
		if (username != null || username != "") {
			var userEntity = userRepository.findByUsername(username);
			if (userEntity.isEmpty())
				return;
			var ent = userEntity.get();
			int count = ent.getLoginFailure();
			if (ent.isLocked() || count == 5)
				return;
			if (count < 5)
				count++;
			if (count == 5)
				ent.setLocked(true);
			ent.setLoginFailure(count);
			userRepository.save(ent);
		}
	}
}
