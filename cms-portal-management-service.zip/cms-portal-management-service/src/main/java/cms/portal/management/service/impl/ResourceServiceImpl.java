package cms.portal.management.service.impl;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import org.apache.commons.lang3.StringUtils;
import org.mapstruct.factory.Mappers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import cms.portal.management.dto.ResponseData;
import cms.portal.management.dto.SelectItem;
import cms.portal.management.entity.FunctionResourceEntity;
import cms.portal.management.entity.ResourceEntity;
import cms.portal.management.enums.Messages;
import cms.portal.management.enums.ResourceEnum;
import cms.portal.management.filter.JwtSessionFilter;
import cms.portal.management.mapper.ResourceMapper;
import cms.portal.management.model.request.ResourceCreateRequest;
import cms.portal.management.model.request.ResourceUpdateRequest;
import cms.portal.management.repository.FunctionResourceRepository;
import cms.portal.management.repository.ResourceRepository;
import cms.portal.management.service.IResourceService;
import cms.portal.management.service.IScopeResoruceService;
import cms.portal.management.util.HelperUtil;
import jakarta.transaction.Transactional;

@Service
public class ResourceServiceImpl implements IResourceService {
	private final ResourceMapper mapper = Mappers.getMapper(ResourceMapper.class);

	@Autowired
	JwtSessionFilter sessionFilter;

	@Autowired
	ResourceRepository resourceRepository;

	@Autowired
	IScopeResoruceService scopeResoruceService;

	@Autowired
	FunctionResourceRepository functionResourceRepository;

	@Override
	public ResponseData<?> apis() {
		var entities = resourceRepository.findByTypeAndActiveOrderByUrlAsc(ResourceEnum.API.toString(), true);
		if (CollectionUtils.isEmpty(entities))
			return ResponseData.success(null);
		return ResponseData.success(entities.stream().map(s -> new SelectItem<>(s.getUrl(), s.getId())).toList());
	}

	@Override
	public ResponseData<?> views() {
		var entities = resourceRepository.findByTypeAndActiveOrderByUrlAsc(ResourceEnum.VIEW.toString(), true);
		if (CollectionUtils.isEmpty(entities))
			return ResponseData.success(null);
		return ResponseData.success(entities.stream()
				.map(s -> new SelectItem<>(s.getDescription() + ":: " + s.getUrl(), s.getId())).toList());
	}

	@Override
	public ResponseData<?> pages(int page, int size, String filter) {
		Pageable paging = PageRequest.of(page, size, Sort.by(Sort.Direction.DESC, "url"));
		Page<ResourceEntity> pageEntity;
		if (StringUtils.isNotBlank(filter)) {
			pageEntity = resourceRepository.findByUrlContainingIgnoreCase(filter, paging);
		} else {
			pageEntity = resourceRepository.findAll(paging);
		}
		return ResponseData.success(pageEntity);
	}

	@Override
	public ResponseData<?> create(ResourceCreateRequest req) {
		var userPrincipal = sessionFilter.getUserDetail();
		if (userPrincipal == null)
			return ResponseData.unauthorized();
		var optional = resourceRepository.findByUrl(req.getUrl().toLowerCase());
		if (optional.isPresent())
			return ResponseData.error(Messages.RESOURCE_EXISTED);
		var entity = mapper.createEntity(req);
		entity.setCreatedBy(userPrincipal.getUsername());
		resourceRepository.save(entity);
		if (req.isAddScope())
			scopeResoruceService.saveAll(entity.getUrl(), req.getScopeIds());
		return ResponseData.success(true);
	}

	@Override
	public ResponseData<?> detail(String id) {
		if (StringUtils.isBlank(id))
			return ResponseData.error(Messages.BAD_REQUEST);
		var optional = resourceRepository.findById(id);
		if (optional.isEmpty())
			return ResponseData.error(Messages.RESOURCE_NOT_FOUND);
		var entity = optional.get();
		var response = mapper.detailResponse(entity);
		var scopeIds = scopeResoruceService.findScopeIdByResourceUrl(entity.getUrl());
		response.setScopeIds(scopeIds);
		return ResponseData.success(response);
	}

	@Override
	@Transactional
	public ResponseData<?> update(ResourceUpdateRequest req) {
		var userPrincipal = sessionFilter.getUserDetail();
		if (userPrincipal == null)
			return ResponseData.unauthorized();
		var optional = resourceRepository.findById(req.getId());
		if (optional.isEmpty())
			return ResponseData.error(Messages.RESOURCE_NOT_FOUND);
		var entity = optional.get();
		entity.setUpdatedDate(LocalDateTime.now());
		entity.setUpdatedBy(userPrincipal.getUsername());
		boolean isUpdateUrlOrType = false;
		if (!Objects.equals(entity.getUrl(), req.getUrl())) {
			isUpdateUrlOrType = true;
			var existing = resourceRepository.findByUrl(req.getUrl().toLowerCase());
			if (existing.isPresent())
				return ResponseData.error(Messages.RESOURCE_EXISTED);
			entity.setUrl(req.getUrl().toLowerCase());
		}
		HelperUtil.updateIfChanged(entity::setDescription, entity.getDescription(), req.getDescription());
		if (HelperUtil.updateIfChanged(entity::setType, entity.getType(), req.getType()))
			isUpdateUrlOrType = true;
		if (isUpdateUrlOrType)
			updateResourceUrlByResourceId(entity.getId(), entity.getUrl(), entity.getType());
		if (req.isAddScope())
			scopeResoruceService.updateByResourceUrl(entity.getUrl(), req.getScopeIds());
		resourceRepository.save(entity);
		return ResponseData.success(entity.getId());
	}

	@Override
	public ResponseData<?> changeActive(String id, boolean status) {
		var userPrincipal = sessionFilter.getUserDetail();
		if (userPrincipal == null)
			return ResponseData.unauthorized();
		if (StringUtils.isBlank(id))
			return ResponseData.error(Messages.BAD_REQUEST);
		var optional = resourceRepository.findById(id);
		if (optional.isEmpty())
			return ResponseData.error(Messages.RESOURCE_NOT_FOUND);
		var entity = optional.get();
		entity.setActive(status);
		resourceRepository.save(entity);
		return ResponseData.success(true);
	}

	@Override
	public List<ResourceEntity> findAllByIds(List<String> ids) {
		return resourceRepository.findAllById(ids);
	}

	@Override
	public ResourceEntity findById(String id) {
		var optional = resourceRepository.findById(id);
		return optional.isPresent() ? optional.get() : null;
	}
	
	private void updateResourceUrlByResourceId(String resourceId, String resourceUrl, String resourceType) {
		var entities = functionResourceRepository.findByResourceId(resourceId);
		if (!CollectionUtils.isEmpty(entities)) {
			List<FunctionResourceEntity> updateEntities = new ArrayList<>();
			entities.stream().forEach(rs -> {
				rs.setResourceUrl(resourceUrl);
				rs.setResourceType(resourceType);
				updateEntities.add(rs);
			});
			if (!CollectionUtils.isEmpty(updateEntities))
				functionResourceRepository.saveAll(updateEntities);
		}
	}
}