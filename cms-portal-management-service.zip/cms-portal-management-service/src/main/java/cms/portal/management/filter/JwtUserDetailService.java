package cms.portal.management.filter;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import cms.portal.management.dto.UserDetailDto;
import cms.portal.management.repository.DepartmentRepository;
import cms.portal.management.repository.GroupMemberRepository;
import cms.portal.management.repository.GroupRepository;
import cms.portal.management.repository.PolicyRepository;
import cms.portal.management.repository.RoleRepository;
import cms.portal.management.repository.UserRepository;

@Service
public class JwtUserDetailService implements UserDetailsService {

	@Autowired
	UserRepository userRepository;
	
	@Autowired
	RoleRepository roleRepository;
	
	@Autowired
	GroupRepository groupRepository;

	@Autowired
	DepartmentRepository departmentRepository;
	
	@Autowired
	GroupMemberRepository groupMemberRepository;

	@Autowired
	PolicyRepository policyRepository;

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		var optional = userRepository.findByUsername(username);
		if (optional.isEmpty())
			throw new UsernameNotFoundException("user not found with username: " + username);
		Set<String> roles = new HashSet<>();
		Set<String> groups = new HashSet<>();
		var userEntity = optional.get();
//		var userRoles = groupMemberRepository.findByUsernameAndDepartmentId(username, userEntity.getDepartmentId());
//		if (!CollectionUtils.isEmpty(userRoles)) {
//			roleIds = userRoles.stream().map(GroupMemberEntity::getRoleId).collect(Collectors.toSet());
//		}
////		var groupMemberEntities = groupMemberRepository.findByUsername(userEntity.getUsername(),
//				userEntity.getDepartmentId());
//		if (!CollectionUtils.isEmpty(groupMemberEntities)) {
//			roleIds = groupMemberEntities.stream().map(GroupMemberEntity::getRoleId).collect(Collectors.toSet());
//			var policyEntities = policyRepository.findByGroupIdAndRoleIdIn(userEntity.getUsername(), roleIds);
//			if (!CollectionUtils.isEmpty(policyEntities))
//				scopeIds = policyEntities.stream().map(PolicyEntity::getScopeId).collect(Collectors.toSet());
//		}
		return new UserDetailDto(userEntity,new ArrayList<>(), new ArrayList<>());
	}
}