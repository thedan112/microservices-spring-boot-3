package cms.portal.management.service.impl;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import cms.portal.management.entity.ScopeResourceMappingEntity;
import cms.portal.management.repository.ScopeResourceMappingRepository;
import cms.portal.management.service.IScopeResoruceService;

@Service
public class ScopeResourceServiceImpl implements IScopeResoruceService {

	@Autowired
	ScopeResourceMappingRepository scopeResourceMappingRepository;

	@Override
	public List<String> findScopeIdByResourceUrl(String resourceUrl) {
		var entities = scopeResourceMappingRepository.findByResourceUrl(resourceUrl);
		if (CollectionUtils.isEmpty(entities))
			return null;
		return entities.stream().map(ScopeResourceMappingEntity::getScopeId).toList();
	}

	@Override
	public void saveAll(String resourceUrl, List<String> scopeIds) {
		var entities = scopeIds.stream()
				.map(s -> new ScopeResourceMappingEntity(UUID.randomUUID().toString(), s, resourceUrl)).toList();
		if (!CollectionUtils.isEmpty(entities))
			scopeResourceMappingRepository.saveAll(entities);
	}

	@Override
	public void updateByResourceUrl(String resourceUrl, List<String> scopeIds) {
		if (CollectionUtils.isEmpty(scopeIds)) {
			scopeResourceMappingRepository.deleteByResourceUrl(resourceUrl);
		} else {
			var entities = scopeResourceMappingRepository.findByResourceUrl(resourceUrl);
			Set<ScopeResourceMappingEntity> newItems = new HashSet<>();
			Set<String> deleteItems = new HashSet<>();
			if (CollectionUtils.isEmpty(entities)) {
				newItems = scopeIds.stream()
						.map(s -> new ScopeResourceMappingEntity(UUID.randomUUID().toString(), s, resourceUrl))
						.collect(Collectors.toSet());
			} else {
				var existItems = entities.stream().map(ScopeResourceMappingEntity::getResourceUrl)
						.collect(Collectors.toSet());
				newItems = scopeIds.stream().filter(f -> !existItems.contains(f))
						.map(s -> new ScopeResourceMappingEntity(UUID.randomUUID().toString(), s, resourceUrl))
						.collect(Collectors.toSet());
				deleteItems = entities.stream().filter(f -> scopeIds.contains(f.getScopeId())).map(s -> s.getId())
						.collect(Collectors.toSet());
			}
			if (!CollectionUtils.isEmpty(newItems))
				scopeResourceMappingRepository.saveAll(newItems);
			if (!CollectionUtils.isEmpty(deleteItems))
				scopeResourceMappingRepository.deleteAllById(deleteItems);
		}
	}
}