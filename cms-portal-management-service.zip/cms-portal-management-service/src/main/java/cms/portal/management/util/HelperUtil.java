package cms.portal.management.util;

import java.util.Objects;
import java.util.function.Consumer;

public class HelperUtil {

	public static Boolean updateIfChanged(Consumer<String> setter, String oldValue, String newValue) {
	    if (!Objects.equals(oldValue, newValue)) {
	        setter.accept(newValue);
	        return true;
	    }
	    return false;
	}
}
