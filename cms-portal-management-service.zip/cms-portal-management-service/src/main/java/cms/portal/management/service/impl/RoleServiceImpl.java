package cms.portal.management.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.mapstruct.factory.Mappers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import cms.portal.management.dto.ResponseData;
import cms.portal.management.dto.SelectItem;
import cms.portal.management.entity.RoleEntity;
import cms.portal.management.enums.Messages;
import cms.portal.management.filter.JwtSessionFilter;
import cms.portal.management.mapper.RoleMapper;
import cms.portal.management.model.request.RoleActionRequest;
import cms.portal.management.repository.RoleRepository;
import cms.portal.management.service.IRoleService;

@Service
public class RoleServiceImpl implements IRoleService {
	private final RoleMapper mapper = Mappers.getMapper(RoleMapper.class);

	@Autowired
	RoleRepository roleRepository;
	@Autowired
	JwtSessionFilter sessionFilter;

	@Override
	public ResponseData<?> all() {
		var items = roleRepository.findAll().stream().map(s -> new SelectItem<>(s.getName(), s.getId())).toList();
		return ResponseData.success(items);
	}

	@Override
	public ResponseData<?> pages(int page, int size, String filter) {
		Pageable paging = PageRequest.of(page, size);
		Page<RoleEntity> pageEntity;
		if (StringUtils.isNotBlank(filter)) {
			pageEntity = roleRepository.findByNameContainingIgnoreCase(filter, paging);
		} else {
			pageEntity = roleRepository.findAll(paging);
		}
		return ResponseData.success(pageEntity);
	}

	@Override
	public ResponseData<?> create(RoleActionRequest req) {
		var userPrincipal = sessionFilter.getUserDetail();
		if (userPrincipal == null)
			return ResponseData.unauthorized();
		var optional = roleRepository.findByName(req.getName().toUpperCase());
		if (optional.isPresent())
			return ResponseData.error(Messages.ROLE_EXISTED);
		var entity = mapper.createEntity(req);
		entity.setCreatedBy(userPrincipal.getUsername());
		roleRepository.save(entity);
		return ResponseData.success(true);
	}

	@Override
	public ResponseData<?> detail(String id) {
		if (StringUtils.isBlank(id))
			return ResponseData.error(Messages.BAD_REQUEST);
		var optional = roleRepository.findById(id);
		if (optional.isEmpty())
			return ResponseData.error(Messages.ROLE_NOT_FOUND);
		return ResponseData.success(optional.get());
	}

	@Override
	public ResponseData<?> update(RoleActionRequest req) {
		return null;
	}

	@Override
	public List<RoleEntity> findAllById(List<String> ids) {
		if (ids.isEmpty())
			return new ArrayList<>();
		var entities = roleRepository.findAllById(ids);
		return entities;
	}
}
