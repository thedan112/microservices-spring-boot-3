package cms.portal.management.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;

import cms.portal.management.entity.GroupRoleEntity;
import jakarta.transaction.Transactional;

public interface GroupRoleRepository extends JpaRepository<GroupRoleEntity, String>{

	List<GroupRoleEntity> findByGroupId(String groupId);
	
	@Modifying
	@Transactional
	void deleteByGroupId(String groupId);
}