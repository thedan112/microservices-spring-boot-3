package cms.portal.management.service;

import java.util.List;

import cms.portal.management.dto.ResponseData;
import cms.portal.management.entity.RoleEntity;
import cms.portal.management.model.request.RoleActionRequest;

public interface IRoleService {

	public ResponseData<?> all();
	
	public ResponseData<?> pages(int page, int size, String filter);

	public ResponseData<?> create(RoleActionRequest req);

	public ResponseData<?> detail(String id);

	public ResponseData<?> update(RoleActionRequest req);

	public List<RoleEntity> findAllById(List<String> ids);
}