package cms.portal.management.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import cms.portal.management.entity.ScopeEntity;

public interface ScopeRepository extends JpaRepository<ScopeEntity, String> {

	List<ScopeEntity> findByOrderByNameAsc();

	Page<ScopeEntity> findByNameContainingIgnoreCase(String name, Pageable pageable);

	Optional<ScopeEntity> findByName(String name);
}