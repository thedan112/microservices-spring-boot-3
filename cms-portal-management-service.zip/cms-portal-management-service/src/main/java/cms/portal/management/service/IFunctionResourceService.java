package cms.portal.management.service;

import java.util.List;

import cms.portal.management.entity.FunctionResourceEntity;

public interface IFunctionResourceService {

	public List<FunctionResourceEntity> findByFunctionId(String functionId); 
	
	public void updateResourceByFunctionId(String functionId, List<String> resourceIds);
	
	public void updateResourceView(String functionId, String resourceView);
	
	public void saveAll(String functionId, List<String> resourceIds);
}
