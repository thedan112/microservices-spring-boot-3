package cms.portal.management.service.impl;

import org.apache.commons.lang3.StringUtils;
import org.mapstruct.factory.Mappers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import cms.portal.management.dto.ResponseData;
import cms.portal.management.dto.SelectItem;
import cms.portal.management.dto.UserDetailDto;
import cms.portal.management.entity.DepartmentEntity;
import cms.portal.management.enums.Messages;
import cms.portal.management.filter.JwtSessionFilter;
import cms.portal.management.mapper.DepartmentMapper;
import cms.portal.management.model.request.DepartmentCreateRequest;
import cms.portal.management.model.request.DepartmentUpdateRequest;
import cms.portal.management.model.response.DepartmentDetailResponse;
import cms.portal.management.repository.DepartmentRepository;
import cms.portal.management.service.IDepartmentGroupService;
import cms.portal.management.service.IDepartmentService;
import cms.portal.management.util.HelperUtil;
import jakarta.transaction.Transactional;

@Service
public class DepartmentServiceImpl implements IDepartmentService {
	private final DepartmentMapper mapper = Mappers.getMapper(DepartmentMapper.class);

	@Autowired
	DepartmentRepository departmentRepository;
	@Autowired
	IDepartmentGroupService departmentGroupService;
	@Autowired
	JwtSessionFilter sessionFilter;

	@Override
	public ResponseData<?> all() {
		var items = departmentRepository.findAll().stream().map(s -> new SelectItem<>(s.getName(), s.getId())).toList();
		return ResponseData.success(items);
	}

	@Override
	public ResponseData<?> pages(int page, int size, String filter) {
		UserDetailDto userPrincipal = sessionFilter.getUserDetail();
		if (userPrincipal == null)
			return ResponseData.error(Messages.UNAUTHORIZED);
		Pageable paging = PageRequest.of(page, size);
		Page<DepartmentEntity> pageEntity;
		if (StringUtils.isNotBlank(filter)) {
			pageEntity = departmentRepository.findByNameContainingIgnoreCase(filter, paging);
		} else {
			pageEntity = departmentRepository.findAll(paging);
		}
		return ResponseData.success(pageEntity);
	}

	@Override
	@Transactional
	public ResponseData<?> create(DepartmentCreateRequest req) {
		var userPrincipal = sessionFilter.getUserDetail();
		if (userPrincipal == null)
			return ResponseData.unauthorized();
		var optional = departmentRepository.findByName(req.getName().toUpperCase());
		if (optional.isPresent())
			return ResponseData.error(Messages.ROLE_EXISTED);
		var entity = mapper.createEntity(req);
		entity.setCreatedBy(userPrincipal.getUsername());
		departmentRepository.save(entity);
		if (req.isAddGroup())
			departmentGroupService.saveAllByDepartmentId(entity.getId(), req.getGroupIds());
		return ResponseData.success(true);
	}

	@Override
	public ResponseData<?> detail(String id) {
		if (StringUtils.isBlank(id))
			return ResponseData.error(Messages.BAD_REQUEST);
		var optional = departmentRepository.findById(id);
		if (optional.isEmpty())
			return ResponseData.error(Messages.ROLE_NOT_FOUND);
		var entity = optional.get();
		var groupIds = departmentGroupService.findGroupIdsByDepartmentId(entity.getId());
		var response = DepartmentDetailResponse.builder().id(entity.getId()).name(entity.getName())
				.description(entity.getDescription()).groupIds(groupIds).build();
		return ResponseData.success(response);
	}

	@Override
	@Transactional
	public ResponseData<?> update(DepartmentUpdateRequest req) {
		var userPrincipal = sessionFilter.getUserDetail();
		if (userPrincipal == null)
			return ResponseData.unauthorized();
		var optional = departmentRepository.findById(req.getId());
		if (optional.isEmpty())
			return ResponseData.error(Messages.DEPARTMENT_NOT_FOUND);
		var entity = optional.get();
		HelperUtil.updateIfChanged(entity::setName, entity.getName(), req.getName());
		HelperUtil.updateIfChanged(entity::setDescription, entity.getDescription(), req.getDescription());
		departmentRepository.save(entity);
		if (req.isAddGroup())
			departmentGroupService.updateByDepartmentIdAndGroupIdIn(entity.getId(), req.getGroupIds());
		return ResponseData.success(true);
	}
}