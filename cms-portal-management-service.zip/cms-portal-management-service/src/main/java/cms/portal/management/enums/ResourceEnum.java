package cms.portal.management.enums;

public enum ResourceEnum {

	API,
	VIEW,
}
