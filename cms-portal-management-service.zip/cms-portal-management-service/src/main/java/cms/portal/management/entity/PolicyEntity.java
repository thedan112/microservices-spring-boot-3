package cms.portal.management.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "POLICY_ENTITY")
public class PolicyEntity {

	@Id
	@Column(name = "ID")
	private String id;
	
	@Column(name = "GROUP_ID")
	private String groupId;

	@Column(name = "ROLE_ID")
	private String roleId;
	
	@Column(name = "SCOPE_ID")
	private String scopeId;
}