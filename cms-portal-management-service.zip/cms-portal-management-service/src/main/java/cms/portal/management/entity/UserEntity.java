package cms.portal.management.entity;

import java.time.LocalDateTime;
import java.util.Date;

import org.hibernate.annotations.CreationTimestamp;

import com.fasterxml.jackson.annotation.JsonProperty;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "USER_ENTITY")
public class UserEntity {

	@Id
	@Column(name = "id", nullable = false)
	private String id;

	@Column(name = "USERNAME")
	private String username;

	@Column(name = "PASSWORD")
	@JsonProperty
	private String password;
	
	@Column(name = "email")
	private String email;

	@Column(name = "EMPLOYEE_CODE")
	private String employeeCode;

	@Column(name = "FULL_NAME")
	private String fullName;
	
	@Column(name = "type")
	private String type;
	
	@Column(name = "DEPARTMENT_ID")
	private String departmentId;
	
	@Column(name = "LOGIN_AT")
	private Date loginAt;

	@Column(name = "CREATED_BY")
	private String createdBy;
	
	@CreationTimestamp
	@Column(name = "CREATED_DATE")
	private LocalDateTime createdDate;
	
	@Column(name = "UPDATED_BY")
	private String updatedBy;
	
	@Column(name = "UPDATED_DATE")
	private LocalDateTime updatedDate;

	@Column(name = "active")
	private boolean active;

	@Column(name = "locked")
	private boolean locked;

	@Column(name = "token")
	@JsonProperty
	private int token;
	
	@Column(name = "LOGIN_FAILURE")
	private int loginFailure;
}
