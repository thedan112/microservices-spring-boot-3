package cms.portal.management.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import cms.portal.management.model.request.FunctionCreateRequest;
import cms.portal.management.model.request.FunctionUpdateRequest;
import cms.portal.management.service.IFunctionService;

@RestController
@RequestMapping(value = "/function")
public class FunctionController {

	@Autowired
	IFunctionService functionService;

	@GetMapping(value = "/all")
	public ResponseEntity<?> all() {
		return ResponseEntity.ok(functionService.all());
	}

	@PostMapping(value = "/pages")
	public ResponseEntity<?> pages(@RequestParam(required = false, defaultValue = "0") int page,
			@RequestParam(required = false, defaultValue = "10") int size,
			@RequestParam(required = false, value = "name") String name) {
		return ResponseEntity.ok(functionService.pages(page, size, name));
	}

	@PostMapping(value = "/create")
	public ResponseEntity<?> create(@RequestBody FunctionCreateRequest req) {
		return ResponseEntity.ok(functionService.create(req));
	}

	@GetMapping(value = "/detail")
	public ResponseEntity<?> detail(@RequestParam(required = false) String id) {
		return ResponseEntity.ok(functionService.detail(id));
	}

	@PostMapping(value = "/update")
	public ResponseEntity<?> update(@RequestBody FunctionUpdateRequest req) {
		return ResponseEntity.ok(functionService.update(req));
	}

	@PostMapping(value = "/change-active")
	public ResponseEntity<?> changeActive(@RequestParam(value = "id") String id,
			@RequestParam(value = "status") boolean status) {
		return ResponseEntity.ok(functionService.changeActive(id, status));
	}
}
