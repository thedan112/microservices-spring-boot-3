package cms.portal.management.repository;

import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import cms.portal.management.entity.UserEntity;
import jakarta.transaction.Transactional;

public interface UserRepository extends JpaRepository<UserEntity, String> {

	Optional<UserEntity> findByUsername(String username);

	Optional<UserEntity> findByEmail(String email);

	Page<UserEntity> findByDepartmentId(String departmentId, Pageable pageable);
	
	Page<UserEntity> findByEmailContainingIgnoreCase(String email, Pageable pageable);

	Page<UserEntity> findByDepartmentIdAndTypeOrderByEmailAsc(String departmentId, String type, Pageable pageable);

	@Modifying
	@Transactional
	@Query("UPDATE UserEntity u SET u.token=?1  WHERE u.username =?2")
	void updateTokenByUsername(int token, String username);
}