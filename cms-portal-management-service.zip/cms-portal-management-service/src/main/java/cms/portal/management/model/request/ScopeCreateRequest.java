package cms.portal.management.model.request;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class ScopeCreateRequest {

	@NotBlank(message = "Name is mandatory")
	private String name;
}
