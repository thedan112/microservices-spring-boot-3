package cms.portal.management.service;

import java.util.List;

import cms.portal.management.dto.ResponseData;
import cms.portal.management.entity.ScopeEntity;
import cms.portal.management.model.request.ScopeCreateRequest;
import cms.portal.management.model.request.ScopeUpdateRequest;

public interface IScopeService {

	public ResponseData<?> all();

	public ResponseData<?> pages(int page, int size, String filter);

	public ResponseData<?> create(ScopeCreateRequest req);

	public ResponseData<?> update(ScopeUpdateRequest req);

	public ResponseData<?> detail(String id);
	
	public List<ScopeEntity> loadAllByIds(List<String> ids);
}
