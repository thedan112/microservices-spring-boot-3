package cms.portal.management.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import cms.portal.management.model.request.ScopeCreateRequest;
import cms.portal.management.model.request.ScopeUpdateRequest;
import cms.portal.management.service.IScopeService;

@RestController
@RequestMapping(value = "/scope")
public class ScopeController {

	@Autowired
	IScopeService service;

	@GetMapping(value = "/all")
	public ResponseEntity<?> all() {
		return ResponseEntity.ok(service.all());
	}

	@PostMapping(value = "/pages")
	public ResponseEntity<?> pages(@RequestParam(required = false, defaultValue = "0") int page,
			@RequestParam(required = false, defaultValue = "10") int size,
			@RequestParam(required = false, value = "name") String filter) {
		return ResponseEntity.ok(service.pages(page, size, filter));
	}

	@PostMapping(value = "/create")
	public ResponseEntity<?> create(@RequestBody ScopeCreateRequest req) {
		return ResponseEntity.ok(service.create(req));
	}

	@GetMapping(value = "/detail")
	public ResponseEntity<?> detail(@RequestParam(required = false, value = "id") String id) {
		return ResponseEntity.ok(service.detail(id));
	}

	@PostMapping(value = "/update")
	public ResponseEntity<?> update(@RequestBody ScopeUpdateRequest req) {
		return ResponseEntity.ok(service.update(req));
	}
}