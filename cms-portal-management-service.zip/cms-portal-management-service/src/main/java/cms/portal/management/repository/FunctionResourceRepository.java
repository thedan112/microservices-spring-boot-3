package cms.portal.management.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import cms.portal.management.entity.FunctionResourceEntity;

public interface FunctionResourceRepository extends JpaRepository<FunctionResourceEntity, String> {

	List<FunctionResourceEntity> findByFunctionId(String functionId);

	List<FunctionResourceEntity> findByResourceId(String resourceId);
	
	List<FunctionResourceEntity> findByFunctionIdAndResourceType(String functionId, String resourceType);

	List<FunctionResourceEntity> findByResourceUrl(String resoruceUrl);
	
	Optional<FunctionResourceEntity> findByFunctionIdAndResourceId(String functionId, String resourceId);
}