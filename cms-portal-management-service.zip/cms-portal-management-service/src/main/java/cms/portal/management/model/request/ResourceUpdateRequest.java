package cms.portal.management.model.request;

import java.util.List;

import lombok.Data;

@Data
public class ResourceUpdateRequest {

	private String id;
	private String url;
	private String description;
	private String type;
	private boolean addScope;
	private List<String> scopeIds;
}
