package cms.portal.management.exception;

import java.io.IOException;

import org.springframework.http.HttpStatus;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.web.client.ResponseErrorHandler;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class RestTemplateException implements ResponseErrorHandler {

	@Override
	public boolean hasError(ClientHttpResponse response) throws IOException {
		return response.getStatusCode().is4xxClientError() || response.getStatusCode().is5xxServerError();
	}

	@Override
	public void handleError(ClientHttpResponse response) throws IOException {
		if (response.getStatusCode().is5xxServerError()) {
			log.error("Server Error by Status {}, Message: {}", response.getStatusCode(), response.getBody());
		} else if (response.getStatusCode().is4xxClientError()) {
			if (response.getStatusCode() == HttpStatus.NOT_FOUND) {
				log.error("Server Error by Status {}, Message: {}", response.getStatusCode(), "Not found resource");
				return;
			}
			log.error("Server Error by Status {}, Message: {}", response.getStatusCode(), "Not implement");
		}
	}
}
