package cms.portal.management.model.request;

import lombok.Data;

@Data
public class ScopeUpdateRequest {

	private String id;
	private String name;
}