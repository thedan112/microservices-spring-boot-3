package cms.portal.management.model.request;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class UserCreateRequest {

	@NotBlank(message = "Email bắt buộc nhập")
	private String email;
	@NotBlank(message = "Tên người dùng bắt buộc nhập")
	private String username;
	@NotBlank(message = "Họ và tên bắt buộc nhập")
	private String fullName;
	@NotBlank(message = "Mã số nhân vien bắt buộc nhập")
	private String employeeCode;
	private String departmentId;
	@NotBlank(message = "Loại bắt buộc nhập")
	private String type;
}
