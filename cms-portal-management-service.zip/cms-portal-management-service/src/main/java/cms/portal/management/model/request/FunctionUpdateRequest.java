package cms.portal.management.model.request;

import java.util.List;

import lombok.Data;

@Data
public class FunctionUpdateRequest {

	private String id;
	private String name;
	private String description;
	private boolean addResource;
	private List<String> resourceIds;
	private String resourceView;
}
