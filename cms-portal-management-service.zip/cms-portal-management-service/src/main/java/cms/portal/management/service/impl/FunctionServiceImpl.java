package cms.portal.management.service.impl;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import org.apache.commons.lang3.StringUtils;
import org.mapstruct.factory.Mappers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import cms.portal.management.dto.ResponseData;
import cms.portal.management.dto.SelectItem;
import cms.portal.management.entity.FunctionEntity;
import cms.portal.management.enums.Messages;
import cms.portal.management.enums.ResourceEnum;
import cms.portal.management.filter.JwtSessionFilter;
import cms.portal.management.mapper.FunctionMapper;
import cms.portal.management.model.request.FunctionCreateRequest;
import cms.portal.management.model.request.FunctionUpdateRequest;
import cms.portal.management.repository.FunctionRepository;
import cms.portal.management.service.IFunctionResourceService;
import cms.portal.management.service.IFunctionService;
import cms.portal.management.util.HelperUtil;

@Service
public class FunctionServiceImpl implements IFunctionService {
	private final FunctionMapper mapper = Mappers.getMapper(FunctionMapper.class);

	@Autowired
	JwtSessionFilter sessionFilter;

	@Autowired
	FunctionRepository functionRepository;

	@Autowired
	IFunctionResourceService functionResourceService;

	@Override
	public ResponseData<?> all() {
		var items = functionRepository.findAll().stream().filter(f -> f.getActive())
				.map(s -> new SelectItem<>(s.getName(), s.getId())).toList();
		return ResponseData.success(items);
	}

	@Override
	public ResponseData<?> pages(int page, int size, String filter) {
		Pageable paging = PageRequest.of(page, size, Sort.by(Sort.Direction.DESC, "createdDate"));
		Page<FunctionEntity> pageEntity;
		if (StringUtils.isNotBlank(filter)) {
			pageEntity = functionRepository.findByNameContainingIgnoreCase(filter, paging);
		} else {
			pageEntity = functionRepository.findAll(paging);
		}
		return ResponseData.success(pageEntity);
	}

	@Override
	public ResponseData<?> create(FunctionCreateRequest req) {
		var userPrincipal = sessionFilter.getUserDetail();
		if (userPrincipal == null)
			return ResponseData.unauthorized();
		var optional = functionRepository.findByName(req.getName().toUpperCase());
		if (optional.isPresent())
			return ResponseData.error(Messages.FUNCTION_EXISTED);
		var entity = mapper.createEntity(req);
		entity.setCreatedBy(userPrincipal.getUsername());
		functionRepository.save(entity);
		if (req.isAddResource()) {
			req.getResourceIds().add(req.getResourceView());
			functionResourceService.saveAll(entity.getId(), req.getResourceIds());
		}
		return ResponseData.success(true);
	}

	@Override
	public ResponseData<?> update(FunctionUpdateRequest req) {
		var userPrincipal = sessionFilter.getUserDetail();
		if (userPrincipal == null)
			return ResponseData.unauthorized();
		var optional = functionRepository.findById(req.getId());
		if (optional.isEmpty())
			return ResponseData.error(Messages.RESOURCE_NOT_FOUND);
		var entity = optional.get();
		entity.setUpdatedDate(LocalDateTime.now());
		entity.setUpdatedBy(userPrincipal.getUsername());
		if (!Objects.equals(entity.getName(), req.getName())) {
			var existing = functionRepository.findByName(req.getName().toUpperCase());
			if (existing.isPresent())
				return ResponseData.error(Messages.FUNCTION_EXISTED);
			entity.setName(req.getName().toLowerCase());
		}
		HelperUtil.updateIfChanged(entity::setDescription, entity.getDescription(), req.getDescription());
		functionRepository.save(entity);
		functionResourceService.updateResourceView(req.getId(), req.getResourceView());
		if (req.isAddResource())
			functionResourceService.updateResourceByFunctionId(entity.getId(), req.getResourceIds());
		return ResponseData.success(entity.getId());
	}

	@Override
	public ResponseData<?> detail(String id) {
		if (StringUtils.isBlank(id))
			return ResponseData.error(Messages.BAD_REQUEST);
		var optional = functionRepository.findById(id);
		if (optional.isEmpty())
			return ResponseData.error(Messages.FUNCTION_NOT_FOUND);
		var entity = optional.get();
		var res = mapper.funtionDetailResponse(entity);
		var resources = functionResourceService.findByFunctionId(id);
		List<String> resourceIds = new ArrayList<>();
		if (!CollectionUtils.isEmpty(resources)) {
			resources.stream().forEach(rs -> {
				if (ResourceEnum.VIEW.toString().equals(rs.getResourceType())
						&& StringUtils.isBlank(res.getResourceView())) {
					res.setResourceView(rs.getResourceId());
				} else {
					resourceIds.add(rs.getResourceId());
				}
			});
		}
		res.setResourceIds(resourceIds);
		return ResponseData.success(res);
	}

	@Override
	public ResponseData<?> changeActive(String id, boolean status) {
		var userPrincipal = sessionFilter.getUserDetail();
		if (userPrincipal == null)
			return ResponseData.unauthorized();
		if (StringUtils.isBlank(id))
			return ResponseData.error(Messages.BAD_REQUEST);
		var optional = functionRepository.findById(id);
		if (optional.isEmpty())
			return ResponseData.error(Messages.FUNCTION_NOT_FOUND);
		var entity = optional.get();
		entity.setActive(status);
		functionRepository.save(entity);
		return ResponseData.success(true);
	}
	@Override
	public List<FunctionEntity> loadAllByIds(List<String> ids) {
		return functionRepository.findAllById(ids);
	}
}