package cms.portal.management.repository;

import java.util.List;
import java.util.Set;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;

import cms.portal.management.entity.GroupMemberEntity;
import jakarta.transaction.Transactional;

public interface GroupMemberRepository extends JpaRepository<GroupMemberEntity, String>{

	List<GroupMemberEntity> findByGroupIdAndRoleIdAndDepartmentId(String groupId, String roleId, String departmentId);
	
	List<GroupMemberEntity> findByGroupIdAndRoleIdIn(String groupId, Set<String> roleIds);
	
	List<GroupMemberEntity> findByUsernameAndDepartmentId(String username, String departmentId);
	
	@Modifying
	@Transactional
	void deleteByGroupIdAndRoleId(String groupId, String roleId);
}
