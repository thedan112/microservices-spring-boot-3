package cms.portal.management.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import cms.portal.management.entity.ResourceEntity;

public interface ResourceRepository extends JpaRepository<ResourceEntity, String>{

	Page<ResourceEntity> findByUrlContainingIgnoreCase(String url, Pageable pageable);
	
	Optional<ResourceEntity> findByUrl(String url);
	
//	List<ResourceEntity> findByActiveOrderByUrlAsc(Boolean active);
	
	List<ResourceEntity> findByTypeAndActiveOrderByUrlAsc(String type, Boolean active);
}