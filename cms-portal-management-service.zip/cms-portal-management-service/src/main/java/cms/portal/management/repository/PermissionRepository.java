package cms.portal.management.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;

import cms.portal.management.entity.PermissionEntity;
import jakarta.transaction.Transactional;

public interface PermissionRepository extends JpaRepository<PermissionEntity, String> {

	List<PermissionEntity> findAllByGroupIdAndRoleId(String groupId, String roleId);
	
	@Modifying
	@Transactional
	void deleteByGroupIdAndRoleId(String groupId, String roleId);
}