package cms.portal.management.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;

import cms.portal.management.entity.DepartmentGroupMappingEntity;

public interface DepartmentGroupMappingRepository extends JpaRepository<DepartmentGroupMappingEntity, String> {

	List<DepartmentGroupMappingEntity> findByDepartmentId(String departmentId);
	
	@Modifying
	void deleteByDepartmentId(String departmentId);
}
