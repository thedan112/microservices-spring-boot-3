package cms.portal.management.model.response;

import java.util.Date;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
@NotBlank
public class UserResponse {

	private String id;
	private String username;
	private String employeeCode;
	private String fullName;
	private String departmentId;
	private Date loginAt;
	private Date createdDate;
	private boolean active;
	private boolean locked;
	private String email;
	private String type;
	private int loginFailure;
}
