package cms.portal.management.util;

import java.io.InputStream;
import java.lang.reflect.Field;
import java.lang.reflect.Type;
import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.apache.commons.collections4.IteratorUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;

import cms.portal.management.dto.ExcelPos;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class ExcelUtil {

	private static final String STRING = "java.lang.String";
	private static final String BIGDECIMAL = "java.math.BigDecimal";
	private static final String LONG = "java.lang.Long";
	private static final String INTEGER = "java.lang.Integer";
	private static final String FLOAT = "java.lang.Float";
	private static final String DOUBLE = "java.lang.Double";
	private static final String DATE = "java.util.Date";

	public static boolean isValidExtension(String fileName) {
		if (fileName.endsWith("xls") || fileName.endsWith("xlsx"))
			return false;
		return true;
	}

	public static <T> List<T> upload(Workbook workbook, InputStream is, int limit, Class<T> clazz) {
		List<T> data = new ArrayList<>();
		try {
			Sheet sheet = workbook.getSheetAt(0);
			List<Row> rowList = IteratorUtils.toList(sheet.rowIterator());
			for (int r = 1; r <= sheet.getLastRowNum(); r++) {
				if (isEmptyRow(sheet.getRow(r)))
					continue;
				T object = clazz.getConstructor().newInstance();
				for (Field f : clazz.getDeclaredFields()) {
					f.setAccessible(true);
					if (f.isAnnotationPresent(ExcelPos.class)) {
						Integer cellPosition = f.getAnnotation(ExcelPos.class).value() - 1; // position
						if (rowList.get(r).getCell(cellPosition) != null
								&& rowList.get(r).getCell(cellPosition).toString() != "") {
							Type type = f.getType();
							Cell cell = rowList.get(r).getCell(cellPosition);
							switch (type.getTypeName()) {
							case STRING:
								f.set(object, readCellContent(cell));
								break;
							case INTEGER:
								f.set(object, Integer.valueOf(readCellContent(cell)));
								break;
							case LONG:
								f.set(object, Long.valueOf(readCellContent(cell)));
								break;
							case FLOAT:
								f.set(object, Float.valueOf(readCellContent(cell)));
								break;
							case DOUBLE:
								f.set(object, Double.valueOf(readCellContent(cell)));
								break;
							case BIGDECIMAL:
								f.set(object, new BigDecimal(readCellContent(cell)));
								break;
							case DATE:
								f.set(object, readCellContent(cell));
								break;
							default:
								f.set(object, String.valueOf(readCellContent(cell)));
								break;
							}
						}
					}
				}
				data.add(object);
			}
		} catch (Exception e) {
			log.error("Process upload excel Error: {}", e.getMessage());
		}
		return data;
	}

//	@SuppressWarnings("rawtypes")
//	public static String readCellContent(Cell cell, Class clazz) {
//		String value = StringUtils.EMPTY;
//		switch (cell.getCellType()) {
//		case STRING:
//			value = cell.getStringCellValue().isEmpty() ? "" : cell.getStringCellValue().trim();
//			break;
//		case NUMERIC:
//			value = DateUtil.isCellDateFormatted(cell) ? cellDateString(cell.getDateCellValue())
//					: numberFormatString(cell.getNumericCellValue());
//			break;
//		case BOOLEAN:
//			value = cell.getBooleanCellValue() + value;
//			break;
//		case FORMULA:
//			value = cell.getCellFormula() + "";
//			break;
//		case BLANK:
//			break;
//		default:
//			break;
//		}
//		return value;
//	}

	public static String readCellContent(Cell cell) {
		return switch (cell.getCellType()) {
		case STRING -> Optional.ofNullable(cell.getStringCellValue()).orElse("").trim();
		case NUMERIC -> DateUtil.isCellDateFormatted(cell) ? cellDateString(cell.getDateCellValue())
				: numberFormatString(cell.getNumericCellValue());
		case BOOLEAN -> String.valueOf(cell.getBooleanCellValue());
		case FORMULA -> cell.getCellFormula();
		default -> StringUtils.EMPTY;
		};
	}

	private static String cellDateString(Date date) {
		if (date == null)
			return StringUtils.EMPTY;
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
		return sdf.format(date);
	}

	private static String numberFormatString(Double number) {
		if (number == null)
			return StringUtils.EMPTY;
		DecimalFormat decimalFormat = new DecimalFormat("#.############");
		String rs = decimalFormat.format(number);
		return rs;
	}

	private static boolean isEmptyRow(Row r) {
		if (r == null)
			return true;
		for (int i = 0; i < r.getLastCellNum(); i++) {
			if (r.getCell(i) != null && !r.getCell(i).getCellType().equals(CellType.BLANK))
				return false;
		}
		return true;
	}
}