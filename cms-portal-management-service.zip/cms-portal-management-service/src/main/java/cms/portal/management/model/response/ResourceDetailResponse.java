package cms.portal.management.model.response;

import java.util.Date;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ResourceDetailResponse {

	private String id;
	private String url;
	private String description;
	private String type;
	private Boolean active;
	private String createdBy;
	private Date createdDate;
	private String updatedBy;
	private Date updatedDate;
	private List<String> scopeIds;
}
