package cms.portal.management.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;

import cms.portal.management.entity.ScopeResourceMappingEntity;

public interface ScopeResourceMappingRepository extends JpaRepository<ScopeResourceMappingEntity, String>{

	List<ScopeResourceMappingEntity> findByResourceUrl(String resourceUrl);
	
	@Modifying
	void deleteByResourceUrl(String resourceUrl);
}