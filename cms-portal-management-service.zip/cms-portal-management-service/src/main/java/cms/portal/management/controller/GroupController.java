package cms.portal.management.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import cms.portal.management.model.request.GroupCreateRequest;
import cms.portal.management.model.request.GroupUpdateRequest;
import cms.portal.management.service.IGroupService;

@RestController
@RequestMapping(value = "/group")
public class GroupController {

	@Autowired
	IGroupService groupService;

	@GetMapping(value = "/all")
	public ResponseEntity<?> all() {
		return ResponseEntity.ok(groupService.all());
	}

	@PostMapping(value = "/pages")
	public ResponseEntity<?> pages(@RequestParam(required = false, defaultValue = "0") int page,
			@RequestParam(required = false, defaultValue = "10") int size,
			@RequestParam(required = false, value = "name") String filter) {
		return ResponseEntity.ok(groupService.pages(page, size, filter));
	}

	@PostMapping(value = "/create")
	public ResponseEntity<?> create(@RequestBody GroupCreateRequest req) {
		return ResponseEntity.ok(groupService.create(req));
	}

	@GetMapping(value = "/detail")
	public ResponseEntity<?> detail(@RequestParam(required = false, value = "id") String id) {
		return ResponseEntity.ok(groupService.detail(id));
	}

	@PostMapping(value = "/update")
	public ResponseEntity<?> update(@RequestBody GroupUpdateRequest req) {
		return ResponseEntity.ok(groupService.update(req));
	}

	@PostMapping(value = "/change-active")
	public ResponseEntity<?> changeActive(@RequestParam(value = "id") String id,
			@RequestParam(value = "status") boolean status) {
		return ResponseEntity.ok(groupService.changeActive(id, status));
	}
}