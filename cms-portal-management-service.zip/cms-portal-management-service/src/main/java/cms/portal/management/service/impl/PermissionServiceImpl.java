package cms.portal.management.service.impl;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import cms.portal.management.dto.ResponseData;
import cms.portal.management.dto.SelectItem;
import cms.portal.management.entity.GroupMemberEntity;
import cms.portal.management.entity.PermissionEntity;
import cms.portal.management.entity.PolicyEntity;
import cms.portal.management.enums.Messages;
import cms.portal.management.model.request.PermissionRequest;
import cms.portal.management.model.request.PermissionUpdateSelecteRequest;
import cms.portal.management.repository.GroupMemberRepository;
import cms.portal.management.repository.PermissionRepository;
import cms.portal.management.repository.PolicyRepository;
import cms.portal.management.service.IDepartmentGroupService;
import cms.portal.management.service.IFunctionService;
import cms.portal.management.service.IGroupRoleService;
import cms.portal.management.service.IGroupService;
import cms.portal.management.service.IPermissionService;
import cms.portal.management.service.IRoleService;
import cms.portal.management.service.IScopeService;
import cms.portal.management.service.IUserService;

@Service
public class PermissionServiceImpl implements IPermissionService {

	@Autowired
	PermissionRepository permissionRepository;

	@Autowired
	PolicyRepository policyRepository;

	@Autowired
	IFunctionService functionService;

	@Autowired
	IScopeService scopeService;

	@Autowired
	IDepartmentGroupService departmentGroupService;

	@Autowired
	IGroupRoleService groupRoleService;

	@Autowired
	GroupMemberRepository groupMemberRepository;

	@Autowired
	IGroupService groupService;

	@Autowired
	IRoleService roleService;

	@Autowired
	IUserService userService;

	@Override
	public ResponseData<?> findAllGroupByDepartmentId(String departmentId) {
		if (StringUtils.isBlank(departmentId))
			return ResponseData.error(Messages.BAD_REQUEST);
		var groupIds = departmentGroupService.findGroupIdsByDepartmentId(departmentId);
		if (CollectionUtils.isEmpty(groupIds))
			return ResponseData.success(null);
		var groups = groupService.findAllById(groupIds);
		if (CollectionUtils.isEmpty(groups))
			return ResponseData.success(null);
		return ResponseData.success(groups.stream().map(s ->  new SelectItem<>(s.getName(), s.getId())));
	}

	@Override
	public ResponseData<?> findAllRoleSelectByGroup(String groupId) {
		if (StringUtils.isBlank(groupId))
			return ResponseData.error(Messages.BAD_REQUEST);
		var roleIds = groupRoleService.findRoleIdsByGroupId(groupId);
		if (CollectionUtils.isEmpty(roleIds))
			return ResponseData.success(null);
		var roles = roleService.findAllById(roleIds);
		if (CollectionUtils.isEmpty(roles))
			return ResponseData.success(null);
		return ResponseData.success(roles.stream().map(s -> new SelectItem<>(s.getName(), s.getId())).toList());
	}

	@Override
	public ResponseData<?> findAllFunctionByGroupIdAndRoleId(PermissionRequest req) {
		if (StringUtils.isAllBlank(req.getGroupId()) || StringUtils.isAllBlank(req.getRoleId()))
			return ResponseData.error(Messages.BAD_REQUEST);
		var permissions = permissionRepository.findAllByGroupIdAndRoleId(req.getGroupId(), req.getRoleId());
		if (CollectionUtils.isEmpty(permissions))
			return ResponseData.success(null);
		var functionIds = permissions.stream().map(PermissionEntity::getFunctionId).toList();
		var functionEntities = functionService.loadAllByIds(functionIds);
		return ResponseData.success(functionEntities);
	}

	@Override
	public ResponseData<?> findAllScopeByGroupIdAndRoleId(PermissionRequest req) {
		if (StringUtils.isAllBlank(req.getGroupId()) || StringUtils.isAllBlank(req.getRoleId()))
			return ResponseData.error(Messages.BAD_REQUEST);
		var policies = policyRepository.findAllByGroupIdAndRoleId(req.getGroupId(), req.getRoleId());
		if (CollectionUtils.isEmpty(policies))
			return ResponseData.success(null);
		var scopIds = policies.stream().map(PolicyEntity::getScopeId).toList();
		var scopEntities = scopeService.loadAllByIds(scopIds);
		return ResponseData.success(scopEntities);
	}

	@Override
	public ResponseData<?> updateChangeSelectFunction(PermissionUpdateSelecteRequest req) {
		if (CollectionUtils.isEmpty(req.getItems())) {
			permissionRepository.deleteByGroupIdAndRoleId(req.getGroupId(), req.getRoleId());
		} else {
			var entities = permissionRepository.findAllByGroupIdAndRoleId(req.getGroupId(), req.getRoleId());
			Set<PermissionEntity> newItems = new HashSet<>();
			Set<String> deleteItems = new HashSet<>();
			if (CollectionUtils.isEmpty(entities)) {
				newItems = req.getItems().stream().map(
						s -> new PermissionEntity(UUID.randomUUID().toString(), req.getGroupId(), req.getRoleId(), s))
						.collect(Collectors.toSet());
			} else {
				var existItems = entities.stream().map(PermissionEntity::getFunctionId).collect(Collectors.toSet());
				newItems = req.getItems().stream().filter(f -> !existItems.contains(f)).map(
						s -> new PermissionEntity(UUID.randomUUID().toString(), req.getGroupId(), req.getRoleId(), s))
						.collect(Collectors.toSet());
				deleteItems = entities.stream().filter(f -> !req.getItems().contains(f.getFunctionId()))
						.map(s -> s.getId()).collect(Collectors.toSet());
			}
			if (!CollectionUtils.isEmpty(newItems))
				permissionRepository.saveAll(newItems);
			if (!CollectionUtils.isEmpty(deleteItems))
				permissionRepository.deleteAllById(deleteItems);
		}
		return ResponseData.success(true);
	}

	@Override
	public ResponseData<?> updateChangeSelectScope(PermissionUpdateSelecteRequest req) {
		if (CollectionUtils.isEmpty(req.getItems())) {
			policyRepository.deleteByGroupIdAndRoleId(req.getGroupId(), req.getRoleId());
		} else {
			var entities = policyRepository.findAllByGroupIdAndRoleId(req.getGroupId(), req.getRoleId());
			Set<PolicyEntity> newItems = new HashSet<>();
			Set<String> deleteItems = new HashSet<>();
			if (CollectionUtils.isEmpty(entities)) {
				newItems = req.getItems().stream()
						.map(s -> new PolicyEntity(UUID.randomUUID().toString(), req.getGroupId(), req.getRoleId(), s))
						.collect(Collectors.toSet());
			} else {
				var existItems = entities.stream().map(PolicyEntity::getScopeId).collect(Collectors.toSet());
				newItems = req.getItems().stream().filter(f -> !existItems.contains(f))
						.map(s -> new PolicyEntity(UUID.randomUUID().toString(), req.getGroupId(), req.getRoleId(), s))
						.collect(Collectors.toSet());
				deleteItems = entities.stream().filter(f -> !req.getItems().contains(f.getScopeId()))
						.map(s -> s.getId()).collect(Collectors.toSet());
			}
			if (!CollectionUtils.isEmpty(newItems))
				policyRepository.saveAll(newItems);
			if (!CollectionUtils.isEmpty(deleteItems))
				policyRepository.deleteAllById(deleteItems);
		}
		return ResponseData.success(true);
	}

	@Override
	public ResponseData<?> findAllUserByGroupIdAndRoleIdAndDepartmentId(PermissionRequest req) {
		if (StringUtils.isAllBlank(req.getGroupId()) || StringUtils.isAllBlank(req.getRoleId()))
			return ResponseData.error(Messages.BAD_REQUEST);
		var members = groupMemberRepository.findByGroupIdAndRoleIdAndDepartmentId(req.getGroupId(), req.getRoleId(),
				req.getDepartmentId());
		if (CollectionUtils.isEmpty(members))
			return ResponseData.success(null);
		return ResponseData
				.success(members.stream().map(s -> new SelectItem<>(s.getUsername(), s.getUsername())).toList());
	}

	@Override
	public ResponseData<?> updateChangeSelectMember(PermissionUpdateSelecteRequest req) {
		if (CollectionUtils.isEmpty(req.getItems())) {
			groupMemberRepository.deleteByGroupIdAndRoleId(req.getGroupId(), req.getRoleId());
		} else {
			var entities = groupMemberRepository.findByGroupIdAndRoleIdAndDepartmentId(req.getGroupId(),
					req.getRoleId(), req.getDepartmentId());
			Set<GroupMemberEntity> newItems = new HashSet<>();
			Set<String> deleteItems = new HashSet<>();
			if (CollectionUtils.isEmpty(entities)) {
				newItems = req
						.getItems().stream().map(s -> new GroupMemberEntity(UUID.randomUUID().toString(),
								req.getGroupId(), req.getRoleId(), s, req.getDepartmentId()))
						.collect(Collectors.toSet());
			} else {
				var existItems = entities.stream().map(GroupMemberEntity::getUsername).collect(Collectors.toSet());
				newItems = req.getItems().stream().filter(f -> !existItems.contains(f))
						.map(s -> new GroupMemberEntity(UUID.randomUUID().toString(), req.getGroupId(), req.getRoleId(),
								s, req.getDepartmentId()))
						.collect(Collectors.toSet());
				deleteItems = entities.stream().filter(f -> !req.getItems().contains(f.getUsername()))
						.map(s -> s.getId()).collect(Collectors.toSet());
			}
			if (!CollectionUtils.isEmpty(newItems))
				groupMemberRepository.saveAll(newItems);
			if (!CollectionUtils.isEmpty(deleteItems))
				groupMemberRepository.deleteAllById(deleteItems);
		}
		return ResponseData.success(true);
	}
}