package cms.portal.management.dto;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Retention(RetentionPolicy.RUNTIME)
@Target({ ElementType.FIELD })
public @interface ExcelPos {

	int value();
	boolean isMandatory() default false;
	boolean isNumeric() default false;
	int isMaxLength() default 10;
	int isMinLength() default 0;
	String pattern() default ""; // cardmask "^(\\d{6})[-](\\d{4})$"
	
}
