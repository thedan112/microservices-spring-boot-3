package cms.portal.management.service;

import java.util.List;

public interface IGroupRoleService {

	public List<String> findRoleIdsByGroupId(String groupId);
	
	public void saveAll(String groupId, List<String> roleIds);
	
	public void updateByResourceUrl(String groupId, List<String> roleIds);
}
