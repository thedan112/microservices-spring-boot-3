import { provideHttpClient, withFetch, withInterceptors } from '@angular/common/http';
import { ApplicationConfig, importProvidersFrom } from '@angular/core';
import { provideAnimationsAsync } from '@angular/platform-browser/animations/async';
import { provideRouter, withEnabledBlockingInitialNavigation, withInMemoryScrolling } from '@angular/router';
import { JwtModule } from '@auth0/angular-jwt';
import Aura from '@primeng/themes/aura';
import { providePrimeNG } from 'primeng/config';
import { routes } from './app.routes';
import { AppContanstData } from '@modules/common/constant/app.constant.data';
import { environments } from 'src/environments/enviroment';
import { MessageService } from 'primeng/api';
import { authInterceptor } from '@modules/interceptors/auth.interceptor.service';

export const appConfig: ApplicationConfig = {
    providers: [
        provideRouter(routes, withInMemoryScrolling({ anchorScrolling: 'enabled', scrollPositionRestoration: 'enabled' }), withEnabledBlockingInitialNavigation()),
        provideHttpClient(withFetch(),
            withInterceptors([authInterceptor])
        ),
        provideAnimationsAsync(),
        providePrimeNG({ theme: { preset: Aura, 
            options: { darkModeSelector: '.my-app-dark' }
         },  }, ),
         MessageService,
         importProvidersFrom([
            JwtModule.forRoot({
                config: {
                    tokenGetter: () => localStorage.getItem(AppContanstData.storage.keyUser),
                    allowedDomains: [environments.service]
                }
            })
         ])
    ]
};
