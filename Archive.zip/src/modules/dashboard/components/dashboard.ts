import { Component, OnInit } from '@angular/core';
import { AppCommonModule } from '@modules/common/app.common.module';

@Component({
    selector: 'app-dashboard',
    templateUrl: './dashboard.html',
    styleUrls: ['./dashboard.scss'],
    imports: [AppCommonModule]
})
export class DashboardComponent implements OnInit {
    constructor() {}
    ngOnInit(): void {}
}
