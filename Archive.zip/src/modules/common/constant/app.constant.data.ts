export const AppContanstData: any = {
    storage: {
      keyToken: 'auth-token',
      keyUser: 'auth-user',
      keyPasswordToken: 'password-token',
    },
    keyTokenHeader: 'Authorization',
    typeToken: 'Bearer ',
    statusCodeSuccess: '000',
    permissionDenied: '403',
  }
  