import { Injectable } from "@angular/core";
import { MessageService } from "primeng/api";
import { BehaviorSubject } from "rxjs";

@Injectable({ providedIn: 'root', })
export class ToastService {
  public isLoading = new BehaviorSubject<boolean>(false);
  public subBlockDocument = new BehaviorSubject<boolean>(false);
  constructor(private messageService: MessageService) { }

  success(summary: string = 'Success', detail?: string, lifeTime: number = 3000) {
    this.messageService.add({ severity: 'success', summary: summary, detail: detail, life: lifeTime });
  }

  info(summary: string = 'Info', detail?: string, lifeTime: number = 3000) {
    this.messageService.add({ severity: 'info', summary: summary, detail: detail, life: lifeTime });
  }

  warn(summary: string = 'Warn', detail?: string, lifeTime: number = 3000) {
    this.messageService.add({ severity: 'warn', summary: summary, detail: detail, life: lifeTime });
  }

  error(summary: string = 'Error', detail?: string, lifeTime: number = 3000) {
    this.messageService.add({ severity: 'error', summary: summary, detail: detail, life: lifeTime });
  }

  clear() {
    this.messageService.clear();
  }

  blockDocument(blocked: boolean = false) {
    this.subBlockDocument.next(blocked);
  }
}