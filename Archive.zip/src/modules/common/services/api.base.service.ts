import { HttpHeaders } from "@angular/common/http";
import { Observable, of } from "rxjs";

export class ApiBaseService {

  // constructor(private router: Router,
  //   private localStorage: LocalStorageService) { }

  public getHeaders(includeJsonContentType?: boolean): HttpHeaders {
    return new HttpHeaders();
  }

  public handleError<T>(operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {
      // if (error.status == 401) {
      //   this.localStorage.clearStorage();
      //   this.router.navigate([UriConstant.auth.login])
      // }
      return of(result as T)
    };
  }
}
