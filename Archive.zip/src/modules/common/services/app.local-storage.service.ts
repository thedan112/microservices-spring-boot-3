import { Injectable } from "@angular/core";
import { CookieService } from "ngx-cookie-service";
import { AppContanstData } from "../constant/app.constant.data";
import { UserModel } from "../models/user.model";

@Injectable({providedIn: 'root'})
export class LocalStorageService {
    constructor(private cookie: CookieService) { }

    public clearStorage() {
        this.cookie.deleteAll();
        window.localStorage.clear();
    }

    public saveSessionUser(user: UserModel): void {
        window.localStorage.setItem(AppContanstData.storage.keyUser, btoa(JSON.stringify(user)))
    }

    public getSessionUser(): UserModel | null {
        let data = window.localStorage.getItem(AppContanstData.storage.keyUser);
        if (data) {
            let cur = JSON.parse(atob(data)) as UserModel;
            if (cur.expiry <= Date.now()) {
                this.clearStorage();
                return null;
            } else {
                return cur;
            }
        } else {
            return null;
        }
    }
}