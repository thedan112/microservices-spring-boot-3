export interface IPagedModel<TData> {
    content: TData[];
    last: boolean;
    totalElements: number;
    totalPages: number;
    first: boolean;
    numberOfElements: number;
    size: number;
    number: number;
    empty: boolean;
    pageCaption: string;
}

export class PagedModel<TData> implements IPagedModel<TData> {

    constructor(content?: Array<TData>, empty?: boolean, first?: boolean, last?: boolean, number?: number
        , numberOfElements?: number, size?: number, totalElements?: number, totalPages?: number) {
        this.content = content || new Array<TData>();
        this.empty = empty || false;
        this.first = first || false
        this.last = last || false;
        this.number = number || 0;
        this.numberOfElements = numberOfElements || 0;
        this.totalElements = totalElements || 0;
        this.totalPages = totalPages || 0;
        //this.pageCaption = '';
        this.test = `Show ${this.numberOfElements} of ${this.totalElements}`;
    }

    content: TData[];
    empty: boolean;
    first: boolean;
    last: boolean;
    number: number;
    numberOfElements: number;
    size: number = 0;
    totalElements: number;
    totalPages: number;
    test: string;
    get pageCaption(): string {
        return `Show ${this.numberOfElements} of ${this.totalElements}`;
    }
}
