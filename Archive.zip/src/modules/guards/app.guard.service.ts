import { Injectable } from "@angular/core";
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot } from "@angular/router";
import { JwtHelperService } from "@auth0/angular-jwt";
import { UriConstant } from "@modules/common/constant/app.uri.data";
import { CommonUserService } from "@modules/common/services/app.user.service";
import { Observable } from "rxjs";

@Injectable({ providedIn: 'root' })
export class AppGuardService implements CanActivate {
    constructor(private userService: CommonUserService,
        private router: Router,
        private jwtHelper: JwtHelperService) { }

    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> {
        return new Observable<boolean>(o => {
            this.userService.user$.subscribe(user => {
                if (user && !this.jwtHelper.isTokenExpired(user.token)) {
                    if (user) {
                        o.next(true);
                        o.complete();
                    } else {
                        this.router.navigate([UriConstant.auth.accessDenied]);
                    }
                } else {
                    console.log("Hết Session")
                    this.router.navigate([UriConstant.auth.login], { queryParams: { returnUrl: state.url } });
                }
            })
        })
    }
}