import { Routes } from '@angular/router';
import { PermissionTabMenuContainer } from './containers/permissions/permission-tabmenu.component';
import { UsersTabMenuContainer } from './containers/users/app.tabmenu-management.component';

export default [
    { path: 'users', component: UsersTabMenuContainer },
    { path: 'permission', component: PermissionTabMenuContainer },
    { path: '**', redirectTo: '/notfound' }
] as Routes;
