export class ScopeCreateRequest {
    name?: string;
}