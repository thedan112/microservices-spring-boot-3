export class GroupUpdateRequest {
    
    id?: string;
    name?: string;
    addRole?: boolean;
    roleIds?: Array<string>;
}