export class ResourceUpdateRequest {
    
    id?: string;
    url?: string;
    description?: string;
    type?: string;
    addScope?: boolean;
    scopeIds?: Array<string>;
}