export class PermissionUpdateSelectRequest {
    constructor(departmentId: string, groupId: string, roleId: string, items: Array<string>) {
        this.departmentId = departmentId;
        this.groupId = groupId;
        this.roleId = roleId;
        this.items = items;
    }

    departmentId?: string;
    groupId?: string;
    roleId?: string;
    items?: Array<string>;
}
