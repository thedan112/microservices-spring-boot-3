export class FunctionCreateRequest {
    
    name?: string;
    description?: string;
    resourceView?: string;
    resourceIds?: string[];
    addResource?: boolean;
}