export class ScopeUpdateRequest {
    id?: string;
    name?: string;
}