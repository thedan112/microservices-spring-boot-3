export class GroupMemberRequest {
    departmentId?: string;
    groupId?: string;
}