export class DepartmentUpdateRequest {
    id?: string;
    name?: string;
    description?: string;
    addGroup?: boolean;
    groupIds?: Array<string>;
}