export class RoleResponse {
    id?: string;
    name?: string;
    active?: boolean;
    createdBy?: string;
    createdDate?: Date;
}