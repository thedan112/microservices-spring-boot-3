import { ResourceResponse } from "./resource-response.model";

export class FunctionUpdateRequest {
    
    id?: string;
    name?: string;
    description?: string;
    addResource?: boolean;
    resourceView?: string;
    resourceIds?: string[];
}