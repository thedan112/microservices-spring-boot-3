export class DepartmentResponse {
    id?: string;
    name?: string;
    groupIds?: string[];
    description?: string;
    createdBy?: string;
    createdDate?: Date;
}