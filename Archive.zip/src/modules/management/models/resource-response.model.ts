export class ResourceResponse {
    id?: string;
    url?: string;
    description?: string;
    type?: string;
    active?: boolean;
    scopeIds?: string[];
    createdBy?: string;
    createdDate?: Date;
}