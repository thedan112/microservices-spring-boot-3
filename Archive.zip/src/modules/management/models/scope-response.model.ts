export class ScopeResponse {
    
}