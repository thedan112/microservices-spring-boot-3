export class FunctionResponse {

    id?: string;
    name?: string;
    description?: string;
    active?: boolean;
    createdBy?: string;
    createdDate?: Date;
    updatedBy?: string;
    updatedDate?: Date;
    resourceView?: string;
    resourceIds?: string[];
}