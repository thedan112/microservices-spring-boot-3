export class GroupCreateRequest {
    name?: string;
    addRole?: boolean;
    roleIds?: Array<string>;   
}