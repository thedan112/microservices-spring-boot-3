export class PermissionGrouplstResponse {
    groupId?: string;
    groupName?: string;
}