export class UserResponse {
    id?: string;
    username?: string;
    email?: string;
    fullName?: string;
    department?: string;
    active?: boolean;
    locked?: boolean;
    createdBy?: string;
    createdDate?: Date;
}