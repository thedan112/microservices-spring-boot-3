export class GroupResponse {
    id?: string;
    name?: string;
    active?: boolean;
    createdBy?: string;
    createdDate?: Date;
}