export class PermissionRequestModel {
    constructor(departmentId: string, groupId: string, roleId: string) {
        this.departmentId = departmentId;
        this.groupId = groupId;
        this.roleId = roleId;
    }

    departmentId?: string;
    groupId?: string;
    roleId?: string;
}
