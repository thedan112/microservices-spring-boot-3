export class SelectionMappingResponse {
    source?: Array<string>;
    target?: Array<string>;
}