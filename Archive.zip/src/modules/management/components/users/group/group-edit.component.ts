import { Component, EventEmitter, Input, OnInit, Output, SimpleChanges } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { AppCommonModule } from '@modules/common/app.common.module';
import { DepartmentResponse } from '@modules/management/models/department-response.model';
import { GroupUpdateRequest } from '@modules/management/models/group-update-request.model';
import { ConfirmationService } from 'primeng/api';
import { SelectItem } from 'primeng/select';

@Component({
    selector: 'app-group-edit',
    templateUrl: './group-edit.component.html',
    styleUrls: ['./group-edit.component.scss'],
    imports: [AppCommonModule]
})
export class GroupEditComponent implements OnInit {
    @Input() isDetail!: boolean;
    @Input() detailForm!: FormGroup;
    @Input() model!: DepartmentResponse;
    @Input() roles?: SelectItem[];
    @Output() hidden = new EventEmitter<{ id: string; visible: boolean }>();
    @Output() submitUpdate = new EventEmitter<any>();

    selection: any[] = [
        { label: 'Yes', value: true },
        { label: 'No', value: false }
    ];
    disabled: boolean = false;

    constructor(private confirm: ConfirmationService) {}

    ngOnInit(): void {}

    ngOnChanges(changes: SimpleChanges) {
        if (this.model) {
            this.detailForm?.patchValue(this.model);
            this.detailForm?.patchValue({ addRole: false });
            this.detailForm?.get('roleIds')?.disable();
        }
    }

    change() {
        let disabled = this.detailForm.value.addRole;
        if (disabled) {
            this.detailForm?.get('roleIds')?.enable();
        } else {
            this.detailForm?.get('roleIds')?.disable();
        }
    } 

    onHidden() {
        this.hidden.emit({ id: '', visible: false });
    }

    onSave() {
        if (this.detailForm.valid) {
            this.confirm.confirm({
                message: 'Are you sure update infomation?',
                header: 'Confirmation',
                icon: 'pi pi-exclamation-triangle',
                acceptButtonProps: { severity: 'primary', icon: 'pi pi-check' },
                rejectButtonProps: { severity: 'secondary', icon: 'pi pi-times' },
                accept: () => {
                    let model = { ...this.detailForm.value } as GroupUpdateRequest;
                    this.submitUpdate.emit(model);
                },
                reject: () => {}
            });
        }
    }
}
