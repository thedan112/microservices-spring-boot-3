import { Component, EventEmitter, Input, OnInit, Output, SimpleChanges } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { AppCommonModule } from '@modules/common/app.common.module';
import { GroupCreateRequest } from '@modules/management/models/group-create-request.model';
import { SelectItem } from 'primeng/select';

@Component({
    selector: 'app-group-create',
    templateUrl: './group-create.component.html',
    styleUrls: ['./group-create.component.scss'],
    imports: [AppCommonModule]
})
export class GroupCreateComponent implements OnInit {
    @Input() isCreate!: boolean;
    @Input() createForm!: FormGroup;
    @Input() roles?: SelectItem[];
    @Output() hidden = new EventEmitter<boolean>();
    @Output() submitCreate = new EventEmitter<any>();
    selection: any[] = [
        { label: 'Yes', value: true },
        { label: 'No', value: false } 
    ];

    constructor() { }
    ngOnInit(): void {}

    ngOnChanges(changes: SimpleChanges) {
        this.createForm?.patchValue({ addRole: false });
        this.createForm?.get('roleIds')?.disable();
    }

    onHidden() {
        this.hidden.emit(false);
    }

    change() {
        let disabled = this.createForm.value.addRole;
        if (disabled) {
            this.createForm?.get('roleIds')?.enable();
        } else {
            this.createForm?.get('roleIds')?.disable();
        }
    }

    onSave() {
        if (this.createForm.valid) {
            let model = { ...this.createForm.value } as GroupCreateRequest;
            this.submitCreate.emit(model);
        }
    }
}
