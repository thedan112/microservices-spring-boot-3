import { Component, EventEmitter, Input, OnInit, Output } from "@angular/core";
import { FormGroup } from "@angular/forms";
import { AppCommonModule } from "@modules/common/app.common.module";
import { ConfirmationService } from "primeng/api";
import { PaginatorState } from "primeng/paginator";

@Component({
    selector: 'app-group-lst',
    templateUrl: './group-lst.component.html',
    styleUrls: ['./group-lst.component.scss'],
    imports: [AppCommonModule],
})
export class GroupLstComponent implements OnInit {
    @Input() colData?: any[];
    @Input() content!: any[];
    @Input() currPage!: number;
    @Input() totalPages!: number;
    @Input() totalElements!: number;
    @Input() rows!: number;
    @Input() numberOfElements?: number;
    @Input() searchForm!: FormGroup;
    @Output() search = new EventEmitter<string>();
    @Output() pageChange = new EventEmitter<PaginatorState>();
    @Output() create = new EventEmitter<boolean>();
    @Output() detail = new EventEmitter<{ id: string, visible: boolean }>();
    @Output() changeActive = new EventEmitter<{ id: string, status: boolean }>();
    @Output() changeLocked = new EventEmitter<{ id: string, status: boolean }>();

    constructor(private confirm: ConfirmationService) { }

    ngOnInit(): void { }

    onCreate() {
        this.create.emit(true);
    }

    onDetail(id: string) {
        this.detail.emit({ id: id, visible: true });
    }

    onSearch() {
        let name = this.searchForm.value.name;
        this.search.emit(name);
    }

    onPageChange(event: PaginatorState) {
        this.pageChange.emit(event);
    }

    onSwitchActive(id: string, status: boolean) {
        this.confirm.confirm({
            message: 'Bạn muốn thay đổi trạng thái kích hoạt người dùng?',
            header: 'Xác nhận',
            icon: 'pi pi-exclamation-triangle',
            acceptButtonProps: { severity: 'primary', icon: 'pi pi-check' },
            rejectButtonProps: { severity: 'secondary', icon: 'pi pi-times' },
            accept: () => {
                this.changeActive.emit({ id, status });
            },
            reject: () => { }
        });
    }
}