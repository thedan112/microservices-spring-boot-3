import { Component, EventEmitter, Input, OnInit, Output, SimpleChanges } from "@angular/core";
import { FormGroup } from "@angular/forms";
import { AppCommonModule } from "@modules/common/app.common.module";
import { DepartmentCreateRequest } from "@modules/management/models/department-create-request.model";
import { SelectItem } from "primeng/select";

@Component({
    selector: 'app-department-create',
    templateUrl: './department-create.component.html',
    styleUrls: ['./department-create.component.scss'],
    imports: [AppCommonModule],
})
export class DepartmentCreateComponent implements OnInit {
    @Input() isCreate!: boolean;
    @Input() createForm!: FormGroup;
    @Input() groups?: SelectItem[];
    @Output() hidden = new EventEmitter<boolean>();
    @Output() submitCreate = new EventEmitter<any>();
    selection: any[] = [
        { label: 'Yes', value: true },
        { label: 'No', value: false } 
    ]; 

    constructor() { }

    ngOnInit(): void {}

    ngOnChanges(changes: SimpleChanges) {
        this.createForm?.patchValue({ addGroup: false });
        this.createForm?.get('groupIds')?.disable();
    }

    onHidden() {
        this.hidden.emit(false);
    }

    change() {
        let disabled = this.createForm.value.addGroup;
        if (disabled) {
            this.createForm?.get('groupIds')?.enable();
        } else {
            this.createForm?.get('groupIds')?.disable();
        }
    }

    onSave() {
        if (this.createForm.valid) {
            let model = { ...this.createForm.value } as DepartmentCreateRequest;
            this.submitCreate.emit(model);
        }
    }
}