import { Component, EventEmitter, Input, OnInit, Output, SimpleChanges } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { AppCommonModule } from '@modules/common/app.common.module';
import { DepartmentResponse } from '@modules/management/models/department-response.model';
import { DepartmentUpdateRequest } from '@modules/management/models/department-update-request.model';
import { ConfirmationService } from 'primeng/api';
import { SelectItem } from 'primeng/select';

@Component({
    selector: 'app-department-edit',
    templateUrl: './department-edit.component.html',
    styleUrls: ['./department-edit.component.scss'],
    imports: [AppCommonModule]
})
export class DepartmentEditComponent implements OnInit {
    @Input() isDetail!: boolean;
    @Input() detailForm!: FormGroup;
    @Input() model!: DepartmentResponse;
    @Input() groups?: SelectItem[];
    @Output() hidden = new EventEmitter<{ id: string; visible: boolean }>();
    @Output() submitUpdate = new EventEmitter<any>();
    selection: any[] = [
        { label: 'Yes', value: true },
        { label: 'No', value: false }
    ];
    disabled: boolean = false;

    constructor(private confirm: ConfirmationService) {}

    ngOnInit(): void {}

    ngOnChanges(changes: SimpleChanges) {
        if (this.model) {
            this.detailForm?.patchValue(this.model);
            this.detailForm?.patchValue({ addRole: false });
            this.detailForm?.get('groupIds')?.disable();
        }
    }

    change() {
        let disabled = this.detailForm.value.addGroup;
        if (disabled) {
            this.detailForm?.get('groupIds')?.enable();
        } else {
            this.detailForm?.get('groupIds')?.disable();
        }
    } 

    onHidden() {
        this.hidden.emit({ id: '', visible: false });
    }

    onSave() {
        if (this.detailForm.valid) {
            this.confirm.confirm({
                message: 'Are you sure update infomation?',
                header: 'Confirmation',
                icon: 'pi pi-exclamation-triangle',
                acceptButtonProps: { severity: 'primary', icon: 'pi pi-check' },
                rejectButtonProps: { severity: 'secondary', icon: 'pi pi-times' },
                accept: () => {
                    let model = { ...this.detailForm.value } as DepartmentUpdateRequest;
                    this.submitUpdate.emit(model);
                },
                reject: () => {}
            });
        }
    }
}
