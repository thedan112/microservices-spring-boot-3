import { Component, EventEmitter, Input, OnInit, Output, SimpleChanges } from "@angular/core";
import { FormGroup } from "@angular/forms";
import { AppCommonModule } from "@modules/common/app.common.module";
import { ConfirmationService } from "primeng/api";
import { DatePipe } from "@angular/common";
import { RoleResponse } from "@modules/management/models/role-response.model";
import { RoleUpdateRequest } from "@modules/management/models/role-update-request.model";

@Component({
    selector: 'app-role-edit',
    templateUrl: './role-edit.component.html',
    styleUrls: ['./role-edit.component.scss'],
    imports: [AppCommonModule],
    providers: [DatePipe],
})
export class RoleEditComponent implements OnInit {
    @Input() isDetail!: boolean;
    @Input() detailForm!: FormGroup;
    @Input() model!: RoleResponse;
    @Output() hidden = new EventEmitter<{ id: string, visible: boolean }>();
    @Output() submitUpdate = new EventEmitter<any>();

    constructor(private confirm: ConfirmationService,
        private datePipe: DatePipe) { }

    ngOnInit(): void { }

    ngOnChanges(changes: SimpleChanges) {
        if (this.model) {
            this.detailForm?.patchValue(this.model);
            this.detailForm?.patchValue({
                createdDate: this.datePipe.transform(this.model.createdDate, 'dd/MM/yyyy hh:mm:ss a')
            });
        }
    }

    onHidden() {
        this.hidden.emit({ id: '', visible: false });
    }

    onSave() {
        if (this.detailForm.valid) {
            this.confirm.confirm({
                message: 'Bạn muốn cập nhật thông tin?',
                header: 'Xác nhận',
                icon: 'pi pi-exclamation-triangle',
                acceptButtonProps: { severity: 'primary', icon: 'pi pi-check' },
                rejectButtonProps: { severity: 'secondary', icon: 'pi pi-times' },
                accept: () => {
                    let model = { ...this.detailForm.value } as RoleUpdateRequest;
                    this.submitUpdate.emit(model);
                },
                reject: () => { }
            });
        }
    }
}