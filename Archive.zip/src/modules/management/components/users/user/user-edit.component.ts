import { Component, EventEmitter, Input, OnInit, Output, SimpleChanges } from "@angular/core";
import { FormGroup } from "@angular/forms";
import { AppCommonModule } from "@modules/common/app.common.module";
import { ConfirmationService } from "primeng/api";
import { DatePipe } from "@angular/common";
import { UserResponse } from "@modules/management/models/user-response.model";
import { UserUpdateRequest } from "@modules/management/models/user-update.model";

@Component({
    selector: 'app-user-edit',
    templateUrl: './user-edit.component.html',
    styleUrls: ['./user-edit.component.scss'],
    imports: [AppCommonModule],
    providers: [DatePipe],
})
export class UserEditComponent implements OnInit {
    @Input() isDetail!: boolean;
    @Input() detailForm!: FormGroup;
    @Input() model!: UserResponse;
    @Output() hidden = new EventEmitter<{ model: UserResponse, visible: boolean }>();
    @Output() submitUpdate = new EventEmitter<any>();
    type: any[] = [
        { label: 'USER', value: 'USER' },
        { label: 'ADMIN', value: 'ADMIN' }
    ];

    department: any[] = [
        { label: 'CARDOPS', value: 'CARDOPS' },
    ];

    constructor(private confirm: ConfirmationService,
        private datePipe: DatePipe) { }

    ngOnInit(): void { }

    ngOnChanges(changes: SimpleChanges) {
        if (this.model) {
            this.detailForm?.patchValue(this.model);
            this.detailForm?.patchValue({
                createdDate: this.datePipe.transform(this.model.createdDate, 'dd/MM/yyyy hh:mm:ss a')
            });
        }
    }

    onHidden() {
        this.hidden.emit({ model: new UserResponse(), visible: false });
    }

    onSave() {
        if (this.detailForm.valid) {
            this.confirm.confirm({
                message: 'Bạn muốn cập nhật thông tin?',
                header: 'Xác nhận',
                icon: 'pi pi-exclamation-triangle',
                acceptButtonProps: { severity: 'primary', icon: 'pi pi-check' },
                rejectButtonProps: { severity: 'secondary', icon: 'pi pi-times' },
                accept: () => {
                    let model = { ...this.detailForm.value } as UserUpdateRequest;
                    this.submitUpdate.emit(model);
                },
                reject: () => { }
            });
        }
    }
}