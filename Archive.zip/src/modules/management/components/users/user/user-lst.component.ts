import { Component, EventEmitter, Input, OnInit, Output } from "@angular/core";
import { FormGroup } from "@angular/forms";
import { AppCommonModule } from "@modules/common/app.common.module";
import { UserResponse } from "@modules/management/models/user-response.model";
import { ConfirmationService } from "primeng/api";
import { PaginatorState } from "primeng/paginator";

@Component({
    selector: 'app-user-lst',
    templateUrl: './user-lst.component.html',
    styleUrls: ['./user-lst.component.scss'],
    imports: [AppCommonModule],
})
export class UserLstComponent implements OnInit {
    @Input() colData?: any[];
    @Input() content!: any[];
    @Input() currPage!: number;
    @Input() totalPages!: number;
    @Input() totalElements!: number;
    @Input() rows!: number;
    @Input() numberOfElements?: number;
    @Input() searchForm!: FormGroup;
    @Output() search = new EventEmitter<string>();
    @Output() pageChange = new EventEmitter<PaginatorState>();
    @Output() create = new EventEmitter<boolean>();
    @Output() detail = new EventEmitter<{ model: UserResponse, visible: boolean }>();
    @Output() changeActive = new EventEmitter<{ id: string, status: boolean }>();
    @Output() changeLocked = new EventEmitter<{ id: string, status: boolean }>();

    constructor(private confirm: ConfirmationService) { }

    ngOnInit(): void { }

    onCreate() {
        this.create.emit(true);
    }

    onDetail(model: any) {
        this.detail.emit({ model: model, visible: true });
    }

    onSearch() {
        let email = this.searchForm.value.email;
        this.search.emit(email);
    }

    onPageChange(event: PaginatorState) {
        this.pageChange.emit(event);
    }

    onSwitchActive(id: string, status: boolean) {
        this.confirm.confirm({
            message: 'Bạn muốn thay đổi trạng thái kích hoạt người dùng?',
            header: 'Xác nhận',
            icon: 'pi pi-exclamation-triangle',
            acceptButtonProps: { severity: 'primary', icon: 'pi pi-check' },
            rejectButtonProps: { severity: 'secondary', icon: 'pi pi-times' },
            accept: () => {
                this.changeActive.emit({ id, status });
            },
            reject: () => { }
        });
    }

    onSwitchLocked(id: string, status: boolean) {
        this.confirm.confirm({
            message: 'Bạn muốn thay đổi trạng thái khóa người dùng?',
            header: 'Xác nhận',
            icon: 'pi pi-exclamation-triangle',
            acceptButtonProps: { severity: 'primary', icon: 'pi pi-check' },
            rejectButtonProps: { severity: 'secondary', icon: 'pi pi-times' },
            accept: () => {
                this.changeLocked.emit({id, status});
            },
            reject: () => { }
        });
    }
}