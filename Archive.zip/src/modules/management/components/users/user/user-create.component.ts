import { Component, EventEmitter, Input, OnInit, Output } from "@angular/core";
import { FormGroup } from "@angular/forms";
import { AppCommonModule } from "@modules/common/app.common.module";
import { ToastService } from "@modules/common/services/toast.service";
import { UserCreateRequest } from "@modules/management/models/user-create-request.model";
import { SelectItem } from "primeng/select";

@Component({
    selector: 'app-user-create',
    templateUrl: './user-create.component.html',
    styleUrls: ['./user-create.component.scss'],
    imports: [AppCommonModule],
})
export class UserCreateComponent implements OnInit {
    @Input() isCreate!: boolean;
    @Input() createForm!: FormGroup;
    @Input() departments?: SelectItem[];
    @Output() hidden = new EventEmitter<boolean>();
    @Output() submitCreate = new EventEmitter<any>();
    type: any[]  = [
        { label: 'USER', value: 'USER'},
        { label: 'ADMIN', value: 'ADMIN'}
    ];

    constructor(private toast: ToastService) { }

    ngOnInit(): void {
    }

    onHidden() { this.hidden.emit(false); }

    onSave() {
        if (this.createForm.valid) {
            let model = { ...this.createForm.value } as UserCreateRequest;
            this.submitCreate.emit(model);
        }
    }
}