import { Component, EventEmitter, Input, OnInit, Output, SimpleChanges } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { AppCommonModule } from '@modules/common/app.common.module';
import { ResourceResponse } from '@modules/management/models/resource-response.model';
import { ResourceUpdateRequest } from '@modules/management/models/resource-update-request.model';
import { ConfirmationService } from 'primeng/api';
import { SelectItem } from 'primeng/select';

@Component({
    selector: 'app-resource-edit',
    templateUrl: './resource-edit.component.html',
    styleUrls: ['./resource-edit.component.scss'],
    imports: [AppCommonModule]
})
export class ResourceEditComponent implements OnInit {
    @Input() isDetail!: boolean;
    @Input() detailForm!: FormGroup;
    @Input() model!: ResourceResponse;
    @Input() scopes?: SelectItem[];
    @Input() target?: SelectItem[];
    @Input() resourceType!: any[];
    @Output() hidden = new EventEmitter<{ id: string; visible: boolean }>();
    @Output() submitUpdate = new EventEmitter<any>();
    selection: any[] = [
        { label: 'Yes', value: true },
        { label: 'No', value: false }
    ];
    disabled: boolean = false; 

    constructor(private confirm: ConfirmationService) {}

    ngOnInit(): void {}

    ngOnChanges(changes: SimpleChanges) {
        if (this.model) {
            this.detailForm?.patchValue(this.model);
            this.detailForm?.get('scopeIds')?.disable();
        }
    }

    onHidden() {
        this.hidden.emit({ id: '', visible: false });
    }

    change() {
        this.disabled = this.detailForm.value.addScope;
        if (this.disabled) {
            this.detailForm?.get('scopeIds')?.enable();
        } else {
            this.detailForm?.get('scopeIds')?.disable();
        }
    }

    onSave() {
        if (this.detailForm.valid) {
            this.confirm.confirm({
                message: 'Are you sure update to infomation?',
                header: 'Confirmation',
                icon: 'pi pi-exclamation-triangle',
                acceptButtonProps: { severity: 'primary', icon: 'pi pi-check' },
                rejectButtonProps: { severity: 'secondary', icon: 'pi pi-times' },
                accept: () => {
                    let model = { ...this.detailForm.value } as ResourceUpdateRequest;
                    this.submitUpdate.emit(model);
                },
                reject: () => {}
            });
        }
    }
}
