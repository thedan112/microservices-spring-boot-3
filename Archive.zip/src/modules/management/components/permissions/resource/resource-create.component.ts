import { Component, EventEmitter, Input, OnInit, Output, SimpleChanges } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { AppCommonModule } from '@modules/common/app.common.module';
import { ResourceCreateRequest } from '@modules/management/models/resource-create-request.model';
import { SelectItem } from 'primeng/select';

@Component({
    selector: 'app-resource-create',
    templateUrl: './resource-create.component.html',
    styleUrls: ['./resource-create.component.scss'],
    imports: [AppCommonModule]
})
export class ResourceCreateComponent implements OnInit {
    @Input() isCreate!: boolean;
    @Input() createForm!: FormGroup;
    @Input() resourceType!: any[];
    @Input() scopes?: SelectItem[];
    @Output() hidden = new EventEmitter<boolean>();
    @Output() submitCreate = new EventEmitter<any>();
    selection: any[] = [
        { label: 'Yes', value: true },
        { label: 'No', value: false }
    ];
    disabled: boolean = false;

    constructor() {}

    ngOnInit(): void {}

    ngOnChanges(changes: SimpleChanges) { 
        this.createForm?.patchValue({ addScope: false });
        this.createForm?.get('scopeIds')?.disable();
    }

    onHidden() {
        this.disabled = false;
        this.hidden.emit(false);
    }

    change() {
        this.disabled = this.createForm.value.addScope;
        if (this.disabled) {
            this.createForm?.get('scopeIds')?.enable();
        } else {
            this.createForm?.get('scopeIds')?.disable();
        }
    }

    onSave() {
        if (this.createForm.valid) {
            let model = { ...this.createForm.value } as ResourceCreateRequest;
            this.submitCreate.emit(model);
        }
    }
}
