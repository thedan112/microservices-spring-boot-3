import { Component, EventEmitter, Input, OnInit, Output, SimpleChanges } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AppCommonModule } from '@modules/common/app.common.module';

@Component({
    selector: 'app-permission-department-selection',
    templateUrl: './permission-department-selection.component.html',
    styleUrls: ['./permission-department-selection.component.scss'],
    imports: [AppCommonModule]
})
export class PermissionDepartmentSelectionComponent implements OnInit {
    @Input() departments?: any[];
    @Output() selection = new EventEmitter<string>();
    selectForm!: FormGroup;

    constructor(private fb: FormBuilder) {}

    ngOnInit(): void {
        this.formBuilder();
    }

    ngOnChanges(changes: SimpleChanges) {
        if (this.departments && this.departments.length > 0) {
            let departmentId = this.departments[0].value;
            if (departmentId) {
                this.selectForm?.patchValue({ id: departmentId });
                this.onChange();
            }
        }
    }

    formBuilder() {
        this.selectForm = this.fb.group({ id: [null, Validators.required] });
    }

    onChange() {
        if (this.selectForm.valid) {
            let departmentId = this.selectForm.value.id;
            this.selection.emit(departmentId);
        }
    }
}
