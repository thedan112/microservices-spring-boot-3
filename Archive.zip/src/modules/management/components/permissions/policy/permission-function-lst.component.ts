import { Component, EventEmitter, Input, OnInit, Output, SimpleChanges } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { AppCommonModule } from '@modules/common/app.common.module';
import { IPagedModel } from '@modules/common/models/page.model';
import { FunctionResponse } from '@modules/management/models/function-response.model';
import { PermissionUpdateSelectRequest } from '@modules/management/models/permission-update-select-request.model';
import { ConfirmationService } from 'primeng/api';
import { PaginatorState } from 'primeng/paginator';

@Component({
    selector: 'app-permission-function-lst',
    templateUrl: './permission-function-lst.component.html',
    styleUrls: ['./permission-function-lst.component.scss'],
    imports: [AppCommonModule]
})
export class PermissionFunctionLstComponent implements OnInit {
    @Input() source!: IPagedModel<FunctionResponse>;
    @Input() target!: Array<FunctionResponse>;
    @Input() groupId!: string;
    @Input() departmentId!: string;
    @Input() roleId!: string;
    @Input() loading!: boolean;
    @Output() search = new EventEmitter<string>();
    @Output() submit = new EventEmitter<PermissionUpdateSelectRequest>();
    @Output() pageChange = new EventEmitter<PaginatorState>();

    selected: Array<FunctionResponse> = new Array();
    searchForm!: FormGroup;

    colData: any[] = [
        { field: 'id', header: '', dataType: 'action' },
        { field: 'name', header: 'Name', dataType: 'text' }
    ];

    constructor(private confirm: ConfirmationService) {}
    ngOnInit(): void {}

    ngOnChanges(changes: SimpleChanges) {
        if (this.target && this.target.length > 0) {
            this.selected = this.target;
        } else {
            this.selected = [];
        }
    }

    onPageChange(event: PaginatorState) {
        this.pageChange.emit(event);
    }

    onSave() {
        this.confirm.confirm({
            message: 'Are you sure submit save change?',
            header: 'Confirmation',
            icon: 'pi pi-exclamation-triangle',
            acceptButtonProps: { severity: 'primary', icon: 'pi pi-check' },
            rejectButtonProps: { severity: 'secondary', icon: 'pi pi-times' },
            accept: () => {
                let items = new Array<string>();
                for (let item of this.selected) {
                    if (item.id) {
                        items.push(item.id);
                    }
                }
                let model = new PermissionUpdateSelectRequest(this.departmentId, this.groupId, this.roleId, items);
                this.submit.emit(model);
            },
            reject: () => {}
        });
    }
}
