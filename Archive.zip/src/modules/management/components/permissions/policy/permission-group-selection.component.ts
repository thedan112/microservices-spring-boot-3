import { Component, EventEmitter, Input, OnInit, Output, SimpleChanges } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AppCommonModule } from '@modules/common/app.common.module';

@Component({
    selector: 'app-permission-group-selection',
    templateUrl: './permission-group-selection.component.html',
    styleUrls: ['./permission-group-selection.component.scss'],
    imports: [AppCommonModule]
})
export class PermissionGroupSelectionComponent implements OnInit {
    @Input() groups!: any[];
    @Input() disabled!: boolean;
    @Output() selection = new EventEmitter<string>();
    selectForm!: FormGroup;

    constructor(private fb: FormBuilder) {
        this.formBuilder();
    }

    ngOnInit(): void {}

    ngOnChanges(changes: SimpleChanges) {
        if (this.groups && this.groups.length > 0) {
            this.selectForm?.get('groupId')?.disable();
            let groupId = this.groups[0].value;
            if (groupId) {
                this.selectForm?.get('groupId')?.enable();
                this.selectForm?.patchValue({ groupId: groupId });
                this.onChange();
            }
        }
    }

    formBuilder() {
        this.selectForm = this.fb.group({ groupId: [null, Validators.required] });
    }

    onChange() {
        if (this.selectForm.valid) {
            let groupId = this.selectForm.value.groupId;
            this.selection.emit(groupId);
        }
    }
}
