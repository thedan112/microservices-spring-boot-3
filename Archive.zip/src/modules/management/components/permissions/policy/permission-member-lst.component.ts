import { Component, EventEmitter, Input, OnInit, Output, SimpleChanges } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { AppCommonModule } from '@modules/common/app.common.module';
import { IPagedModel } from '@modules/common/models/page.model';
import { PermissionUpdateSelectRequest } from '@modules/management/models/permission-update-select-request.model';

import { ConfirmationService } from 'primeng/api';
import { SelectItem } from 'primeng/select';

@Component({
    selector: 'app-permission-member-lst',
    templateUrl: './permission-member-lst.component.html',
    styleUrls: ['./permission-member-lst.component.scss'],
    imports: [AppCommonModule]
})
export class PermissionMemberLstComponent implements OnInit {
    @Input() source!: IPagedModel<any>;
    @Input() target!: any[];
    @Input() departmentId!: string;
    @Input() groupId!: string;
    @Input() roleId!: string;
    @Input() loading!: boolean;
    @Output() search = new EventEmitter<string>();
    @Output() submit = new EventEmitter<PermissionUpdateSelectRequest>();
    @Output() pageChange = new EventEmitter<{ page: number; size: number }>();

    selected: any[] = [];
    searchForm!: FormGroup;

    colData: any[] = [
        { field: 'id', header: '', dataType: 'action' },
        { field: 'username', header: 'Username', dataType: 'text' }
    ];

    constructor(private confirm: ConfirmationService) {}

    ngOnInit(): void {}

    ngOnChanges(changes: SimpleChanges) {
        if (this.target && this.target.length > 0) {
            this.selected = this.target;
        } else {
            this.selected = [];
        }
    }

    onPageChange(event: any) {
        this.pageChange.emit({ page: event.page, size: event.rows });
    }

    onSave() {
        this.confirm.confirm({
            message: 'Are you sure submit save change?',
            header: 'Confirmation',
            icon: 'pi pi-exclamation-triangle',
            acceptButtonProps: { severity: 'primary', icon: 'pi pi-check' },
            rejectButtonProps: { severity: 'secondary', icon: 'pi pi-times' },
            accept: () => {
                let items = new Array<string>();
                for (let item of this.selected) {
                    if (item) {
                        items.push(item.value);
                    }
                }
                let model = new PermissionUpdateSelectRequest(this.departmentId, this.groupId, this.roleId, items);
                this.submit.emit(model);
            },
            reject: () => {}
        });
    }
}
