import { Component, EventEmitter, Input, OnInit, Output, SimpleChanges } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AppCommonModule } from '@modules/common/app.common.module';

@Component({
    selector: 'app-permission-role-selection',
    templateUrl: './permission-role-selection.component.html',
    styleUrls: ['./permission-role-selection.component.scss'],
    imports: [AppCommonModule]
})
export class PermissionRoleSelectionComponent implements OnInit {
    @Input() roles!: any[];
    @Input() disabled!: boolean;
    @Output() selection = new EventEmitter<string>();
    selectForm!: FormGroup;

    constructor(private fb: FormBuilder) {
        this.formBuilder();
    }

    ngOnInit(): void {}

    ngOnChanges(changes: SimpleChanges) {
        if (this.roles && this.roles.length > 0) {
            this.selectForm?.get('roleId')?.disable();
            let roleId = this.roles[0].value;
            if (roleId) {
                this.selectForm?.get('roleId')?.enable();
                this.selectForm?.patchValue({ roleId: roleId });
                this.onChange();
            }
        }
    }

    formBuilder() {
        this.selectForm = this.fb.group({ roleId: [null, Validators.required] });
    }

    onChange() {
        if (this.selectForm.valid) {
            let roleId = this.selectForm.value.roleId;
            this.selection.emit(roleId);
        }
    }
}
