import { Component, EventEmitter, Input, OnInit, Output, SimpleChanges } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { AppCommonModule } from '@modules/common/app.common.module';
import { PermissionUpdateSelectRequest } from '@modules/management/models/permission-update-select-request.model';
import { ConfirmationService } from 'primeng/api';
import { PaginatorState } from 'primeng/paginator';

@Component({
    selector: 'app-permission-scope-lst',
    templateUrl: './permission-scope-lst.component.html',
    styleUrls: ['./permission-scope-lst.component.scss'],
    imports: [AppCommonModule]
})
export class PermissionScopeLstComponent implements OnInit {
    @Input() source!: any[];
    @Input() target!: any[];
    @Input() groupId!: string;
    @Input() departmentId!: string;
    @Input() roleId!: string;
    @Output() search = new EventEmitter<string>();
    @Output() submit = new EventEmitter<PermissionUpdateSelectRequest>();
    @Output() pageChange = new EventEmitter<PaginatorState>();

    selected: any[] = [];
    searchForm!: FormGroup;

    colData: any[] = [
        { field: 'id', header: '', dataType: 'action' },
        { field: 'name', header: 'Name', dataType: 'text' }
    ];

    constructor(private confirm: ConfirmationService) {}
    ngOnInit(): void {}

    ngOnChanges(changes: SimpleChanges) {
        if (this.target && this.target.length > 0) {
            console.log(this.selected);
            this.selected = this.target;
        } else {
            this.selected = [];
        }
    }

    onPageChange(event: PaginatorState) {
        this.pageChange.emit(event);
    }

    onSave() {
        this.confirm.confirm({
            message: 'Are you sure submit save change?',
            header: 'Confirmation',
            icon: 'pi pi-exclamation-triangle',
            acceptButtonProps: { severity: 'primary', icon: 'pi pi-check' },
            rejectButtonProps: { severity: 'secondary', icon: 'pi pi-times' },
            accept: () => {
                let items = new Array<string>();
                for (let item of this.selected) {
                    if (item.value) {
                        items.push(item.value);
                    }
                }
                let model = new PermissionUpdateSelectRequest(this.departmentId, this.groupId, this.roleId, items);
                this.submit.emit(model);
            },
            reject: () => {}
        });
    }
}
