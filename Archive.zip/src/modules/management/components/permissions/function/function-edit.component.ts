import { Component, EventEmitter, Input, OnInit, Output, SimpleChanges } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { AppCommonModule } from '@modules/common/app.common.module';
import { FunctionResponse } from '@modules/management/models/function-response.model';
import { FunctionUpdateRequest } from '@modules/management/models/function-update-request.model';
import { ResourceResponse } from '@modules/management/models/resource-response.model';
import { ConfirmationService } from 'primeng/api';

@Component({
    selector: 'app-function-edit',
    templateUrl: './function-edit.component.html',
    styleUrls: ['./function-edit.component.scss'],
    imports: [AppCommonModule],
    providers: []
})
export class FunctionEditComponent implements OnInit {
    @Input() isDetail!: boolean;
    @Input() views!: any;
    @Input() apis!: any;
    @Input() targets!: Array<string>;
    @Input() detailForm!: FormGroup;
    @Input() model!: FunctionResponse;
    @Output() hidden = new EventEmitter<{ id: string; visible: boolean }>();
    @Output() submitUpdate = new EventEmitter<FunctionUpdateRequest>();
    @Output() loadResources = new EventEmitter<string>();

    constructor(private confirm: ConfirmationService) {}

    selection: any[] = [
        { label: 'Yes', value: true },
        { label: 'No', value: false }
    ];

    ngOnInit(): void {}

    ngOnChanges(changes: SimpleChanges) {
        if (this.model) {
            this.detailForm?.patchValue(this.model);
            this.detailForm?.patchValue({ addResource: false });
            this.detailForm?.get('resourceIds')?.disable();
        }
    }

    change() {
        let disabled = this.detailForm.value.addResource;
        if (disabled) {
            this.detailForm?.get('resourceIds')?.enable();
        } else {
            this.detailForm?.get('resourceIds')?.disable();
        }
    } 

    onHidden() {
        this.hidden.emit({ id: '', visible: false });
    }

    onSave() {
        if (this.detailForm.valid) {
            this.confirm.confirm({
                message: 'Are you sure update infomation?',
                header: 'Confirmation',
                icon: 'pi pi-exclamation-triangle',
                acceptButtonProps: { severity: 'primary', icon: 'pi pi-check' },
                rejectButtonProps: { severity: 'secondary', icon: 'pi pi-times' },
                accept: () => {
                    let model = { ...this.detailForm.value } as FunctionUpdateRequest;
                    this.submitUpdate.emit(model);
                },
                reject: () => {}
            });
        }
    }
}
