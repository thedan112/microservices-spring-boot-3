import { Component, EventEmitter, Input, OnInit, Output, SimpleChanges } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { AppCommonModule } from '@modules/common/app.common.module';
import { FunctionCreateRequest } from '@modules/management/models/function-create-request.model';
import { SelectItem } from 'primeng/select';

@Component({
    selector: 'app-function-create',
    templateUrl: './function-create.component.html',
    styleUrls: ['./function-create.component.scss'],
    imports: [AppCommonModule]
})
export class FunctionCreateComponent implements OnInit {
    @Input() isCreate!: boolean;
    @Input() createForm!: FormGroup;
    @Input() apis?: SelectItem[];
    @Input() views?: SelectItem[];
    @Output() hidden = new EventEmitter<boolean>();
    @Output() submitCreate = new EventEmitter<any>();
    selection: any[] = [
        { label: 'Yes', value: true },
        { label: 'No', value: false }
    ];

    constructor() {}

    ngOnInit(): void {}

    ngOnChanges(changes: SimpleChanges) {
        this.createForm?.patchValue({ addResource: false });
        this.createForm?.get('resourceIds')?.disable();
    }

    onHidden() {
        this.hidden.emit(false);
    }

    change() {
        let disabled = this.createForm.value.addResource;
        if (disabled) {
            this.createForm?.get('resourceIds')?.enable();
        } else {
            this.createForm?.get('resourceIds')?.disable();
        }
    }
    onSave() {
        if (this.createForm.valid) {
            let model = { ...this.createForm.value } as FunctionCreateRequest;
            this.submitCreate.emit(model);
        }
    }
}
