import { Component, EventEmitter, Input, OnInit, Output } from "@angular/core";
import { FormGroup } from "@angular/forms";
import { AppCommonModule } from "@modules/common/app.common.module";
import { PaginatorState } from "primeng/paginator";

@Component({
    selector: 'app-scope-lst',
    templateUrl: './scope-lst.component.html',
    styleUrls: ['./scope-lst.component.scss'],
    imports: [AppCommonModule],
})
export class ScopeLstComponent implements OnInit {
    @Input() colData?: any[];
    @Input() content!: any[];
    @Input() currPage!: number;
    @Input() totalPages!: number;
    @Input() totalElements!: number;
    @Input() rows!: number;
    @Input() numberOfElements?: number;
    @Input() searchForm!: FormGroup;
    @Output() search = new EventEmitter<string>();
    @Output() pageChange = new EventEmitter<PaginatorState>();
    @Output() create = new EventEmitter<boolean>();
    @Output() detail = new EventEmitter<{ id: string, visible: boolean }>();

    constructor() { }

    ngOnInit(): void { }

    onCreate() {
        this.create.emit(true);
    }

    onDetail(id: string) {
        this.detail.emit({ id: id, visible: true });
    }

    onSearch() {
        let url = this.searchForm.value.url;
        this.search.emit(url);
    }

    onPageChange(event: PaginatorState) {
        this.pageChange.emit(event);
    }
}