import { Component, EventEmitter, Input, OnInit, Output, SimpleChanges } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { AppCommonModule } from '@modules/common/app.common.module';
import { ScopeResponse } from '@modules/management/models/scope-response.model';
import { ScopeUpdateRequest } from '@modules/management/models/scope-update-request.model';
import { ConfirmationService } from 'primeng/api';

@Component({
    selector: 'app-scope-edit',
    templateUrl: './scope-edit.component.html',
    styleUrls: ['./scope-edit.component.scss'],
    imports: [AppCommonModule],
})
export class ScopeEditComponent implements OnInit {
    @Input() isDetail!: boolean;
    @Input() detailForm!: FormGroup;
    @Input() model!: ScopeResponse;
    @Output() hidden = new EventEmitter<{ id: string; visible: boolean }>();
    @Output() submitUpdate = new EventEmitter<ScopeUpdateRequest>();

    constructor(private confirm: ConfirmationService) {}

    ngOnInit(): void {}

    ngOnChanges(changes: SimpleChanges) {
        if (this.model) {
            this.detailForm?.patchValue(this.model);
        }
    }

    onHidden() {
        this.hidden.emit({ id: '', visible: false });
    }

    onSave() {
        if (this.detailForm.valid) {
            this.confirm.confirm({
                message: 'Are you sure update to infomation?',
                header: 'Confirmation',
                icon: 'pi pi-exclamation-triangle',
                acceptButtonProps: { severity: 'primary', icon: 'pi pi-check' },
                rejectButtonProps: { severity: 'secondary', icon: 'pi pi-times' },
                accept: () => {
                    let model = { ...this.detailForm.value } as ScopeUpdateRequest;
                    this.submitUpdate.emit(model);
                },
                reject: () => {}
            });
        }
    }
}
