import { Component, EventEmitter, Input, OnInit, Output } from "@angular/core";
import { FormGroup } from "@angular/forms";
import { AppCommonModule } from "@modules/common/app.common.module";
import { ResourceCreateRequest } from "@modules/management/models/resource-create-request.model";

@Component({
    selector: 'app-scope-create',
    templateUrl: './scope-create.component.html',
    styleUrls: ['./scope-create.component.scss'],
    imports: [AppCommonModule],
})
export class ScopeCreateComponent implements OnInit {
    @Input() isCreate!: boolean;
    @Input() createForm!: FormGroup;
    @Output() hidden = new EventEmitter<boolean>();
    @Output() submitCreate = new EventEmitter<any>();

    constructor() { }

    ngOnInit(): void {}

    onHidden() { this.hidden.emit(false); }

    onSave() {
        if (this.createForm.valid) {
            let model = { ...this.createForm.value } as ResourceCreateRequest;
            this.submitCreate.emit(model);
        }
    }
}