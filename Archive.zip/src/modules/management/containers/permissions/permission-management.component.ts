import { Component, OnInit } from '@angular/core';
import { AppCommonModule } from '@modules/common/app.common.module';
import { IPagedModel, PagedModel } from '@modules/common/models/page.model';
import { ToastService } from '@modules/common/services/toast.service';
import { lastValueFrom } from 'rxjs';
import { SelectItem } from 'primeng/select';
import { MenuItem } from 'primeng/api';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { PermissionGroupSelectionComponent } from '@modules/management/components/permissions/policy/permission-group-selection.component';
import { PermissionFunctionLstComponent } from '@modules/management/components/permissions/policy/permission-function-lst.component';
import { PermissionScopeLstComponent } from '@modules/management/components/permissions/policy/permission-scope-lst.component';
import { FunctionResponse } from '@modules/management/models/function-response.model';
import { ApiPermissionService } from '@modules/management/services/api.permission.service';
import { ApiDepartmentService } from '@modules/management/services/api.department.service';
import { ApiFunctionService } from '@modules/management/services/api.function.service';
import { PermissionRequestModel } from '@modules/management/models/permission-request.model';
import { PermissionUpdateSelectRequest } from '@modules/management/models/permission-update-select-request.model';
import { PermissionMemberLstComponent } from '@modules/management/components/permissions/policy/permission-member-lst.component';
import { ApiUserService } from '@modules/management/services/api.user.service';
import { ApiScopeService } from '@modules/management/services/api.scope.service';
import { PermissionRoleSelectionComponent } from '@modules/management/components/permissions/policy/permission-role-selection.component';
import { PermissionDepartmentSelectionComponent } from '@modules/management/components/permissions/policy/permission-department-selection.component';

@Component({
    selector: 'app-permission-management',
    templateUrl: './permission-management.component.html',
    styleUrls: ['./permission-management.component.scss'],
    imports: [AppCommonModule, PermissionDepartmentSelectionComponent, PermissionGroupSelectionComponent, PermissionFunctionLstComponent, PermissionScopeLstComponent, PermissionMemberLstComponent, PermissionRoleSelectionComponent]
})
export class PermissionManagementContainer implements OnInit {
    loading: boolean = false;
    visibleRole: boolean = false;
    visibleSelection: boolean = false;
    targets: any[] = [];
    groups: SelectItem[] = [];
    departments: SelectItem[] = [];
    roles: any[] = [];
    functionSource: IPagedModel<FunctionResponse> = new PagedModel();
    functionTarget: Array<FunctionResponse> = new Array();
    scopeSource: Array<any> = new Array();
    scopeTarget: Array<any> = new Array();
    userSource: IPagedModel<any> = new PagedModel();
    userTarget: Array<any> = new Array();
    page: number = 0;
    size: number = 10;
    groupId!: string;
    roleId!: string;
    departmentId!: string;
    totalRecords: number = 0;
    items: MenuItem[] = [
        {
            label: 'Member mapping',
            icon: 'pi pi-users',
            tab: '0',
            command: () => {
                this.selectItem = '0';
            }
        },
        {
            label: 'Function mapping',
            icon: 'pi pi-box',
            tab: '1',
            command: () => {
                this.selectItem = '1';
            }
        },
        {
            label: 'Scope mapping',
            icon: 'pi pi-link',
            tab: '2',
            command: () => {
                this.selectItem = '2';
            }
        }
    ];
    activeItem: any | undefined;
    selectItem: string | undefined;
    selectFormGroup!: FormGroup;
    selectFormRole!: FormGroup;

    constructor(
        private fb: FormBuilder,
        private toast: ToastService,
        private api: ApiPermissionService,
        private departmentApi: ApiDepartmentService,
        private functionApi: ApiFunctionService,
        private userApi: ApiUserService,
        private scopeApi: ApiScopeService
    ) {}

    ngOnInit(): void {
        this.activeItem = this.items[0];
        this.selectItem = '0';
        this.formRoleBuilder();
        this.loadAllDepartment();
    }

    onActiveItemChange(event: MenuItem) {
        if (this.activeItem === event) return;
        this.activeItem = event;
        this.loadBySelectItem();
    }

    loadBySelectItem() {
        switch (this.selectItem) {
            case '0':
                this.loadMemberByDepartment({ page: 0, size: 10 });
                break;
            case '1':
                this.loaddAllFunction();
                break;
            case '2':
                this.loadAllScope();
                break;
        }
    }

    formRoleBuilder() {
        this.selectFormRole = this.fb.group({ roleId: [null, Validators.required] });
    }

    formGroupBuilder() {
        this.selectFormGroup = this.fb.group({ groupId: [null, Validators.required] });
    }

    async loadAllDepartment() {
        let res = await lastValueFrom(this.departmentApi.all());
        if (res.status == '000' && res.data) {
            this.departments = res.data;
        }
    }

    async loaddAllFunction() {
        let res = await lastValueFrom(this.functionApi.pages(this.page, this.size, ''));
        if (res.status == '000' && res.data) {
            this.functionSource = res.data;
            this.visibleSelection = true;
        } else {
            this.toast.error('Failure', res.message);
        }
    }

    async loadAllScope() {
        let res = await lastValueFrom(this.scopeApi.all());
        if (res.status == '000' && res.data) {
            this.scopeSource = res.data;
            this.visibleSelection = true;
        } else {
            this.toast.error('Failure', res.message);
        }
    }

    onPageChange($event: any): void {
        this.page = $event.page;
        this.size = $event.rows;
        this.loaddAllFunction();
    }

    async loadGroupByDepartment(id: string) {
        this.loading = true;
        let res = await lastValueFrom(this.api.loadGroupByDepartment(id));
        if (res.status == '000') {
            this.departmentId = id;
            this.groups = res.data;
            this.roles = [];
            this.visibleSelection = false;
        } else {
            this.toast.error('Failure', res.message);
        }
        this.loading = false;
    }

    async loadMemberByDepartment(event: { page: number; size: number }) {
        let res = await lastValueFrom(this.userApi.loadByDepartmentId(event.page, event.size, this.departmentId));
        if (res.status == '000') {
            this.userSource = res.data;
        }
    }

    pageChangeOfMember(event: { page: number; size: number }) {
        this.loadMemberByDepartment(event);
    }

    onChangeRole(roleId: string) {
        let model = new PermissionRequestModel(this.departmentId, this.groupId, roleId);
        switch (this.selectItem) {
            case '0':
                this.loadMemberByGroupAndRoleAndDepartment(model);
                break;
            case '1':
                this.loadFunctionByPermission(model);
                break;
            case '2':
                this.loadScopeByPermission(model);
                break;
        }
    }

    async loadFunctionByPermission(model: PermissionRequestModel) {
        let res = await lastValueFrom(this.api.loadFunctionsByGroupAndRole(this.page, this.size, model));
        if (res.status == '000' && res.data) {
            this.functionTarget = res.data;
        } else {
            this.functionTarget = [];
        }
    }

    async loadScopeByPermission(model: PermissionRequestModel) {
        let res = await lastValueFrom(this.api.loadScopeByGroupAndRole(model));
        if (res.status == '000' && res.data) {
            this.scopeTarget = res.data;
        } else {
            this.scopeTarget = [];
        }
    }

    async loadMemberByGroupAndRoleAndDepartment(model: PermissionRequestModel) {
        let res = await lastValueFrom(this.api.loadMemberByGroupAndRoleAndDepartment(model));
        if (res.status == '000' && res.data) {
            this.userTarget = res.data;
        } else {
            this.userTarget = [];
        }
    }

    async loadRoleByGroup(id: string) {
        let res = await lastValueFrom(this.api.loadRoleByGroup(id));
        if (res.status == '000') {
            this.loading = true;
            this.roles = res.data;
            if (this.roles) {
                this.roleId = this.roles[0].value;
                this.selectFormRole?.patchValue({ roleId: this.roleId });
                this.groupId = id;
                this.visibleRole = true;
                this.visibleSelection = true;
                this.loadBySelectItem();
                this.onChangeRole(this.roleId);
            } else {
                this.visibleSelection = false;
            }
            this.loading = false;
        } else {
            this.toast.error('Failure', res.message);
        }
    }

    async onChangeFunction(model: PermissionUpdateSelectRequest) {
        let res = await lastValueFrom(this.api.updateChangeSelectFunction(model));
        if (res.status == '000') {
            this.toast.success('Successfully');
        } else {
            this.toast.error('Failure', res.message);
        }
    }

    async onChangeScope(model: PermissionUpdateSelectRequest) {
        let res = await lastValueFrom(this.api.updateChangeSelectScope(model));
        if (res.status == '000') {
            this.toast.success('Successfully');
        } else {
            this.toast.error('Failure', res.message);
        }
    }

    async onChangeMember(model: PermissionUpdateSelectRequest) {
        let res = await lastValueFrom(this.api.updateChangeSelectMember(model));
        if (res.status == '000') {
            this.toast.success('Successfully');
        } else {
            this.toast.error('Failure', res.message);
        }
    }
}
