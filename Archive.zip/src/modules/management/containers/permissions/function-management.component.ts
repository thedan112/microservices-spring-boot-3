import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { IPagedModel, PagedModel } from '@modules/common/models/page.model';
import { ToastService } from '@modules/common/services/toast.service';
import { AppCommonModule } from '@modules/common/app.common.module';
import { lastValueFrom } from 'rxjs';
import { FunctionLstComponent } from '@modules/management/components/permissions/function/function-lst.component';
import { FunctionCreateComponent } from '@modules/management/components/permissions/function/function-create.component';
import { FunctionEditComponent } from '@modules/management/components/permissions/function/function-edit.component';
import { FunctionResponse } from '@modules/management/models/function-response.model';
import { ApiFunctionService } from '@modules/management/services/api.function.service';
import { FunctionCreateRequest } from '@modules/management/models/function-create-request.model';
import { FunctionUpdateRequest } from '@modules/management/models/function-update-request.model';
import { ApiResourceService } from '@modules/management/services/api.resource.service';
import { SelectItem } from 'primeng/select';

@Component({
    selector: 'app-function-management',
    templateUrl: './function-management.component.html',
    styleUrls: ['./function-management.component.scss'],
    imports: [AppCommonModule, FunctionLstComponent, FunctionCreateComponent, FunctionEditComponent]
})
export class FunctionManagementContainer implements OnInit {
    display: boolean = false;
    isCreateDialog: boolean = false;
    isDetailDialog: boolean = false;
    isMappingDialog: boolean = false;
    loading: boolean = false;
    page: number = 0;
    size: number = 10;
    totalRecords: number = 0;
    searchForm!: FormGroup;
    createForm!: FormGroup;
    detailForm!: FormGroup;
    pagedData: IPagedModel<FunctionResponse> = new PagedModel();
    functionDetail: FunctionResponse = new FunctionResponse();
    filter!: string;
    targets: Array<any> = new Array();
    apis!: SelectItem[];
    views!: SelectItem[];

    column: any[] = [
        { field: 'name', header: 'Name', dataType: 'text' },
        { field: 'createdBy', header: 'Created By', dataType: 'text' },
        { field: 'createdDate', header: 'Created Date', dataType: 'datetime' },
        { field: 'updatedBy', header: 'Updated By', dataType: 'text' },
        { field: 'updatedDate', header: 'Updated Date', dataType: 'datetime' },
        { field: 'active', header: 'Active', dataType: 'status' },
        { field: 'id', header: 'Action', dataType: 'action' }
    ];

    constructor(
        private fb: FormBuilder,
        private toast: ToastService,
        private api: ApiFunctionService,
        private resourceApi: ApiResourceService
    ) {}

    ngOnInit(): void {
        this.formBuilderSearch();
        this.formBuilderCreate();
        this.formBuilderDetail();
        this.loadData();
        this.loadAllViews();
        this.loadAllAPIs();
    }

    formBuilderSearch() {
        this.searchForm = this.fb.group({ name: [null] });
    }

    formBuilderCreate() {
        this.createForm = this.fb.group({
            name: [null, Validators.required],
            description: [null],
            addResource: [null],
            resourceView:[null, Validators.required],
            resourceIds: [null]
        });
    }

    formBuilderDetail() {
        this.detailForm = this.fb.group({
            id: [null, Validators.required],
            name: [null, Validators.required],
            description: [null],
            addResource: [null],
            resourceView: [null, Validators.required],
            resourceIds: [null]
        });
    }

    onSearch(event: string) {
        this.page = 0;
        this.size = 10;
        this.filter = event;
        this.loadData();
    }

    async loadData() {
        this.loading = true;
        let res = await lastValueFrom(this.api.pages(this.page, this.size, this.filter));
        if (res.status == '000' && res.data) {
            this.pagedData = res.data;
        } else {
            this.toast.error('Failure', res.message);
        }
        this.loading = false;
    }

    async loadDetail(id: any) {
        this.loading = true;
        let res = await lastValueFrom(this.api.detail(id));
        if (res.status == '000' && res.data) {
            this.functionDetail = res.data;
        } else {
            this.toast.error('Failure', res.message);
        }
        this.loading = false;
    }

    onVisibleCreate(event: boolean) {
        if (event) {
            this.formBuilderCreate();
        }
        this.isCreateDialog = event;
    }

    onVisibleDetail(event: { id: string; visible: boolean }) {
        if (event.visible) {
            this.formBuilderDetail();
            this.loadDetail(event.id);
        }
        this.isDetailDialog = event.visible;
    }

    async onCreate(model: FunctionCreateRequest) {
        this.loading = true;
        let res = await lastValueFrom(this.api.create(model));
        if (res.status == '000') {
            this.onVisibleCreate(false);
            this.loadData();
            this.toast.success('Successfully');
        } else {
            this.toast.error('Failure', res.message);
        }
        this.loading = false;
    }

    async onUpdate(model: FunctionUpdateRequest) {
        this.loading = true;
        let res = await lastValueFrom(this.api.update(model));
        if (res.status == '000' && res.data) {
            this.page = 0;
            this.size = 10;
            this.loadData();
            this.onVisibleDetail({ id: '', visible: false });
            this.toast.success('Successfully');
        } else {
            this.toast.error('Failure', res.message);
        }
        this.loading = false;
    }

    onPageChange($event: any): void {
        this.page = $event.page;
        this.size = $event.rows;
        this.loadData();
    }

    async changeActive(event: { id: string; status: boolean }) {
        let res = await lastValueFrom(this.api.changeActive(event.id, event.status));
        if (res.status == '000') {
            this.toast.success('Successfully');
        } else {
            this.toast.error('Failure', res.message);
        }
    }

    async loadResourcesById(id: string) {
        let res = await lastValueFrom(this.api.loadResourcesById(id));
        if (res.status == '000') {
            this.targets = res.data.targets;
        } else {
            this.toast.error('Failure', res.message);
        }
    }

    async loadAllAPIs() {
        let res = await lastValueFrom(this.resourceApi.loadAllApis());
        if (res.status == '000') {
            this.apis = res.data;
        } else {
            this.toast.error('Failure', res.message);
        }
    }

    async loadAllViews() {
        let res = await lastValueFrom(this.resourceApi.loadAllViews());
        if (res.status == '000') {
            this.views = res.data;
        } else {
            this.toast.error('Failure', res.message);
        }
    }
}