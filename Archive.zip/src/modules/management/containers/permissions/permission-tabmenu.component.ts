import { Component, OnInit } from "@angular/core";
import { AppCommonModule } from "@modules/common/app.common.module";
import { MenuItem } from "primeng/api";
import { FunctionManagementContainer } from "./function-management.component";
import { PermissionManagementContainer } from "./permission-management.component";
import { ResourceManagementContainer } from "./resource-management.component";
import { ScopeManagementContainer } from "./scope-management.component";

@Component({
    selector: 'app-permission-tabmenu',
    templateUrl: './permission-tabmenu.component.html',
    styleUrls: ['./permission-tabmenu.component.scss'],
    imports: [AppCommonModule, ResourceManagementContainer, FunctionManagementContainer, PermissionManagementContainer, ScopeManagementContainer],
})
export class PermissionTabMenuContainer implements OnInit {
    items!: MenuItem[];
    activeItem: MenuItem | undefined; 
    selectItem: string | undefined;

    constructor() { }

    ngOnInit(): void {
        this.items = [
            { label: 'Policy', icon: 'pi pi-shield', command: () => { this.selectItem = '0' } },
            { label: 'Function', icon: 'pi pi-box', command: () => { this.selectItem = '1' } },
            { label: 'Resource', icon: 'pi pi-code', command: () => { this.selectItem = '2' } },
            { label: 'Scope', icon: 'pi pi-link', command: () => { this.selectItem = '3' } },
        ]
        this.activeItem = this.items[0];
        this.selectItem = '0';
    }

    onActiveItemChange(event: MenuItem) {
        this.activeItem = event;
    }
}