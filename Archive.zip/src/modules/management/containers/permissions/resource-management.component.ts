import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { IPagedModel, PagedModel } from '@modules/common/models/page.model';
import { UserResponse } from '../../models/user-response.model';
import { ToastService } from '@modules/common/services/toast.service';
import { lastValueFrom } from 'rxjs';
import { AppCommonModule } from '@modules/common/app.common.module';
import { ResourceResponse } from '../../models/resource-response.model';
import { ResourceCreateRequest } from '../../models/resource-create-request.model';
import { ResourceUpdateRequest } from '../../models/resource-update-request.model';
import { ApiResourceService } from '../../services/api.resource.service';
import { SelectItem } from 'primeng/select';
import { ApiScopeService } from '../../services/api.scope.service';
import { ResourceLstComponent } from '@modules/management/components/permissions/resource/resource-lst.component';
import { ResourceCreateComponent } from '@modules/management/components/permissions/resource/resource-create.component';
import { ResourceEditComponent } from '@modules/management/components/permissions/resource/resource-edit.component';

@Component({
    selector: 'app-resource-management',
    templateUrl: './resource-management.component.html',
    styleUrls: ['./resource-management.component.scss'],
    imports: [AppCommonModule, ResourceLstComponent, ResourceCreateComponent, ResourceEditComponent]
})
export class ResourceManagementContainer implements OnInit {
    display: boolean = false;
    isCreateDialog: boolean = false;
    isDetailDialog: boolean = false;
    loading: boolean = false;
    page: number = 0;
    size: number = 10;
    totalRecords: number = 0;
    searchForm!: FormGroup;
    createForm!: FormGroup;
    detailForm!: FormGroup;
    pagedData: IPagedModel<ResourceResponse> = new PagedModel();
    resourceDetail: ResourceResponse = new ResourceResponse();
    filter!: string;
    scopes?: SelectItem[];

    column: any[] = [
        { field: 'url', header: 'Url', dataType: 'text' },
        { field: 'description', header: 'Description', dataType: 'text' },
        { field: 'type', header: 'Type', dataType: 'text' },
        { field: 'active', header: 'Active', dataType: 'status' },
        { field: 'id', header: 'Action', dataType: 'action' }
    ];

    type: any[] = [
        { label: 'API', value: 'API' },
        { label: 'VIEW', value: 'VIEW' }
    ];

    constructor(
        private fb: FormBuilder,
        private toast: ToastService,
        private api: ApiResourceService,
        private apiScope: ApiScopeService
    ) {}

    ngOnInit(): void {
        this.formBuilderSearch();
        this.formBuilderCreate();
        this.formBuilderDetail();
        this.loadData();
        this.loadAllScope();
    }

    formBuilderSearch() {
        this.searchForm = this.fb.group({ url: [null] });
    }

    formBuilderCreate() {
        this.createForm = this.fb.group({
            url: [null, Validators.required],
            description: [null],
            type: [null, Validators.required],
            addScope: [null],
            scopeIds: [null]
        });
    }

    formBuilderDetail() {
        this.detailForm = this.fb.group({
            id: [null, Validators.required],
            url: [null, Validators.required],
            description: [null],
            type: [null, Validators.required],
            addScope: [null],
            scopeIds: [null]
        });
    }

    async loadAllScope() {
        let res = await lastValueFrom(this.apiScope.all());
        if (res.status == '000' && res.data) {
            this.scopes = res.data;
        }
    }

    onSearch(event: string) {
        this.page = 0;
        this.size = 10;
        this.filter = event;
        this.loadData();
    }

    async loadData() {
        this.loading = true;
        let res = await lastValueFrom(this.api.pages(this.page, this.size, this.filter));
        if (res.status == '000' && res.data) {
            this.pagedData = res.data;
        } else {
            this.toast.error('Failure', res.message);
        }
        this.loading = false;
    }

    async loadDetail(id: any) {
        this.loading = true;
        let res = await lastValueFrom(this.api.detail(id));
        if (res.status == '000' && res.data) {
            this.resourceDetail = res.data;
        } else {
            this.toast.error('Failure', res.message);
        }
        this.loading = false;
    }

    onVisibleCreate(event: boolean) {
        if (event) {
            this.formBuilderCreate();
        }
        this.isCreateDialog = event;
    }

    onVisibleDetail(event: { id: string; visible: boolean }) {
        if (event.visible) {
            this.formBuilderDetail();
            this.loadDetail(event.id);
        }
        this.isDetailDialog = event.visible;
    }

    async onCreate(model: ResourceCreateRequest) {
        this.loading = true;
        let res = await lastValueFrom(this.api.create(model));
        if (res.status == '000') {
            this.onVisibleCreate(false);
            this.loadData();
            this.toast.success('Successfully');
        } else {
            this.toast.error('Failure', res.message);
        }
        this.loading = false;
    }

    async onUpdate(model: ResourceUpdateRequest) {
        this.loading = true;
        let res = await lastValueFrom(this.api.update(model));
        if (res.status == '000' && res.data) {
            this.page = 0;
            this.size = 10;
            this.loadData();
            this.onVisibleDetail({ id: '', visible: false });
            this.toast.success('Successfully');
        } else {
            this.toast.error('Failure', res.message);
        }
        this.loading = false;
    }

    onPageChange($event: any): void {
        this.page = $event.page;
        this.size = $event.rows;
        this.loadData();
    }

    async changeActive(event: { id: string; status: boolean }) {
        let res = await lastValueFrom(this.api.changeActive(event.id, event.status));
        if (res.status == '000') {
            this.toast.success('Successfully');
        } else {
            this.toast.error('Failure', res.message);
        }
    }
}
