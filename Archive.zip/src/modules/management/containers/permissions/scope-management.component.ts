import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { IPagedModel, PagedModel } from '@modules/common/models/page.model';
import { ToastService } from '@modules/common/services/toast.service';
import { AppCommonModule } from '@modules/common/app.common.module';
import { lastValueFrom } from 'rxjs';
import { ScopeLstComponent } from '@modules/management/components/permissions/scope/scope-lst.component';
import { ScopeCreateComponent } from '@modules/management/components/permissions/scope/scope-create.component';
import { ScopeEditComponent } from '@modules/management/components/permissions/scope/scope-edit.component';
import { ScopeResponse } from '@modules/management/models/scope-response.model';
import { ApiScopeService } from '@modules/management/services/api.scope.service';
import { FunctionUpdateRequest } from '@modules/management/models/function-update-request.model';
import { FunctionCreateRequest } from '@modules/management/models/function-create-request.model';


@Component({
    selector: 'app-scope-management',
    templateUrl: './scope-management.component.html',
    styleUrls: ['./scope-management.component.scss'],
    imports: [AppCommonModule, ScopeLstComponent, ScopeCreateComponent, ScopeEditComponent]
})
export class ScopeManagementContainer implements OnInit {
    display: boolean = false;
    isCreateDialog: boolean = false;
    isDetailDialog: boolean = false;
    isMappingDialog: boolean = false;
    loading: boolean = false;
    page: number = 0;
    size: number = 10;
    totalRecords: number = 0;
    searchForm!: FormGroup;
    createForm!: FormGroup;
    detailForm!: FormGroup;
    pagedData: IPagedModel<ScopeResponse> = new PagedModel();
    scopeDetail: ScopeResponse = new ScopeResponse();
    filter!: string;
    sources: Array<any> = new Array();
    targets: Array<any> = new Array();
    scopes: Array<ScopeResponse> = new Array();

    column: any[] = [
        { field: 'name', header: 'Name', dataType: 'text' },
        { field: 'id', header: 'Action', dataType: 'action' },
    ];

    constructor(
        private fb: FormBuilder,
        private toast: ToastService,
        private api: ApiScopeService
    ) {}

    ngOnInit(): void {
        this.formBuilderSearch();
        this.formBuilderCreate();
        this.formBuilderDetail();
        this.loadData();
    }

    formBuilderSearch() {
        this.searchForm = this.fb.group({ name: [null] });
    }

    formBuilderCreate() {
        this.createForm = this.fb.group({
            name: [null, Validators.required],
        });
    }

    formBuilderDetail() {
        this.detailForm = this.fb.group({
            id: [null, Validators.required],
            name: [null, Validators.required],
        });
    }

    onSearch(event: string) {
        this.page = 0;
        this.size = 10;
        this.filter = event;
        this.loadData();
    }

    async loadData() {
        this.loading = true;
        let res = await lastValueFrom(this.api.pages(this.page, this.size, this.filter));
        if (res.status == '000' && res.data) {
            this.pagedData = res.data;
        } else {
            this.toast.error('Failure', res.message);
        }
        this.loading = false;
    }

    async loadDetail(id: any) {
        this.loading = true;
        let res = await lastValueFrom(this.api.detail(id));
        if (res.status == '000' && res.data) {
            this.scopeDetail = res.data;
        } else {
            this.toast.error('Successfully', res.message);
        }
        this.loading = false;
    }

    onVisibleCreate(event: boolean) {
        if (event) {
            this.formBuilderCreate();
            this.scopes = [];
        }
        this.isCreateDialog = event;
    }

    onVisibleDetail(event: { id: string; visible: boolean }) {
        if (event.visible) {
            this.formBuilderDetail();
            this.loadDetail(event.id);
        }
        this.isDetailDialog = event.visible;
    }

    async onCreate(model: FunctionCreateRequest) {
        this.loading = true;
        let res = await lastValueFrom(this.api.create(model));
        if (res.status == '000') {
            this.onVisibleCreate(false);
            this.loadData();
            this.toast.success('Successfully');
        } else {
            this.toast.error('Failure', res.message);
        }
        this.loading = false;
    }

    async onUpdate(model: FunctionUpdateRequest) {
        this.loading = true;
        let res = await lastValueFrom(this.api.update(model));
        if (res.status == '000' && res.data) {
            this.page = 0;
            this.size = 10;
            this.loadData();
            this.onVisibleDetail({ id: '', visible: false });
            this.toast.success('Successfully');
        } else {
            this.toast.error('Failure', res.message);
        }
        this.loading = false;
    }

    onPageChange($event: any): void {
        this.page = $event.page;
        this.size = $event.rows;
        this.loadData();
    }
}