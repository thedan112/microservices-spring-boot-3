import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AppCommonModule } from '@modules/common/app.common.module';
import { IPagedModel, PagedModel } from '@modules/common/models/page.model';
import { ToastService } from '@modules/common/services/toast.service';
import { GroupCreateComponent } from '@modules/management/components/users/group/group-create.component';
import { GroupEditComponent } from '@modules/management/components/users/group/group-edit.component';
import { GroupLstComponent } from '@modules/management/components/users/group/group-lst.component';
import { GroupCreateRequest } from '@modules/management/models/group-create-request.model';
import { GroupMemberRequest } from '@modules/management/models/group-member-request.model';
import { GroupResponse } from '@modules/management/models/group-response.model';
import { GroupUpdateRequest } from '@modules/management/models/group-update-request.model';
import { UserResponse } from '@modules/management/models/user-response.model';
import { ApiGroupService } from '@modules/management/services/api.group.service';
import { ApiRoleService } from '@modules/management/services/api.role.service';
import { SelectItem } from 'primeng/select';
import { lastValueFrom } from 'rxjs';

@Component({
    selector: 'app-group-management',
    templateUrl: './group-management.component.html',
    styleUrls: ['./group-management.component.scss'],
    imports: [AppCommonModule, GroupLstComponent, GroupCreateComponent, GroupEditComponent]
})
export class GroupManagementContainer implements OnInit {
    display: boolean = false;
    isCreateDialog: boolean = false;
    isDetailDialog: boolean = false;
    isMemberDialog: boolean = false;
    loading: boolean = false;
    page: number = 0;
    size: number = 10;
    totalRecords: number = 0;
    searchForm!: FormGroup;
    createForm!: FormGroup;
    detailForm!: FormGroup;
    pagedData: IPagedModel<GroupResponse> = new PagedModel();
    groupDetail: GroupResponse = new GroupResponse();
    filter!: string;
    roles!: SelectItem[];

    column: any[] = [
        { field: 'name', header: 'Name', dataType: 'text' },
        { field: 'createdBy', header: 'Created By', dataType: 'text' },
        { field: 'createdDate', header: 'Created Date', dataType: 'datetime' },
        { field: 'active', header: 'Active', dataType: 'active' },
        { field: 'id', header: 'Action', dataType: 'action' }
    ];

    constructor(
        private fb: FormBuilder,
        private toast: ToastService,
        private api: ApiGroupService,
        private apiRole: ApiRoleService,
    ) {}

    ngOnInit(): void {
        this.formBuilderSearch();
        this.formBuilderCreate();
        this.formBuilderDetail();
        this.loadRoles();
        this.loadData();
    }

    formBuilderSearch() {
        this.searchForm = this.fb.group({ name: [null] });
    }

    formBuilderCreate() {
        this.createForm = this.fb.group({
            name: [null, Validators.required],
            addRole: [null],
            roleIds: [null],
        });
    }

    formBuilderDetail() {
        this.detailForm = this.fb.group({
            id: [null, Validators.required],
            name: [null, Validators.required],
            addRole: [null],
            roleIds: [null],
        });
    }

    async loadRoles() {
        let res = await lastValueFrom(this.apiRole.all());
        if (res.status == '000' && res.data) {
            this.roles = res.data;
        }
    }

    onSearch(event: string) {
        this.page = 0;
        this.size = 10;
        this.filter = event;
        this.loadData();
    }

    async loadData() {
        this.loading = true;
        let res = await lastValueFrom(this.api.pages(this.page, this.size, this.filter));
        if (res.status == '000' && res.data) {
            this.pagedData = res.data;
        } else {
            this.toast.error('Failure', res.message);
        }
        this.loading = false;
    }

    async loadDetail(id: any) {
        let res = await lastValueFrom(this.api.detail(id));
        if(res.status == '000' && res.data) {
            this.groupDetail = res.data;
        } else {
            this.toast.error('Failure', res.message);
        }
    }

    onVisibleCreate(event: boolean) {
        if (event) {
            this.formBuilderCreate();
        }
        this.isCreateDialog = event;
    }

    onVisibleDetail(event: { id: string; visible: boolean }) {
        if (event.visible) {
            this.formBuilderDetail();
            this.loadDetail(event.id);
        }
        this.isDetailDialog = event.visible;
    }

    onVisibleMember(event: { id: string; visible: boolean }) {
        if (event.visible) {
        }
        this.isDetailDialog = event.visible;
    }

    async onCreate(model: GroupCreateRequest) {
        this.loading = true;
        let res = await lastValueFrom(this.api.create(model));
        if (res.status == '000') {
            this.onVisibleCreate(false);
            this.loadData();
            this.toast.success('Successfully');
        } else {
            this.toast.error('Failure', res.message);
        }
        this.loading = false;
    }

    async onUpdate(model: GroupUpdateRequest) {
        this.loading = true;
        let res = await lastValueFrom(this.api.update(model));
        if (res.status == '000' && res.data) {
            this.page = 0;
            this.size = 10;
            this.loadData();
            this.onVisibleDetail({ id: '', visible: false });
            this.toast.success('Successfully');
        } else {
            this.toast.error('Failure', res.message);
        }
        this.loading = false;
    }

    onPageChange($event: any): void {
        this.page = $event.page;
        this.size = $event.rows;
        this.loadData();
    }

    async changeActive(event: { id: string; status: boolean }) {
        let res = await lastValueFrom(this.api.changeActive(event.id, event.status));
        if (res.status == '000') {
            this.toast.success('Successfully');
        } else {
            this.toast.error('Failure', res.message);
        }
    }
}