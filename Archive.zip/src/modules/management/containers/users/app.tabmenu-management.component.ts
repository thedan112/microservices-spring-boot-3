import { Component, OnInit } from '@angular/core';
import { AppCommonModule } from '@modules/common/app.common.module';
import { MenuItem } from 'primeng/api';
import { DepartmentManagementContainer } from './department-management.component';
import { GroupManagementContainer } from './group-management.component';
import { RoleManagementContainer } from './role-management.component';
import { UserManagementContainer } from './user-management.component';

@Component({
    selector: 'app-user-tabmenu',
    templateUrl: './app.tabmenu-management.component.html',
    styleUrls: ['./app.tabmenu-management.component.scss'],
    imports: [AppCommonModule, UserManagementContainer, RoleManagementContainer, DepartmentManagementContainer, GroupManagementContainer]
})
export class UsersTabMenuContainer implements OnInit {
    items!: MenuItem[];
    activeItem: MenuItem | undefined;
    selectItem: string | undefined;

    constructor() {}

    ngOnInit(): void {
        this.items = [
            {
                label: 'User',
                icon: 'pi pi-user',
                command: () => {
                    this.selectItem = '0';
                }
            },
            {
                label: 'Department',
                icon: 'pi pi-warehouse',
                command: () => {
                    this.selectItem = '1';
                }
            },
            {
                label: 'Role',
                icon: 'pi pi-cog',
                command: () => {
                    this.selectItem = '2';
                }
            },
            {
                label: 'Group',
                icon: 'pi pi-users',
                command: () => {
                    this.selectItem = '3';
                }
            }
        ];
        this.activeItem = this.items[0];
        this.selectItem = '0';
    }

    onActiveItemChange(event: MenuItem) {
        this.activeItem = event;
    }
}
