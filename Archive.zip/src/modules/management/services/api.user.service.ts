import { HttpClient, HttpParams } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { ResponseModel } from "@modules/common/models/api.response.model";
import { ApiBaseService } from "@modules/common/services/api.base.service";
import { catchError, Observable } from "rxjs";
import { environments } from "src/environments/enviroment";

@Injectable({ providedIn: 'root' })
export class ApiUserService extends ApiBaseService {

    constructor(private http: HttpClient) { super() }

    pages(page: number, size: number, filter: string): Observable<ResponseModel<any>> {
        const url = environments.managementService + "/user/pages";
        let params = new HttpParams().set('page', page).set('size', size);
        if (filter) {
            params = params.set('email', filter);
        }
        return this.http.post<ResponseModel<any>>(url, null, { headers: this.getHeaders(), params: params })
            .pipe(catchError(this.handleError('pages', new ResponseModel<any>())));
    }

    loadByDepartmentId(page: number, size: number, departmentId: string): Observable<ResponseModel<any>> {
        const url = environments.managementService + "/user/department";
        let params = new HttpParams().set('page', page).set('size', size).set('id', departmentId);
        return this.http.post<ResponseModel<any>>(url, null, { headers: this.getHeaders(), params: params })
            .pipe(catchError(this.handleError('pages', new ResponseModel<any>())));
    }

    detail(id: string): Observable<ResponseModel<any>> {
        const url = environments.managementService + "/user/detail";
        let params = new HttpParams().set('id', id);
        return this.http.get<ResponseModel<any>>(url, { headers: this.getHeaders(), params: params })
            .pipe(catchError(this.handleError('detail', new ResponseModel<any>())));
    }

    getDetailFromAD(email: string): Observable<ResponseModel<any>> {
        const url = environments.managementService + "/user/validate-ad";
        let params = new HttpParams().set('email', email);
        return this.http.get<ResponseModel<any>>(url, { headers: this.getHeaders(), params: params })
            .pipe(catchError(this.handleError('detail-ad', new ResponseModel<any>())));
    }

    create(model: any): Observable<ResponseModel<any>> {
        const url = environments.managementService + "/user/create";
        return this.http.post<ResponseModel<any>>(url, model, { headers: this.getHeaders() })
            .pipe(catchError(this.handleError('create', new ResponseModel<any>())));
    }

    update(model: any): Observable<ResponseModel<any>> {
        const url = environments.managementService + "/user/update";
        return this.http.post<ResponseModel<any>>(url, model, { headers: this.getHeaders() })
            .pipe(catchError(this.handleError('update', new ResponseModel<any>())));
    }

    changeActive(id: string, status: boolean): Observable<ResponseModel<any>> {
        const url = environments.managementService + "/user/change-active";
        let params = new HttpParams().set('id', id).set('status', status);
        return this.http.post<ResponseModel<any>>(url, null, { headers: this.getHeaders(), params: params })
            .pipe(catchError(this.handleError('change-active', new ResponseModel<any>())));
    }

    changeLocked(id: string, status: boolean): Observable<ResponseModel<any>> {
        const url = environments.managementService + "/user/change-locked";
        let params = new HttpParams().set('id', id).set('status', status);
        return this.http.post<ResponseModel<any>>(url, null, { headers: this.getHeaders(), params: params })
            .pipe(catchError(this.handleError('change-locked', new ResponseModel<any>())));
    }
}