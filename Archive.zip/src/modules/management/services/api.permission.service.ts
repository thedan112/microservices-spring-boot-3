import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ResponseModel } from '@modules/common/models/api.response.model';
import { ApiBaseService } from '@modules/common/services/api.base.service';
import { PermissionRequestModel } from '@modules/management/models/permission-request.model';
import { PermissionUpdateSelectRequest } from '@modules/management/models/permission-update-select-request.model';
import { catchError, Observable } from 'rxjs';
import { environments } from 'src/environments/enviroment';

@Injectable({ providedIn: 'root' })
export class ApiPermissionService extends ApiBaseService {
    constructor(private http: HttpClient) {
        super();
    }

    loadGroupByDepartment(departmentId: string): Observable<ResponseModel<any>> {
        const url = environments.managementService + '/permission/groups';
        let params = new HttpParams().set('id', departmentId);
        return this.http.get<ResponseModel<any>>(url, { headers: this.getHeaders(), params: params }).pipe(catchError(this.handleError('load-groups-by-department', new ResponseModel<any>())));
    }

    loadMemberByDepartment(page: number, size: number, departmentId: string): Observable<ResponseModel<any>> {
        const url = environments.managementService + '/permission/members';
        let params = new HttpParams().set('page', page).set('size', size).set('id', departmentId);
        return this.http.get<ResponseModel<any>>(url, { headers: this.getHeaders(), params: params }).pipe(catchError(this.handleError('load-members-by-department', new ResponseModel<any>())));
    }

    loadRoleByGroup(groupId: string): Observable<ResponseModel<any>> {
        const url = environments.managementService + '/permission/roles';
        let params = new HttpParams().set('id', groupId);
        return this.http.get<ResponseModel<any>>(url, { headers: this.getHeaders(), params: params }).pipe(catchError(this.handleError('load-roles-by-group', new ResponseModel<any>())));
    }

    loadFunctionsByGroupAndRole(page: number, size: number, model: PermissionRequestModel): Observable<ResponseModel<any>> {
        const url = environments.managementService + '/permission/functions';
        let params = new HttpParams().set('page', page).set('size', size);
        return this.http.post<ResponseModel<any>>(url, model, { headers: this.getHeaders(), params: params }).pipe(catchError(this.handleError('load-functions-by-group-roles', new ResponseModel<any>())));
    }

    loadScopeByGroupAndRole(model: PermissionRequestModel): Observable<ResponseModel<any>> {
        const url = environments.managementService + '/permission/scopes';
        return this.http.post<ResponseModel<any>>(url, model, { headers: this.getHeaders()}).pipe(catchError(this.handleError('load-scopes-by-group-roles', new ResponseModel<any>())));
    }

    loadMemberByGroupAndRoleAndDepartment(model: PermissionRequestModel): Observable<ResponseModel<any>> {
        const url = environments.managementService + '/permission/members';
        return this.http.post<ResponseModel<any>>(url, model, { headers: this.getHeaders()}).pipe(catchError(this.handleError('load-members-by-group-roles', new ResponseModel<any>())));
    }

    updateChangeSelectFunction(model: PermissionUpdateSelectRequest): Observable<ResponseModel<any>> {
        const url = environments.managementService + '/permission/functions/update';
        return this.http.post<ResponseModel<any>>(url, model, { headers: this.getHeaders() }).pipe(catchError(this.handleError('update-change-select-functions', new ResponseModel<any>())));
    }

    updateChangeSelectScope(model: PermissionUpdateSelectRequest): Observable<ResponseModel<any>> {
        const url = environments.managementService + '/permission/scopes/update';
        return this.http.post<ResponseModel<any>>(url, model, { headers: this.getHeaders() }).pipe(catchError(this.handleError('update-change-select-scopes', new ResponseModel<any>())));
    }

    updateChangeSelectMember(model: PermissionUpdateSelectRequest): Observable<ResponseModel<any>> {
        const url = environments.managementService + '/permission/members/update';
        return this.http.post<ResponseModel<any>>(url, model, { headers: this.getHeaders() }).pipe(catchError(this.handleError('update-change-select-users', new ResponseModel<any>())));
    }
}
