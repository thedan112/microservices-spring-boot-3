import { HttpClient, HttpParams } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { ResponseModel } from "@modules/common/models/api.response.model";
import { ApiBaseService } from "@modules/common/services/api.base.service";
import { catchError, Observable } from "rxjs";
import { environments } from "src/environments/enviroment";
import { GroupMemberRequest } from "../models/group-member-request.model";

@Injectable({ providedIn: 'root' })
export class ApiGroupService extends ApiBaseService {
    constructor(private http: HttpClient) { super(); }

    all(): Observable<ResponseModel<any>> {
        const url = environments.managementService + "/group/all";
        return this.http.get<ResponseModel<any>>(url, { headers: this.getHeaders() })
            .pipe(catchError(this.handleError('all', new ResponseModel<any>())));
    }

    pages(page: number, size: number, filter: string): Observable<ResponseModel<any>> {
        const url = environments.managementService + "/group/pages";
        let params = new HttpParams().set('page', page).set('size', size);
        if (filter) {
            params = params.set('name', filter);
        }
        return this.http.post<ResponseModel<any>>(url, null, { headers: this.getHeaders(), params: params })
            .pipe(catchError(this.handleError('pages', new ResponseModel<any>())));
    }

    detail(id: string): Observable<ResponseModel<any>> {
        const url = environments.managementService + "/group/detail";
        let params = new HttpParams().set('id', id);
        return this.http.get<ResponseModel<any>>(url, { headers: this.getHeaders(), params: params })
            .pipe(catchError(this.handleError('detail', new ResponseModel<any>())));
    }

    create(model: any): Observable<ResponseModel<any>> {
        const url = environments.managementService + "/group/create";
        return this.http.post<ResponseModel<any>>(url, model, { headers: this.getHeaders() })
            .pipe(catchError(this.handleError('create', new ResponseModel<any>())));
    }

    update(model: any): Observable<ResponseModel<any>> {
        const url = environments.managementService + "/group/update";
        return this.http.post<ResponseModel<any>>(url, model, { headers: this.getHeaders() })
            .pipe(catchError(this.handleError('update', new ResponseModel<any>())));
    }

    changeActive(id: string, status: boolean): Observable<ResponseModel<any>> {
        const url = environments.managementService + "/group/change-active";
        let params = new HttpParams().set('id', id).set('status', status);
        return this.http.post<ResponseModel<any>>(url, null, { headers: this.getHeaders(), params: params })
            .pipe(catchError(this.handleError('change-active', new ResponseModel<any>())));
    }

    loadMembers(model: GroupMemberRequest): Observable<ResponseModel<any>> {
        const url = environments.managementService + "/group/members";
        return this.http.post<ResponseModel<any>>(url, model, { headers: this.getHeaders() })
            .pipe(catchError(this.handleError('load-members', new ResponseModel<any>())));
    }
}