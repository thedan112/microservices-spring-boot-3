import { Component, OnInit } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { LoginRequestModel } from '../models/login.req.model';
import { ToastService } from '@modules/common/services/toast.service';
import { AuthModule } from '../auth.module';
import { ApiAuthService } from '../services/api.auth.service';
import { CommonUserService } from '@modules/common/services/app.user.service';
import { UriConstant } from '@modules/common/constant/app.uri.data';

@Component({
    selector: 'app-auth',
    templateUrl: './app.auth.html',
    styleUrls: ['./app.auth.scss'],
    imports: [AuthModule]
})
export class AuthComponent implements OnInit {
    formGroup: FormGroup = this.fb.group({
        username: ['', Validators.required],
        password: ['', Validators.required],
    })
    routerLink: RouterLink | undefined;
    constructor(private fb: FormBuilder,
        private toast: ToastService,
        private commonUser: CommonUserService,
        private api: ApiAuthService,
        private router: Router) { }

    ngOnInit(): void {
    }

    onLogin() {
        if (this.formGroup?.valid) {
            let req = { ...this.formGroup.value } as LoginRequestModel;
            this.api.login(req).subscribe(res => {
                if (res.status == '000' && res.data?.token) {
                    this.commonUser.user = {
                        username: res.data?.username || '',
                        expiry: res.data?.expiry || 0,
                        token: res.data.token || '',
                    }
                    this.router.navigate([UriConstant.home.dashboard]);
                } else {
                    if (res.status == undefined || res.status == null) {
                        this.toast.error('Hệ thống bảo trì, Vui lòng quay lại sao ít phút');
                    } else {
                        this.toast.error('Thất bại', res.message);
                    }
                }
            })
        }
    }
}
