import { NgModule } from "@angular/core";
import { ButtonModule } from 'primeng/button';
import { PasswordModule } from 'primeng/password';
import { InputText } from 'primeng/inputtext';
import { RouterLink } from '@angular/router';
import { IconFieldModule } from 'primeng/iconfield';
import { InputIconModule } from 'primeng/inputicon';
import { InputTextModule } from 'primeng/inputtext';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Toast, ToastModule } from 'primeng/toast';
import { ApiAuthService } from "./services/api.auth.service";

@NgModule({
    imports: [
        FormsModule, 
        ToastModule,
        Toast,
        RouterLink, 
        ButtonModule,
        PasswordModule, 
        InputText,
        IconFieldModule,
        InputIconModule,
        InputTextModule,
        ReactiveFormsModule
    ],
    exports: [
        FormsModule, 
        ToastModule,
        RouterLink, 
        ButtonModule,
        PasswordModule, 
        InputText,
        IconFieldModule,
        InputIconModule,
        InputTextModule,
        ReactiveFormsModule,
    ],
    providers: [ApiAuthService]
})
export class AuthModule { }