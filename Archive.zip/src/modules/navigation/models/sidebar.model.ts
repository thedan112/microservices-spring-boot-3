export interface Breadcrumb {
    title?: string;
} 

export interface SBRouteData {
    // path: string;
    breadcrumb?: Breadcrumb;
}

export interface SideNavItem {
    icon?: string;
    label?: string;
    routerLink?: string[];
    visible?: boolean;
    items?: SideNavItem[];
    expand?: boolean;
    separator?: boolean;
}

export interface sideNav {
    title: string,
    icon?: string,
    type: string,
    expand?: boolean,
    visible?: boolean,
    items?: SideNavItem[];
}
