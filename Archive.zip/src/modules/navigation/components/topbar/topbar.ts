import { Component } from '@angular/core';
import { MenuItem } from 'primeng/api';
import { Router, RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { StyleClassModule } from 'primeng/styleclass';
import { LayoutService } from '@modules/navigation/services/layout.service';
import { DividerModule } from 'primeng/divider';
import { AppSubTop } from '../config/app.subtop';
import { CommonUserService } from '@modules/common/services/app.user.service';

@Component({
    selector: 'app-topbar',
    templateUrl: './topbar.html',
    styleUrls: ['./topbar.scss'],
    imports: [RouterModule, CommonModule, StyleClassModule, DividerModule, AppSubTop, DividerModule]
})
export class TopbarComponent {
    items!: MenuItem[];
    username: string | '';
    constructor(
        public layoutService: LayoutService,
        private commonUserService: CommonUserService
    ) {
        this.username = commonUserService.getUsername();
    }

    toggleDarkMode() {
        this.layoutService.layoutConfig.update((state) => ({ ...state, darkTheme: !state.darkTheme }));
    }
}
