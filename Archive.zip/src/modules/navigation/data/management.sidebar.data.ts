import { SideNavItem } from "../models/sidebar.model";

export const ManagementSideNav: SideNavItem[] = [{
    label: 'Access Control',
    items: [
        {
            label: 'Management',
            icon: 'pi pi-fw pi-spin pi-cog',
            visible: true,
            items: [
                { label: 'Users', visible: true, icon: 'pi pi-fw pi-users', routerLink: ['/management/users'] },
                { label: 'Permission', visible: true, icon: 'pi pi-fw pi-sitemap', routerLink: ['/management/permission'] },
            ]
        },
    ]
},
]