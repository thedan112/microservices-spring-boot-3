export const environments = {
    production: false,
    service: 'http://localhost:8762',
    managementService: 'http://localhost:8762/api/management'
}