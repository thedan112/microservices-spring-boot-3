package com.migration.component;

import java.util.UUID;

import org.quartz.CronScheduleBuilder;
import org.quartz.Job;
import org.quartz.JobBuilder;
import org.quartz.JobDataMap;
import org.quartz.JobDetail;
import org.quartz.Scheduler;
import org.quartz.Trigger;
import org.quartz.TriggerBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class SchedulerServiceImpl {

	@Autowired
	Scheduler scheduler;

	public JobDetail buildJobDetail(Class<? extends Job> clazz, String key, String value, String desc,
			String identity) {
		JobDataMap jobDataMap = new JobDataMap();
		jobDataMap.put(key, value);
		return JobBuilder.newJob(clazz).withIdentity(UUID.randomUUID().toString(), identity).withDescription(desc)
				.usingJobData(jobDataMap).storeDurably().build();
	}

	public Trigger buildTrigger(String name, String cronExpression) {
		return TriggerBuilder.newTrigger().withIdentity(name, cronExpression)
				.withSchedule(CronScheduleBuilder.cronSchedule(cronExpression)).build();
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public void buildScheduleJob(String className, String name, String cronExpression) {
		Class clazz = buildClassJob(className);
		if (clazz == null)
			return;
		JobDetail detail = buildJobDetail(clazz, clazz.getSimpleName(), clazz.getSimpleName(),
				"Job for class " + clazz.getSimpleName(), cronExpression);
		Trigger trigger = buildTrigger(name, cronExpression);
		try {
			scheduler.unscheduleJob(trigger.getKey());
			scheduler.scheduleJob(detail, trigger);
		} catch (Exception e) {
			log.error("buildScheduleJob error by: {}", e.getMessage());
		}
	}

	@SuppressWarnings("rawtypes")
	public static Class buildClassJob(String className) {
		try {
			return Class.forName(className);
		} catch (ClassNotFoundException e) {
			log.error("buildClassJob error by: {}", e.getMessage());
		}
		return null;
	}
}
