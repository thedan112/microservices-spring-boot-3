package com.migration.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.migration.repository.GenericDocDetailsV2ApiRecordRepository;
import com.migration.service.IProcessService;

@Service
public class TransactionServiceImpl implements IProcessService {
	@Autowired
	GenericDocDetailsV2ApiRecordRepository repo;

	@Override
	public void getDataMigration() {
		
	}

	@Override
	public void generateXmlFile(Object data) {
	}
}
