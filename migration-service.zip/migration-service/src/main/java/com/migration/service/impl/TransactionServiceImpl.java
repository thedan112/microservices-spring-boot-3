package com.migration.service.impl;

import org.springframework.stereotype.Service;

import com.migration.service.IProcessService;

@Service
public class TransactionServiceImpl implements IProcessService {
	@Override
	public void getDataMigration() {
		
	}

	@Override
	public void generateXmlFile(Object data) {
	}
}
