package com.migration.service;

import java.util.List;

import com.migration.model.request.CreateJobRequest;
import com.migration.model.request.TriggerJobRequest;

public interface ISchedulerService {

	public List<?> all();

	public Boolean create(CreateJobRequest req);

	public Boolean trigger(TriggerJobRequest req);

	public Boolean runOne(String name);
}
