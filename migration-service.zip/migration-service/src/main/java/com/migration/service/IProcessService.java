package com.migration.service;

public interface IProcessService {

	public void getDataMigration();
	
	public void generateXmlFile(Object data);
}
