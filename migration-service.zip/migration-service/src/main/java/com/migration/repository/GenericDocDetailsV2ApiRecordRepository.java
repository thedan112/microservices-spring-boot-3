package com.migration.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.migration.entity.GenericDocDetailsV2ApiRecordEntity;

public interface GenericDocDetailsV2ApiRecordRepository
		extends JpaRepository<GenericDocDetailsV2ApiRecordEntity, String> {
}
