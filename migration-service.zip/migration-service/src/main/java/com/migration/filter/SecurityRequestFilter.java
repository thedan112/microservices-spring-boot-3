package com.migration.filter;

import java.io.IOException;

import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@Component
public class SecurityRequestFilter extends OncePerRequestFilter {

	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
			throws ServletException, IOException {

		filterChain.doFilter(request, response);
//		ContentCachingRequestWrapper requestWrapper = new ContentCachingRequestWrapper(request);
//		ContentCachingResponseWrapper responseWrapper = new ContentCachingResponseWrapper(response);

//        long startTime = System.currentTimeMillis();
//		filterChain.doFilter(requestWrapper, responseWrapper);
//		long duration = System.currentTimeMillis() - startTime;
//
//		String requestBody = getRequestBody(requestWrapper);
//		String responseBody = getResponseBody(responseWrapper);
//
//        log.info("method={} uri={} status={} duration_ms={} request_body={} response_body={}",
//                request.getMethod(),
//                request.getRequestURI(),
//                response.getStatus(),
//                duration,
//                requestBody.replace("\n", "").replace("\r", ""), // Loại bỏ ký tự xuống dòng
//                responseBody.replace("\n", "").replace("\r", "")
//        );
//		
//		responseWrapper.copyBodyToResponse();
	}

//	private String getRequestBody(ContentCachingRequestWrapper request) {
//		byte[] buf = request.getContentAsByteArray();
//		if (buf.length > 0) {
//			try {
//				return new String(buf, 0, buf.length, request.getCharacterEncoding());
//			} catch (UnsupportedEncodingException ex) {
//				return "[UNSUPPORTED ENCODING]";
//			}
//		}
//		return "[NO BODY]";
//	}
//
//	private String getResponseBody(ContentCachingResponseWrapper response) {
//		byte[] buf = response.getContentAsByteArray();
//		if (buf.length > 0) {
//			try {
//				return new String(buf, 0, buf.length, response.getCharacterEncoding());
//			} catch (UnsupportedEncodingException ex) {
//				return "[UNSUPPORTED ENCODING]";
//			}
//		}
//		return "[NO BODY]";
//	}
}
