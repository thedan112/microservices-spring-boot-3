package com.migration.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Table;

@Entity
@Table(name = "GENERICDOCDETAILSV2APIRECORDS")
public class GenericDocDetailsV2ApiRecordEntity {

}
