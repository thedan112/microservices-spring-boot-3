package com.migration.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.migration.model.thymeleaf.JobScheduler;
import com.migration.service.impl.JobSchedulerService;

@Controller
@RequestMapping(value = "/jobs")
public class SchedulerController {

	@Autowired
	private JobSchedulerService jobService;

	@GetMapping
	public String listJobs(Model model) {
		model.addAttribute("jobs", jobService.getAllJobs());
		model.addAttribute("newJob", new JobScheduler());
		return "jobs/list";
	}

	@PostMapping("/create")
	public String createJob(@ModelAttribute JobScheduler job, RedirectAttributes redirectAttributes) {
		try {
			jobService.createJob(job);
			redirectAttributes.addFlashAttribute("success", "Job created successfully!");
		} catch (Exception e) {
			redirectAttributes.addFlashAttribute("error", "Error creating job: " + e.getMessage());
		}
		return "redirect:/jobs";
	}

	@PostMapping("/delete/{id}")
	public String deleteJob(@PathVariable Long id, RedirectAttributes redirectAttributes) {
		try {
			jobService.deleteJob(id);
			redirectAttributes.addFlashAttribute("success", "Job deleted successfully!");
		} catch (Exception e) {
			redirectAttributes.addFlashAttribute("error", "Error deleting job: " + e.getMessage());
		}
		return "redirect:/jobs";
	}

	@PostMapping("/stop/{id}")
	public String stopJob(@PathVariable Long id, RedirectAttributes redirectAttributes) {
		try {
			jobService.stopJob(id);
			redirectAttributes.addFlashAttribute("success", "Job stopped successfully!");
		} catch (Exception e) {
			redirectAttributes.addFlashAttribute("error", "Error stopping job: " + e.getMessage());
		}
		return "redirect:/jobs";
	}

	@PostMapping("/start/{id}")
	public String startJob(@PathVariable Long id, RedirectAttributes redirectAttributes) {
		try {
			jobService.startJob(id);
			redirectAttributes.addFlashAttribute("success", "Job started successfully!");
		} catch (Exception e) {
			redirectAttributes.addFlashAttribute("error", "Error starting job: " + e.getMessage());
		}
		return "redirect:/jobs";
	}

	@PostMapping("/run/{id}")
	public String runJobManually(@PathVariable Long id, RedirectAttributes redirectAttributes) {
		try {
			jobService.runJobManually(id);
			redirectAttributes.addFlashAttribute("success", "Job executed manually!");
		} catch (Exception e) {
			redirectAttributes.addFlashAttribute("error", "Error running job: " + e.getMessage());
		}
		return "redirect:/jobs";
	}
}
