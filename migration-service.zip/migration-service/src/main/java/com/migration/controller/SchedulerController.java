package com.migration.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.migration.model.request.CreateJobRequest;
import com.migration.service.ISchedulerService;

@RestController
@RequestMapping(value = "/schedule", produces = "application/json")
public class SchedulerController {
	@Autowired
	ISchedulerService service;

	@GetMapping(value = "/all")
	public ResponseEntity<?> getAllJob() {
		return ResponseEntity.ok(service.all());
	}

	@PostMapping(value = "/create")
	public ResponseEntity<?> createJob(@RequestBody CreateJobRequest req) {
		return ResponseEntity.ok(service.create(req));
	}

//	@PostMapping("/trigger")
//	public ResponseEntity<?> triggerJob(@RequestBody TriggerJobRequest req) {
//		return ResponseEntity.ok(service.start(req));
//	}
//
//	@PostMapping("/runOne")
//	public ResponseEntity<?> trigger(@RequestParam(value = "name") String name) {
//		return ResponseEntity.ok(service.start(req));
//	}
}
