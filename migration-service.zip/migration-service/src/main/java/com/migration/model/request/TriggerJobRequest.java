package com.migration.model.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class TriggerJobRequest {

	@NotBlank(message = "Name cannot null or empty")
	private String name;

	@NotBlank(message = "Cron Expression cannot null or empty")
	private String cronExpression;

	@NotNull(message = "Active Input true/false")
	private Boolean active;
}
