package com.migration.model.thymeleaf;

import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class JobScheduler {

	private Long id;
	private String jobName;
	private String cronExpression;
	private String description;
	private String status;
	private LocalDateTime createdAt;
	private LocalDateTime lastRunAt;
	private String lastRunResult;

	protected void onCreate() {
		createdAt = LocalDateTime.now();
	}
}
