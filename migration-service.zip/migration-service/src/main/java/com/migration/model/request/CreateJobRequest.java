package com.migration.model.request;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class CreateJobRequest {

	@NotBlank(message = "Name: is not null or empty")
	private String name;
	@NotBlank(message = "Cron Expression: is not null or empty")
	private String cronExpression;
	@NotBlank(message = "Method Name: is not null or empty")
	private String methodName;
}
