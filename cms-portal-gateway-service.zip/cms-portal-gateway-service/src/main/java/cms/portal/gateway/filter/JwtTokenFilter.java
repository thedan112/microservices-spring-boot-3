package cms.portal.gateway.filter;

import java.util.Base64;
import java.util.Date;
import java.util.function.Function;

import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

import org.springframework.stereotype.Component;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.MalformedJwtException;
import io.jsonwebtoken.UnsupportedJwtException;
import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class JwtTokenFilter {

	private static final String JWT_SECRET = "HLiHI2DmTkmJs9Df4iQgmx52e0hMcfBH";
	private static final String ISSUER = "portal-service";
	private SecretKey secretKey;

	@PostConstruct
	public void initKey() {
		byte[] privateKeyBytes = Base64.getEncoder().encode(JWT_SECRET.getBytes());
		this.secretKey = new SecretKeySpec(privateKeyBytes, "HmacSHA256");
	}

	public Boolean validateToken(String token) {
		try {
			Claims claims = getAllClaimsFromToken(token);
			Date expired = claims.getExpiration();
			if (expired.before(new Date())) {
				log.error("[Username: {}] Token had expired at {}", claims.getSubject(), expired);
				return false;
			}
			return true;
		} catch (MalformedJwtException e) {
			log.error("Invalid JWT Token: {}", e.getMessage());
		} catch (ExpiredJwtException e) {
			log.error("JWT Token is expired: {}", e.getMessage());
		} catch (UnsupportedJwtException e) {
			log.error("JWT Token is unsupported: {}", e.getMessage());
		} catch (IllegalArgumentException e) {
			log.error("JWT claims string is empty: {}", e.getMessage());
		} catch (Exception e) {
			log.error("JWT invalid signature: {}", e.getMessage());
		}
		return false;
	}

	private Claims getAllClaimsFromToken(String token) {
		return Jwts.parser().verifyWith(secretKey).requireIssuer(ISSUER).build().parseSignedClaims(token).getPayload();
	}

	public <T> T getClaimFromToken(String token, Function<Claims, T> claimsResolver) {
		final Claims claims = getAllClaimsFromToken(token);
		return claimsResolver.apply(claims);
	}
}