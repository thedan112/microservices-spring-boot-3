package cms.portal.gateway.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class ResponseData<T> {

	private String status;
	private String path;
	private String message;
	private T data;

	public static <T> ResponseData<T> error(String status, String path, String message) {
		return new ResponseData<T>(status, path, message, null);
	}

	public static <T> ResponseData<T> internalServerError(String path) {
		return new ResponseData<T>("500", path, "Internal Server Error", null);
	}

	public static <T> ResponseData<T> unauthorized(String path) {
		return new ResponseData<T>("401", path, "Unauthorized", null);
	}

	public static <T> ResponseData<T> accessDenied(String path) {
		return new ResponseData<T>("403", path, "Forbidden", null);
	}
}