package cms.portal.gateway.filter;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class JacksonUtil {

	private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();

	static {
		OBJECT_MAPPER.configure(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT, true);
		OBJECT_MAPPER.configure(DeserializationFeature.ACCEPT_EMPTY_ARRAY_AS_NULL_OBJECT, true);
	}

	@SuppressWarnings("unchecked")
	public static <T> T readValue(String obj, Class<?> clazz) {
		try {
			return (T) OBJECT_MAPPER.readValue(obj, clazz);
		} catch (Exception e) {
			log.error("{}, readValue error: {}", obj, e.getMessage());
		}
		return null;
	}

	@SuppressWarnings("unchecked")
	public static <T> T convertValue(Object obj, TypeReference<?> type) {
		try {
			return (T) OBJECT_MAPPER.convertValue(obj, type);
		} catch (Exception e) {
			log.error("{}, convertValue error: {}", obj, e.getMessage());
		}
		return null;
	}

	public static String jsonParser(Object o) {
		try {
			return OBJECT_MAPPER.writeValueAsString(o);
		} catch (Exception e) {
			log.error("Parser to JSON error: {}", e.getMessage());
		}
		return null;
	}
}
