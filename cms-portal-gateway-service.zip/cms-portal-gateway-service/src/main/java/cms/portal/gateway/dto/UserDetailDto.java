package cms.portal.gateway.dto;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonDeserialize
public class UserDetailDto implements Serializable {
	private static final long serialVersionUID = -3743416549736329940L;
	
	private String id;
	private String username;
	private String email;
	private Date expiry;
	private Integer locked;
	private Integer active;
	private String type;
	private String department;
	private List<String> roles;
}