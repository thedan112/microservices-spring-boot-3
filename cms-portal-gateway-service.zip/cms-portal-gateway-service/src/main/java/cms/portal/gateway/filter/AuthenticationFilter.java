package cms.portal.gateway.filter;

import java.nio.charset.StandardCharsets;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.gateway.filter.GatewayFilter;
import org.springframework.cloud.gateway.filter.factory.AbstractGatewayFilterFactory;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.core.io.buffer.DataBuffer;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.server.ServerWebExchange;

import cms.portal.gateway.dto.ResponseData;
import cms.portal.gateway.model.ValidationPathRequest;
import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Component
@Slf4j
public class AuthenticationFilter extends AbstractGatewayFilterFactory<AuthenticationFilter.Config> {
	@Autowired
	RouteValidatorFilter validator;
	@Autowired
	RestTemplate restTemplate;

	public AuthenticationFilter() {
		super(Config.class);
	}

	public static class Config {
	}

	@Override
	public GatewayFilter apply(Config config) {
		return ((exchange, chain) -> {
			if (validator.isSecured.test(exchange.getRequest())) {
				String path = exchange.getRequest().getPath().toString();
				if (!exchange.getRequest().getHeaders().containsKey(HttpHeaders.AUTHORIZATION)) {
					log.error("Status: 401, Path: {}, Msg: {}", path, "Unauthorized");
					return writeErrorResponse(exchange, 401, path, "Unauthorized, Please login again");
				}
				String authHeader = exchange.getRequest().getHeaders().get(HttpHeaders.AUTHORIZATION).get(0);
				if (authHeader != null && authHeader.startsWith("Bearer ")) {
					authHeader = authHeader.substring(7);
				} else {
					log.error("Status: 401, Path: {}, Msg: {}", path, "Token invalid or expired");
					return writeErrorResponse(exchange, 401, path, "Unauthorized, Please login again");
				}
				try {
					if (!hasPermission(path, authHeader)) {
						return writeErrorResponse(exchange, 403, path, "Please, Access denined");
					}
				} catch (Exception e) {
					log.error("Status: 500-InternalServerError, Path: {}, Msg: {}", path, e.getMessage());
					return writeErrorResponse(exchange, 500, path, "Internal Server Error");
				}
			}
			return chain.filter(exchange);
		});
	}

	private Mono<Void> writeErrorResponse(ServerWebExchange exchange, int status, String path, String message) {
		exchange.getResponse().getHeaders().add("Content-Type", "application/json");
		ResponseData<String> response = ResponseData.error(String.valueOf(status), path, message);
		String json = JacksonUtil.jsonParser(response);
		byte[] bytes = json.getBytes(StandardCharsets.UTF_8);
		DataBuffer buffer = exchange.getResponse().bufferFactory().wrap(bytes);
		return exchange.getResponse().writeWith(Flux.just(buffer));
	}

	private Boolean hasPermission(String path, String token) {
		ParameterizedTypeReference<ResponseData<Boolean>> paramType = new ParameterizedTypeReference<>() {
		};
		try {
			ValidationPathRequest request = new ValidationPathRequest(path);
			HttpHeaders httpHeaders = new HttpHeaders();
			httpHeaders.set("Content-Type", "application/json");
			httpHeaders.setBearerAuth(token);
			HttpEntity<?> httpEntity = new HttpEntity<>(request, httpHeaders);
			ResponseData<Boolean> res = restTemplate.exchange("http://localhost:8081/auth/validate-permission", HttpMethod.POST, httpEntity, paramType).getBody();
			if (!"000".equals(res.getStatus()))
				return false;
			return true;
		} catch (RestClientException e) {
			log.error("Method: POST, Endpoint: {}, RestClientException: {}", path, e.getMessage());
		} catch (Exception e) {
			log.error("Method: POST, Endpoint: {}, Exception: {}", path, e.getMessage());
		}
		return false;
	}
}
