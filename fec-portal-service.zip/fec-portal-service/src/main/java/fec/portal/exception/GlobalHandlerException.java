package fec.portal.exception;

import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import fec.portal.am.enums.Messages;
import fec.portal.dto.ResponseData;
import lombok.extern.slf4j.Slf4j;

@RestControllerAdvice
@Slf4j
public class GlobalHandlerException {

//	@ExceptionHandler(InternalErrorException.class)
//	public ResponseEntity<?> internalServerException(InternalErrorException e) {
//		var response = ApiResponse.error(StatusCode.INTERNAL_ERROR);
//		return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
//	}
//	
//	@ExceptionHandler(ResourceNotFoundException.class)
//	public ResponseEntity<?> reousrceNotFoundException(ResourceNotFoundException ex) {
//		var response = ApiResponse.error(StatusCode.ERROR_RESOURCE_NOT_FOUND);
//		return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
//	}

	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<?> methodArgumentNotValidException(MethodArgumentNotValidException ex) {
		Map<String, String> errors = new HashMap<>();
		ex.getBindingResult().getFieldErrors().forEach(error -> {
			errors.put(error.getField(), error.getDefaultMessage());
		});
		var response = ResponseData.error(Messages.BAD_REQUEST.getStatus(), errors.toString());
		return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(RestClientException.class)
	public void restClientExceltpion(RestClientException ex) {
		log.error(ex.getMessage());

	}
}