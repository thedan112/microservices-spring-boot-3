package fec.portal.filter;

import java.io.IOException;
import java.nio.charset.StandardCharsets;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import fec.portal.dto.UserDetailDto;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@Component
public class SecurityRequestFilter extends OncePerRequestFilter {
	@Autowired
	JwtTokenFilter jwtTokenFilter;

	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
			throws ServletException, IOException {
		String authHeader = request.getHeader(HttpHeaders.AUTHORIZATION);
		UserDetailDto userDetails = null;
		String jwtToken = null;
		if (StringUtils.isNotBlank(authHeader) && authHeader.startsWith("Bearer ")) {
			jwtToken = authHeader.substring(7);
			userDetails = jwtTokenFilter.validateToken(jwtToken);
		}
		if (userDetails != null && SecurityContextHolder.getContext().getAuthentication() == null) {
			String uri = request.getRequestURI();
			/* validate permission */
			UsernamePasswordAuthenticationToken authToken = new UsernamePasswordAuthenticationToken(userDetails,
					userDetails.getPassword(), userDetails.getAuthorities());
			authToken.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
			SecurityContextHolder.getContext().setAuthentication(authToken);
		}
		filterChain.doFilter(request, response);
	}

	private Boolean hasPermission(String uri) {
		return true;
	}

	private void handleForbidenResponse(HttpServletResponse response, String path) throws IOException {
		try {
			response.setContentType(MediaType.APPLICATION_JSON_VALUE);
			response.setCharacterEncoding(StandardCharsets.UTF_8.toString());
			response.setStatus(403);
//			response.getWriter().write(HelperUtil.jsonParser(ApiResponse.accessDenined(path)));
			response.getWriter().flush();
		} catch (Exception e) {
		}
	}
}
