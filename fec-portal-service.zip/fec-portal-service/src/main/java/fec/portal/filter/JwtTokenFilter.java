package fec.portal.filter;

import java.util.Base64;
import java.util.Date;
import java.util.Map;
import java.util.function.Function;

import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.type.TypeReference;

import fec.portal.dto.UserDetailDto;
import fec.portal.util.JacksonUtil;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.MalformedJwtException;
import io.jsonwebtoken.UnsupportedJwtException;
import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class JwtTokenFilter {
	private static final String JWT_SECRET = "HLiHI2DmTkmJs9Df4iQgmx52e0hMcfBH";
	private static final String ISSUER = "portal-service";
	private TypeReference<UserDetailDto> TYPE_REFERENCE = new TypeReference<>() {
	};
	private SecretKey secretKey;

	@PostConstruct
	public void initKey() {
		byte[] privateKeyBytes = Base64.getEncoder().encode(JWT_SECRET.getBytes());
		this.secretKey = new SecretKeySpec(privateKeyBytes, "HmacSHA256");
	}

	public String doGenerateToken(UserDetailDto userDetail) {
		return Jwts.builder().id(userDetail.getId()).subject(userDetail.getUsername()).issuer(ISSUER)
				.issuedAt(new Date(System.currentTimeMillis())).expiration(userDetail.getExpiry())
				.claim("userDetail", claimDetail(userDetail)).signWith(secretKey).compact();
	}

	public Map<String, Object> claimDetail(UserDetailDto userDetail) {
		return Map.of("username", userDetail.getUsername(), "email", userDetail.getEmail(), "department",
				userDetail.getDepartment(), "roles", userDetail.getRoles(), "expiries", userDetail.getExpiry());
	}

	public UserDetailDto validateToken(String token) {
		try {
			Claims claims = getAllClaimsFromToken(token);
			Date expired = claims.getExpiration();
			if (expired.before(new Date())) {
				log.error("[ClientId: {}] Token had expired at {}", claims.getSubject(), expired);
				return null;
			}
			return JacksonUtil.convertValue(claims.get("userDetail"), TYPE_REFERENCE);
		} catch (MalformedJwtException e) {
			log.error("Invalid JWT Token: {}", e.getMessage());
		} catch (ExpiredJwtException e) {
			log.error("JWT Token is expired: {}", e.getMessage());
		} catch (UnsupportedJwtException e) {
			log.error("JWT Token is unsupported: {}", e.getMessage());
		} catch (IllegalArgumentException e) {
			log.error("JWT claims string is empty: {}", e.getMessage());
		} catch (Exception e) {
			log.error("JWT invalid signature: {}", e.getMessage());
		}
		return null;
	}

	private Claims getAllClaimsFromToken(String token) {
		return Jwts.parser().verifyWith(secretKey).requireIssuer(ISSUER).build().parseSignedClaims(token).getPayload();
	}

	public String getUsernameFromToken(String token) {
		return getClaimFromToken(token, Claims::getSubject);
	}

	public Date getExpirationDateFromToken(String token) {
		return getClaimFromToken(token, Claims::getExpiration);
	}

	public <T> T getClaimFromToken(String token, Function<Claims, T> claimsResolver) {
		final Claims claims = getAllClaimsFromToken(token);
		return claimsResolver.apply(claims);
	}
}
