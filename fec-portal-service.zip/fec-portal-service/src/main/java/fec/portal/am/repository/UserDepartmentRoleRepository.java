package fec.portal.am.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import fec.portal.am.entity.UserDepartmentRoleEntity;

public interface UserDepartmentRoleRepository extends JpaRepository<UserDepartmentRoleEntity, String> {

	List<UserDepartmentRoleEntity> findByUsernameAndDepartmentId(String username, String department);
}
