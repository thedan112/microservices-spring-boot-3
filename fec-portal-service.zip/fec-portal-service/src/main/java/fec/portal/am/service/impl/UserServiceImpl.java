package fec.portal.am.service.impl;

import org.apache.commons.lang3.StringUtils;
import org.mapstruct.factory.Mappers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import fec.portal.am.entity.UserEntity;
import fec.portal.am.enums.Messages;
import fec.portal.am.mapper.UserMapper;
import fec.portal.am.repository.UserRepository;
import fec.portal.am.service.IUserService;
import fec.portal.dto.ResponseData;
import fec.portal.dto.UserDetailDto;
import fec.portal.filter.JwtSessionFilter;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class UserServiceImpl implements IUserService {
	private final UserMapper mapper = Mappers.getMapper(UserMapper.class);
	
	@Autowired
	UserRepository userRepository;
	@Autowired
	JwtSessionFilter sessionFilter;

	@Override
	public ResponseData<?> pages(int page, int size, String email) {
		UserDetailDto userPrincipal = sessionFilter.getUserDetail();
		if (userPrincipal == null)
			return ResponseData.error(Messages.UNAUTHORIZED);
		Pageable paging = PageRequest.of(page, size);
		Page<UserEntity> pageEntity;
		if (StringUtils.isNotBlank(email)) {
			pageEntity = userRepository.findByEmailContainingIgnoreCase(email, paging);
		} else {
			pageEntity = userRepository.findAll(paging);
		}
		return ResponseData.success(pageEntity);
	}
}
