package fec.portal.am.service;

import fec.portal.dto.ResponseData;

public interface IUserService {

	public ResponseData<?> pages(int page, int size, String email);
}
