package fec.portal.am.controller;

public class PermissionController {

}
