package fec.portal.am.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;

import fec.portal.am.entity.UserEntity;
import fec.portal.am.model.response.UserResponse;

@Mapper
public interface UserMapper {

	@Mapping(target = "active", expression = "java(convertBoolByInt(ent.getActive()))")
	@Mapping(target = "locked", expression = "java(convertBoolByInt(ent.getLocked()))")
	UserResponse userResponse(UserEntity ent);
	
	@Named("convertBoolByInt")
	default boolean convertBoolByInt(Integer value) {
		return value == 0 ? false : true;
	}
}
