package fec.portal.am.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import fec.portal.am.entity.PermissionEntity;

public interface PermissionRepository extends JpaRepository<PermissionEntity, String>{

}
