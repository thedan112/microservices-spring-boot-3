package fec.portal.am.entity;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonProperty;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "USERS")
public class UserEntity {

	@Id
	@Column(name = "id", nullable = false)
	private String id;

	@Column(name = "USERNAME")
	private String username;

	@Column(name = "PASSWORD")
	@JsonProperty
	private String password;
	
	@Column(name = "EMPLOYEE_CODE")
	private String employeeCode;

	@Column(name = "FULL_NAME")
	private String fullName;

	@Column(name = "DEPARTMENT_ID")
	private String departmentId;
	
	@Column(name = "LOGIN_AT")
	private Date loginAt;

	@Column(name = "CREATED_DATE")
	private Date createdDate;

	@Column(name = "active")
	private int active;

	@Column(name = "locked")
	private int locked;

	@Column(name = "token")
	@JsonProperty
	private int token;
	
	@Column(name = "PASSWORD_EXPIRED")
	@JsonProperty
	private Date passwordExpired;

	@Column(name = "email")
	private String email;

	@Column(name = "type")
	private String type;
	
	@Column(name = "LOGIN_FAILURE")
	private int loginFailure;
}
