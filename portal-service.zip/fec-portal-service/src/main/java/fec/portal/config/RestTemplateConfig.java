package fec.portal.config;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

import fec.portal.exception.RestTemplateException;
import fec.portal.setting.RestTemplateSetting;

@Configuration
public class RestTemplateConfig {
	@Autowired
	RestTemplateSetting setting;
//	@Autowired
//	RestTemplateInterceptor restTemplateInterceptor;

	@Bean
	public RestTemplate restTemplate() {
		RestTemplate restTemplate = new RestTemplate();
		restTemplate.setRequestFactory(simpleClientHttpRequestFactory());
		restTemplate.setErrorHandler(new RestTemplateException());
		restTemplate.setInterceptors(interceptors());
		return restTemplate;
	}

	private SimpleClientHttpRequestFactory simpleClientHttpRequestFactory() {
		SimpleClientHttpRequestFactory factory = new SimpleClientHttpRequestFactory();
		factory.setConnectTimeout(setting.getConnectionTimeout());
		factory.setReadTimeout(setting.getReadTimeout());
		return factory;
	}

	private List<ClientHttpRequestInterceptor> interceptors() {
		List<ClientHttpRequestInterceptor> interceptors = new ArrayList<>();
//		interceptors.add(restTemplateInterceptor);
		return interceptors;
	}
}
