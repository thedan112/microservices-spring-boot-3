package fec.portal.setting;

import java.util.Set;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import lombok.Data;

@Data
@Configuration
@ConfigurationProperties(prefix = "app.sensitive-data")
public class AppSetting {

	private Set<String> card;
	private Set<String> phone;

}
