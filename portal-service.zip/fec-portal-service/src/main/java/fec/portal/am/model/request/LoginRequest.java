package fec.portal.am.model.request;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class LoginRequest {

	@NotBlank(message = "Thông tin không hợp lệ")
	private String username;
	@NotBlank(message = "Thông tin không hợp lệ")
	private String password;
}
