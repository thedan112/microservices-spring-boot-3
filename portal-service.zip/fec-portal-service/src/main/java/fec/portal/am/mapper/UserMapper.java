package fec.portal.am.mapper;

import java.util.Date;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import fec.portal.am.entity.UserEntity;
import fec.portal.am.model.request.UserCreateRequest;

@Mapper
public interface UserMapper {

	@Mapping(target = "id", expression = "java(java.util.UUID.randomUUID().toString())")
	@Mapping(target = "password", expression = "java(password())")
	@Mapping(target = "active", expression = "java(1)")
	@Mapping(target = "locked", expression = "java(0)")
	@Mapping(target = "token", expression = "java(0)")
	@Mapping(target = "loginFailure", expression = "java(0)")
	@Mapping(target = "createdDate", expression = "java(today())")
	UserEntity createEntity(UserCreateRequest source);
	
	@Named("today")
	default Date today() {
		return new Date();
	}
	
	@Named("password")
	default String password() {
		return new BCryptPasswordEncoder().encode("admin");
	}
}
