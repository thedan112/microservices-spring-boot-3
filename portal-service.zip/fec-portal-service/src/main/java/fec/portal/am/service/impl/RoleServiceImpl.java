package fec.portal.am.service.impl;

import org.apache.commons.lang3.StringUtils;
import org.mapstruct.factory.Mappers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import fec.portal.am.entity.RoleEntity;
import fec.portal.am.enums.Messages;
import fec.portal.am.mapper.RoleMapper;
import fec.portal.am.model.request.RoleActionRequest;
import fec.portal.am.repository.RoleRepository;
import fec.portal.am.service.IRoleService;
import fec.portal.dto.ResponseData;
import fec.portal.dto.UserDetailDto;
import fec.portal.filter.JwtSessionFilter;

@Service
public class RoleServiceImpl implements IRoleService {
	private final RoleMapper mapper = Mappers.getMapper(RoleMapper.class);

	@Autowired
	RoleRepository roleRepository;
	@Autowired
	JwtSessionFilter sessionFilter;

	@Override
	public ResponseData<?> pages(int page, int size, String filter) {
		UserDetailDto userPrincipal = sessionFilter.getUserDetail();
		if (userPrincipal == null)
			return ResponseData.error(Messages.UNAUTHORIZED);
		Pageable paging = PageRequest.of(page, size);
		Page<RoleEntity> pageEntity;
		if (StringUtils.isNotBlank(filter)) {
			pageEntity = roleRepository.findByNameContainingIgnoreCase(filter, paging);
		} else {
			pageEntity = roleRepository.findAll(paging);
		}
		return ResponseData.success(pageEntity);
	}

	@Override
	public ResponseData<?> create(RoleActionRequest req) {
		var userPrincipal = sessionFilter.getUserDetail();
		if (userPrincipal == null)
			return ResponseData.unauthorized();
		var optional = roleRepository.findByName(req.getName().toUpperCase());
		if (optional.isPresent())
			return ResponseData.error(Messages.ROLE_EXISTED);
		var entity = mapper.createEntity(req);
		entity.setCreatedBy(userPrincipal.getUsername());
		roleRepository.save(entity);
		return ResponseData.success(true);
	}

	@Override
	public ResponseData<?> detail(String id) {
		if (StringUtils.isBlank(id))
			return ResponseData.error(Messages.BAD_REQUEST);
		var optional = roleRepository.findById(id);
		if (optional.isEmpty())
			return ResponseData.error(Messages.ROLE_NOT_FOUND);
		return ResponseData.success(optional.get());
	}

	@Override
	public ResponseData<?> update(RoleActionRequest req) {
		return null;
	}

	@Override
	public ResponseData<?> changeStatus(String id) {
		var userPrincipal = sessionFilter.getUserDetail();
		if (userPrincipal == null)
			return ResponseData.unauthorized();
		if (StringUtils.isBlank(id))
			return ResponseData.error(Messages.BAD_REQUEST);
		var optional = roleRepository.findById(id);
		if (optional.isEmpty())
			return ResponseData.error(Messages.USER_NOT_FOUND);
		var entity = optional.get();
		int status = entity.getActive() == 0 ? 1 : 0;
		entity.setActive(status);
		return ResponseData.success(true);
	}
}
