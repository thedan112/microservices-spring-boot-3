package fec.portal.am.model.request;

import lombok.Data;

@Data
public class UserUpdateRequest {

	private String id;
	private String departmentId;
	private String type;
}
