package fec.portal.am.service;

import fec.portal.am.model.request.RoleActionRequest;
import fec.portal.dto.ResponseData;

public interface IRoleService {

	public ResponseData<?> pages(int page, int size, String filter);

	public ResponseData<?> create(RoleActionRequest req);

	public ResponseData<?> detail(String id);

	public ResponseData<?> update(RoleActionRequest req);

	public ResponseData<?> changeStatus(String id);
}