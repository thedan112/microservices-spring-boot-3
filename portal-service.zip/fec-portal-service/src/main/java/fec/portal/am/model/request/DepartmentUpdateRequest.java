package fec.portal.am.model.request;

import java.util.List;

import lombok.Data;

@Data
public class DepartmentUpdateRequest {

	private String id;
	private String name;
	private String description;
	private List<String> roleIds;
}
