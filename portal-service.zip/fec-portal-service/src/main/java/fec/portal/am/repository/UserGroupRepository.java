package fec.portal.am.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import fec.portal.am.entity.UserGroupEntity;

public interface UserGroupRepository extends JpaRepository<UserGroupEntity, String> {

	List<UserGroupEntity> findByUsernameAndDepartmentId(String username, String departmentId);
}
