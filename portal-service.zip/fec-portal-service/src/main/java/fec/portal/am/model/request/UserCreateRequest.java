package fec.portal.am.model.request;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class UserCreateRequest {

	@NotBlank(message = "tham số không hợp lệ")
	private String email;
	@NotBlank(message = "tham số không hợp lệ")
	private String username;
	@NotBlank(message = "tham số không hợp lệ")
	private String fullName;
	@NotBlank(message = "tham số không hợp lệ")
	private String employeeCode;
	@NotBlank(message = "tham số không hợp lệ")
	private String departmentId;
	@NotBlank(message = "tham số không hợp lệ")
	private String type;
}
