	package fec.portal.am.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import fec.portal.am.model.request.LoginRequest;
import fec.portal.am.service.IAuthenticationService;
import jakarta.validation.Valid;

@RestController
@RequestMapping(value = "/api/auth")
public class AuthenticateController {

	@Autowired
	IAuthenticationService authenticationService;
	
	@PostMapping(value = "/login")
	public ResponseEntity<?> login(@RequestBody @Valid LoginRequest req) {
		return ResponseEntity.ok(authenticationService.login(req));
	}

	@GetMapping(value = "/logout")
	public ResponseEntity<?> login() {
		return ResponseEntity.ok(authenticationService.logout());
	}
	
	@PostMapping(value = "/validate-permission")
	public ResponseEntity<?> validatePermission() {
		return ResponseEntity.ok(null);
	}

	@PostMapping(value = "/validate-uri")
	public ResponseEntity<?> validateUri() {
		return ResponseEntity.ok(null);
	}
}
