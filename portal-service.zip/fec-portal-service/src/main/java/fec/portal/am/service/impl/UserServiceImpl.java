package fec.portal.am.service.impl;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.mapstruct.factory.Mappers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import fec.portal.am.entity.UserEntity;
import fec.portal.am.enums.Messages;
import fec.portal.am.mapper.UserMapper;
import fec.portal.am.model.request.UserCreateRequest;
import fec.portal.am.model.request.UserUpdateRequest;
import fec.portal.am.repository.UserRepository;
import fec.portal.am.service.IUserService;
import fec.portal.dto.ResponseData;
import fec.portal.dto.UserDetailDto;
import fec.portal.filter.JwtSessionFilter;

@Service
public class UserServiceImpl implements IUserService {
	private final UserMapper mapper = Mappers.getMapper(UserMapper.class);

	@Autowired
	UserRepository userRepository;
	@Autowired
	JwtSessionFilter sessionFilter;

	@Override
	public ResponseData<?> pages(int page, int size, String filter) {
		UserDetailDto userPrincipal = sessionFilter.getUserDetail();
		if (userPrincipal == null)
			return ResponseData.error(Messages.UNAUTHORIZED);
		Pageable paging = PageRequest.of(page, size);
		Page<UserEntity> pageEntity;
		if (StringUtils.isNotBlank(filter)) {
			pageEntity = userRepository.findByEmailContainingIgnoreCase(filter, paging);
		} else {
			pageEntity = userRepository.findAll(paging);
		}
		return ResponseData.success(pageEntity);
	}

	@Override
	public ResponseData<?> create(UserCreateRequest req) {
		var userPrincipal = sessionFilter.getUserDetail();
		if (userPrincipal == null)
			return ResponseData.unauthorized();
		var optional = userRepository.findByEmail(req.getEmail().toLowerCase());
		if (optional.isPresent())
			return ResponseData.error(Messages.USER_EXISTED);
		var entity = mapper.createEntity(req);
		entity.setCreatedBy(userPrincipal.getUsername());
		userRepository.save(entity);
		return ResponseData.success(true);
	}

	@Override
	public ResponseData<?> detail(String id) {
		if (StringUtils.isBlank(id))
			return ResponseData.error(Messages.BAD_REQUEST);
		var optional = userRepository.findById(id);
		if (optional.isEmpty())
			return ResponseData.error(Messages.ROLE_NOT_FOUND);
		return ResponseData.success(optional.get());
	}

	@Override
	public ResponseData<?> update(UserUpdateRequest req) {
		var userPrincipal = sessionFilter.getUserDetail();
		if (userPrincipal == null)
			return ResponseData.unauthorized();
		return ResponseData.success(true);
	}

	@Override
	public ResponseData<?> changeActive(String id) {
		var userPrincipal = sessionFilter.getUserDetail();
		if (userPrincipal == null)
			return ResponseData.unauthorized();
		if (StringUtils.isBlank(id))
			return ResponseData.error(Messages.BAD_REQUEST);
		var optional = userRepository.findById(id);
		if (optional.isEmpty())
			return ResponseData.error(Messages.USER_NOT_FOUND);
		var entity = optional.get();
		int status = entity.getActive() == 0 ? 1 : 0;
		entity.setActive(status);
		return ResponseData.success(true);
	}

	@Override
	public ResponseData<?> changeLocked(String id) {
		var userPrincipal = sessionFilter.getUserDetail();
		if (userPrincipal == null)
			return ResponseData.unauthorized();
		if (StringUtils.isBlank(id))
			return ResponseData.error(Messages.BAD_REQUEST);
		var optional = userRepository.findById(id);
		if (optional.isEmpty())
			return ResponseData.error(Messages.USER_NOT_FOUND);
		var entity = optional.get();
		int status = entity.getLocked() == 0 ? 1 : 0;
		entity.setLocked(status);
		return ResponseData.success(true);
	}

	@Override
	public ResponseData<?> upload(MultipartFile multipartFile) {
		return ResponseData.success(true);
	}

	@Override
	public ResponseData<?> saveUpload(List<?> items) {
		return ResponseData.success(true);
	}
}
