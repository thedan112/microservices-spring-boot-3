package fec.portal.am.enums;

public enum Messages {
	SUCCESS("000", "Thành Công"), 
	BAD_REQUEST("400", "Yêu cầu không hợp lệ"),
	ACCESS_DENIED("403", "Bạn không có quyền thực hiện chức năng này."),
	NOT_FOUND_DATA("404", "Không tìm thấy thông tin"), 
	UNAUTHORIZED("401", "Phiên làm việc đã hết hạn"),
	PROCESSING_ERROR("500", "Lỗi trong quá trình xử lý"), 
	
	USER_LOCKED("1000", "Người dùng đang bị khóa"), 
	USER_EXISTED("1001", "Người dùng đã tồn tại"),
	USER_NOT_ACTIVE("1002", "Người dùng chưa kích hoạt"),
	USER_NOT_FOUND("1003", "Người dùng không tồn tại"),
	USER_BAD_CREDENTIAL("1004", "Người dùng hoặc mật khẩu không đúng"),
	PASSWORD_EXPIRED("1005", "Mật khẩu đã hết hạn"),
	
	ROLE_EXISTED("1004", "Vai trò đã tồn tại."),
	ROLE_NOT_FOUND("1005", "Vai trò không tồn tại."),
	
	DEPARTMENT_EXISTED("2000", "Phòng ban đã tồn tại."),
	DEPARTMENT_NOT_FOUND("2001", "Phòng ban không tồn tại."),
	
	FUNCTION_EXISTED("3000", "Chức năng đã tồn tại."),
	FUNCTION_NOT_FOUND("3001", "Chức năng không tồn tại."),
	
	RESOURCE_EXISTED("4000", "API đã tồn tại."),
	RESOURCE_NOT_FOUND("4001", "API không tồn tại."),
	;
	
	private final String status;
	private final String message;

	Messages(String status, String message) {
		this.status = status;
		this.message = message;
	}

	public String getMessage() {
		return message;
	}

	public String getStatus() {
		return status;
	}

	@Override
	public String toString() {
		return message;
	}
}