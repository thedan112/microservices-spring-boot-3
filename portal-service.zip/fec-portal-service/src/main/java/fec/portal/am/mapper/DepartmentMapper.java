package fec.portal.am.mapper;

import java.util.Date;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;

import fec.portal.am.entity.DepartmentEntity;
import fec.portal.am.model.request.DepartmentCreateRequest;

@Mapper
public interface DepartmentMapper {

	@Mapping(target = "id", expression = "java(java.util.UUID.randomUUID().toString())")
	@Mapping(target = "createdDate", expression = "java(today())")
	DepartmentEntity createEntity(DepartmentCreateRequest source);
	
	@Named("today")
	default Date today() {
		return new Date();
	}
}
