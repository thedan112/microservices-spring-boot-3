package fec.portal.am.service;

import fec.portal.am.model.request.DepartmentCreateRequest;
import fec.portal.am.model.request.DepartmentUpdateRequest;
import fec.portal.dto.ResponseData;

public interface IDepartmentService {

	public ResponseData<?> pages(int page, int size, String filter);
	
	public ResponseData<?> create(DepartmentCreateRequest req);

	public ResponseData<?> detail(String id);

	public ResponseData<?> update(DepartmentUpdateRequest req);
}
