package fec.portal.am.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "USER_GROUP")
public class UserGroupEntity {

	@Id
	@Column(name = "ID")
	private String id;

	@Column(name = "USERNAME")
	private String username;

	@Column(name = "DEPARTMENT_ID")
	private String departmentId;

	@Column(name = "ROLE_ID")
	private String roleId;
}
