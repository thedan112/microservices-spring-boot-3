package fec.portal.am.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import fec.portal.am.entity.PermissionEntity;

public interface PermissionRepository extends JpaRepository<PermissionEntity, String> {

	List<PermissionEntity> findByDepartmentIdAndRoleIdIn(String departmentId, List<String> roles);
}
