package fec.portal.am.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import fec.portal.am.entity.FunctionEntity;

public interface FunctionRepository extends JpaRepository<FunctionEntity, String>{

}
