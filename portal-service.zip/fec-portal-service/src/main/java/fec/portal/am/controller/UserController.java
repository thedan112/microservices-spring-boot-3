package fec.portal.am.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import fec.portal.am.model.request.UserCreateRequest;
import fec.portal.am.service.IUserService;
import jakarta.validation.Valid;

@RestController
@RequestMapping(value = "/api/management/user")
public class UserController {

	@Autowired
	IUserService service;

	@PostMapping(value = "/pages")
	public ResponseEntity<?> pages(@RequestParam(required = false, defaultValue = "0") int page,
			@RequestParam(required = false, defaultValue = "10") int size,
			@RequestParam(required = false, name = "email") String email) {
		return ResponseEntity.ok(service.pages(page, size, email));
	}

	@GetMapping(value = "/validate-ad")
	public ResponseEntity<?> checkEmail(@RequestParam(required = false, name = "email") String email) {
		return ResponseEntity.ok(null);	
	}
	
	@PostMapping(value = "/create")
	public ResponseEntity<?> create(@RequestBody @Valid UserCreateRequest req) {
		return ResponseEntity.ok(service.create(req));
	}

	@GetMapping(value = "/detail")
	public ResponseEntity<?> detail(@RequestParam(required = false, name = "id") String id) {
		return ResponseEntity.ok(null);
	}

	@PostMapping(value = "/update")
	public ResponseEntity<?> update() {
		return ResponseEntity.ok(null);
	}
	
	@PostMapping(value = "/change-actiÏve")
	public ResponseEntity<?> changeActive(@RequestParam(required = false, name = "id") String id) {
		return ResponseEntity.ok(service.changeActive(id));
	}
	
	@PostMapping(value = "/change-locked")
	public ResponseEntity<?> changeLocked(@RequestParam(required = false, name = "id") String id) {
		return ResponseEntity.ok(service.changeLocked(id));
	}
}