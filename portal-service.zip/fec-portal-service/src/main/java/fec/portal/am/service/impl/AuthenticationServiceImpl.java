package fec.portal.am.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.stereotype.Service;

import fec.portal.am.enums.Messages;
import fec.portal.am.model.request.LoginRequest;
import fec.portal.am.model.response.LoginResponse;
import fec.portal.am.repository.UserRepository;
import fec.portal.am.service.IAuthenticationService;
import fec.portal.dto.ResponseData;
import fec.portal.dto.UserDetailDto;
import fec.portal.filter.JwtSessionFilter;
import fec.portal.filter.JwtTokenFilter;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class AuthenticationServiceImpl implements IAuthenticationService {
	@Autowired
	AuthenticationManager authenticationManager;
	@Autowired
	JwtTokenFilter tokenFilter;
	@Autowired
	JwtSessionFilter sessionFilter;
	@Autowired
	UserRepository userRepository;

	@Override
	public ResponseData<?> login(LoginRequest req) {
		try {
			Authentication authenticatetion = authenicate(req.getUsername(), req.getPassword());
			UserDetailDto userPrincal = (UserDetailDto) authenticatetion.getPrincipal();
			if (userPrincal.getLocked() == 1)
				return ResponseData.error(Messages.USER_LOCKED);
			if (userPrincal.getActive() == 0)
				return ResponseData.error(Messages.USER_NOT_ACTIVE);
			String token = tokenFilter.doGenerateToken(userPrincal);
			activeToken(req.getUsername());
			return ResponseData.success(new LoginResponse(req.getUsername(), userPrincal.getExpiry().getTime(), token));
		} catch (AuthenticationException ex) {
			Messages errorMessage = Messages.UNAUTHORIZED;
			if (ex.getMessage().equalsIgnoreCase("user not found with username: " + req.getUsername())) {
				errorMessage = Messages.USER_BAD_CREDENTIAL;
			} else if (ex.getMessage().equalsIgnoreCase("Bad credentials")) {
				errorMessage = Messages.USER_BAD_CREDENTIAL;
				sessionFilter.processFailureAuthen(req.getUsername());
			} else if (ex.getMessage().equalsIgnoreCase("User is disabled")) {
				errorMessage = Messages.USER_EXISTED;
			} else if (ex.getMessage().equalsIgnoreCase("User account has expired")) {
				errorMessage = Messages.PASSWORD_EXPIRED;
			} else if (ex.getMessage().equalsIgnoreCase("User account is locked")) {
				errorMessage = Messages.USER_LOCKED;
			}
			log.error("username: {}, Login failed by: {}", req.getUsername(), ex.getMessage());
			return ResponseData.error(errorMessage);
		}
	}

	private Authentication authenicate(String username, String password) {
		return authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(username, password));
	}

	@Override
	public ResponseData<?> isPermission(String uri) {
		return null;
	}

	@Async
	private void activeToken(String username) {
		userRepository.updateTokenByUsername(1, username);
	}
	
	@Override
	public ResponseData<?> logout() {
		String username = sessionFilter.getSessionUsername();
		if (username == null || username == "")
			return ResponseData.error(Messages.UNAUTHORIZED);
		userRepository.updateTokenByUsername(0, username);
		return ResponseData.success(true);
	}
}
