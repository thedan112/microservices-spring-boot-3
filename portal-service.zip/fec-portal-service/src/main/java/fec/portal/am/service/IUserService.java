package fec.portal.am.service;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import fec.portal.am.model.request.UserCreateRequest;
import fec.portal.am.model.request.UserUpdateRequest;
import fec.portal.dto.ResponseData;

public interface IUserService {

	public ResponseData<?> pages(int page, int size, String filter);

	public ResponseData<?> create(UserCreateRequest req);

	public ResponseData<?> detail(String id);

	public ResponseData<?> update(UserUpdateRequest req);

	public ResponseData<?> changeActive(String id);

	public ResponseData<?> changeLocked(String id);
	
	public ResponseData<?> upload(MultipartFile multipartFile);
	
	public ResponseData<?> saveUpload(List<?> items);
}