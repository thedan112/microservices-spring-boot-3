package fec.portal.am.service;

public interface IPermissionService {

}
