package fec.portal.am.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value = "/api/resource")
public class ResourceController {

	@PostMapping(value = "/pages")
	public ResponseEntity<?> pages(@RequestParam(required = false, defaultValue = "0") int page,
			@RequestParam(required = false, defaultValue = "10") int size) {
		return ResponseEntity.ok(null);
	}

	@PostMapping(value = "/create")
	public ResponseEntity<?> create() {
		return ResponseEntity.ok(null);
	}

	@GetMapping(value = "/detail")
	public ResponseEntity<?> detail() {
		return ResponseEntity.ok(null);
	}

	@PostMapping(value = "/update")
	public ResponseEntity<?> update() {
		return ResponseEntity.ok(null);
	}
}
