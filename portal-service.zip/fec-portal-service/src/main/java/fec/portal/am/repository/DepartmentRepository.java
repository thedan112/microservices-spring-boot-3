package fec.portal.am.repository;

import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import fec.portal.am.entity.DepartmentEntity;

public interface DepartmentRepository extends JpaRepository<DepartmentEntity, String> {

	Page<DepartmentEntity> findByNameContainingIgnoreCase(String name, Pageable pageable);
	
	Optional<DepartmentEntity> findByName(String name);
}
