package fec.portal.am.service;

import fec.portal.dto.ResponseData;

public interface IFunctionService {

	public ResponseData<?> pages(int page, int size, String filter);
}
