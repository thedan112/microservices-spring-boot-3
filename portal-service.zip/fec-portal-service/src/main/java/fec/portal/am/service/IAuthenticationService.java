package fec.portal.am.service;

import fec.portal.am.model.request.LoginRequest;
import fec.portal.dto.ResponseData;

public interface IAuthenticationService {

	public ResponseData<?> login(LoginRequest req);

	public ResponseData<?> logout();
	
	public ResponseData<?> isPermission(String uri);
}
