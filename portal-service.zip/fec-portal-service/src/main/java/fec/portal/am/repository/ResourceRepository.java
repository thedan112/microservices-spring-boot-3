package fec.portal.am.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import fec.portal.am.entity.ResourceEntity;

public interface ResourceRepository extends JpaRepository<ResourceEntity, String>{

}
