package fec.portal.filter;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import fec.portal.am.entity.UserGroupEntity;
import fec.portal.am.repository.UserGroupRepository;
import fec.portal.am.repository.UserRepository;
import fec.portal.dto.UserDetailDto;

@Service
public class JwtUserDetailService implements UserDetailsService {

	@Autowired
	UserRepository userRepository;

	@Autowired
	UserGroupRepository userDepartmentRoleRepository;

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		var userEntity = userRepository.findByUsername(username);
		if (userEntity.isEmpty())
			throw new UsernameNotFoundException("user not found with username: " + username);
		var policies = userDepartmentRoleRepository.findByUsernameAndDepartmentId(userEntity.get().getUsername(),
				userEntity.get().getDepartmentId());
		List<String> roles = new ArrayList<>();
		if (!CollectionUtils.isEmpty(policies))
			roles = policies.stream().map(UserGroupEntity::getRoleId).toList();
		if ("admin".equals(userEntity.get().getUsername()))
			roles.add("ADMIN");
		return new UserDetailDto(userEntity.get(), roles);
	}
}
