package fec.portal.enums;

public enum UserTypeEnum {
	ADMINISTRATOR,
	USER,
	OPERATION,
	;
}
