package fec.portal.enums;

public enum MessageCode {

	SUCCESS("000", "Thành công"),
	BAD_REQUEST("400", "Bạn chưa nhập đủ tham số"),
	UNAUTHORIZED("401", "Thông tin xác thực không hợp lệ"),
	ACCESS_DENINED("403", "Bạn chưa có quyền thực hiện chức năng"),
	NOT_FOUND_DATA("404", "Không tìm thấy dữ liệu"),
	INTERNAL_SERVER_ERROR("500","Lỗi trong quá trình thực hiện"),
	
	EXCEL_LIMIT_ERROR("600", "Dữ liệu trong File quá lớn, Vui lòng kiểm tra lại"),
	EXCEL_IMPORT_ERROR("601", "Lỗi trong quá trình xử lý dữ liệu ")
	;
	
	private final String status;
	private final String message;

	MessageCode(String status, String message) {
		this.status = status;
		this.message = message;
	}

	public String getStatus() {
		return status;
	}

	public String getMessage() {
		return message;
	}

}
