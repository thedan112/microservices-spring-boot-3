package core.enums;

public enum SensitiveKeyEnum {
	IdentityCard,
	IdentityCardNumber,
	ClientNumber,
	MobilePhone,
	;
}
