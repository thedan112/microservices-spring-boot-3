package core.enums;

public enum RoleEnum {

	ADMIN,
	OPERATION,
	CLIENT
}
