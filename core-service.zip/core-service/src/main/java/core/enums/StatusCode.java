package core.enums;

public enum StatusCode {

	SUCCESS("000", "Successfully"),
	UNAUTHORIZED("401", "Unauthorized"),
	FORBIDEN("403", "Permission cannot access resources"),
	ERROR_RESOURCE_NOT_FOUND("050", "Resource not found"),
	
	
	ERROR_INPUT_VALIDATION("100", "Validation input is invalid"),
	ERROR_INPUT_MISSING("101", "Missing field in request"),
	ERROR_INPUT_FORMAT("102", "Format input is invalid. Please, follow detail"),
	ERROR_CONNECTION("103", "Connection failed"),
	ERROR_TIMEOUT("104","Execute timeout"),
	ERROR_BUILD_REQUEST_XML("105", "Build request XML failed"),
	
	NOT_FOUND_DATA("400", "Requested data not found"),
	NOT_RECEIVE_RESPONSE("401", "Not receive response"),

	INTERNAL_ERROR("500", "The system encountered an unexpected condition"),
	
	EXTERNAL_SERVICE_ERROR("600", "External service returned error"),
	EXTERNAL_SERVICE_UNAVAILABLE("601", "External service unavailable"),
	EXTERNAL_SERVICE_UNAUTHORIZED("602", "External service authentication failed"),
	EXTERNAL_SERVICE_FORMAT_INVALID("603", "External service format invalid"),
	EXTERNAL_SERVICE_TIMEOUT("604", "External service timeout"),
	EXTERNAL_SERVICE_DATA_EMPTY("605", "External service returned a object empty"),
	;
	
	private final String status;
	private final String message;

	StatusCode(String status, String message) {
		this.status = status;
		this.message = message;
	}

	public String getStatus() {
		return status;
	}

	public String getMessage() {
		return message;
	}

}
