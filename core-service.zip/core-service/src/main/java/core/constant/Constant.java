package core.constant;

import org.springframework.core.ParameterizedTypeReference;

public class Constant {

	public static final ParameterizedTypeReference<String> STRING_TYPE_REFERENCE = new ParameterizedTypeReference<>() {
	};
	
	public static final String APPLICATION_JSON = "application/json";
	public static final String APPLICATION_XML = "application/xml";
}
