package core.constant;

public class OneWayConstant {
	public static final String WAY4_NAMESPACE_ENV = "http://schemas.xmlsoap.org/soap/envelope/";
	public static final String WAY4_NAMESPACE_WSIN = "http://www.openwaygroup.com/wsint";
}
