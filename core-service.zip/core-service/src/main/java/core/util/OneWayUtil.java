package core.util;

import java.lang.reflect.Field;
import java.util.Optional;
import java.util.stream.Stream;

import core.enums.StatusCode;
import core.model.ApiResponse;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class OneWayUtil {

	private static final String BODY = "body";
	private static final String RESPONSE = "response";
	private static final String RESULT = "result";
	private static final String RETCODE = "retCode";
	private static final String RETMSG = "retMsg";
//	private static final String OUT_OBJECT = "outObject";

	public static ApiResponse<?> validationResult(Object obj) {
		return Stream.ofNullable(obj).map(o -> getFieldValue(obj, BODY)).filter(body -> body != null)
				.map(body -> getFieldValue(body, RESPONSE)).filter(response -> response != null)
				.map(response -> getFieldValue(response, RESULT)).filter(result -> result != null).findFirst()
				.map(result -> {
					Object retCode = getFieldValue(result, RETCODE);
					if (retCode instanceof String) {
						Object retMsg = getFieldValue(result, RETMSG);
						String message = Optional.ofNullable(retMsg).map(Object::toString)
								.orElse(StatusCode.EXTERNAL_SERVICE_ERROR.getMessage());
						if (retCode == null || !"0".equals(retCode)) {
							return ApiResponse.error(StatusCode.EXTERNAL_SERVICE_ERROR.getStatus(), message);
						}
					}
//					return result;
					return ApiResponse.success(null);
				})
//				.filter(result -> result != null).map(result -> getFieldValue(result, OUT_OBJECT))
//				.filter(outObject -> outObject != null).map(outObject -> ApiResponse.success(null))
				.orElse(ApiResponse.error(StatusCode.EXTERNAL_SERVICE_DATA_EMPTY));
	}

	public static Object getFieldValue(Object obj, String fieldName) {
		Class<?> clazz = obj.getClass();
		try {
			Field field = clazz.getDeclaredField(fieldName);
			field.setAccessible(true);
			return field.get(obj);
		} catch (NoSuchFieldException e) {
			log.error("{}: No such field {}", obj.getClass(), fieldName);
		} catch (Exception e) {
			log.error("getFieldValue Exception: {}: ", e.getMessage());
		}
		return null;
	}
}
