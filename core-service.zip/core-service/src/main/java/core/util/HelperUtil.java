package core.util;

import java.io.StringWriter;

import org.apache.commons.lang3.StringUtils;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;

import core.mapper.SoapPrefixMapper;
import core.model.SoapEnvelope;
import core.model.SoapEnvelope.SoapBody;
import core.model.SoapEnvelope.SoapHeader;
import jakarta.xml.bind.JAXBContext;
import jakarta.xml.bind.Marshaller;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class HelperUtil {
	private static final XmlMapper XML_MAPPER = new XmlMapper();
	private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();

	static {
		OBJECT_MAPPER.configure(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT, true);
		OBJECT_MAPPER.configure(DeserializationFeature.ACCEPT_EMPTY_ARRAY_AS_NULL_OBJECT, true);
	}

	public static <T> SoapEnvelope<T> generateSoapRequest(T object) {
		return new SoapEnvelope<>(SoapHeader.buildSoapHeader(), new SoapBody<>(object));
	}

	public static <T> String marshaller(SoapEnvelope<T> envelope, Class<?> clazz) {
		try {
			JAXBContext jaxbContext = JAXBContext.newInstance(SoapEnvelope.class, clazz);
			Marshaller marshaller = jaxbContext.createMarshaller();
			marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
			marshaller.setProperty(Marshaller.JAXB_ENCODING, "UTF-8");
			marshaller.setProperty("org.glassfish.jaxb.namespacePrefixMapper", new SoapPrefixMapper());
			StringWriter stringWriter = new StringWriter();
			marshaller.marshal(envelope, stringWriter);
			String rs = stringWriter.toString();
			return rs;
		} catch (Exception e) {
			log.error("Marshaller to XML error: {}", e.getMessage());
		}
		return null;
	}

	@SuppressWarnings("unchecked")
	public static <T> T unmarshaller(String xml, Class<?> clazz) {
		try {
			JsonNode jsonNode = XML_MAPPER.readTree(xml.getBytes());
			String json = OBJECT_MAPPER.writeValueAsString(jsonNode);
			return (T) OBJECT_MAPPER.readValue(json, clazz);
		} catch (Exception e) {
			log.error("Unmarshaller to XML error: {}", e.getMessage());
		}
		return null;
	}

	public static String jsonParser(Object o) {
		try {
			return OBJECT_MAPPER.writeValueAsString(o);
		} catch (Exception e) {
			log.error("Parser to JSON error: {}", e.getMessage());
		}
		return null;
	}

	@SuppressWarnings("unchecked")
	public static <T> T parserFromJson(String json, Class<?> clazz) {
		try {
			return (T) OBJECT_MAPPER.readValue(json, clazz);
		} catch (Exception e) {
			log.error("{}, ParserFromJson error: {}", json, e.getMessage());
		}
		return null;
	}
	
	@SuppressWarnings("unchecked")
	public static <T> T parserFromValue(Object obj, TypeReference<?> type) {
		try {
			return (T) OBJECT_MAPPER.convertValue(obj, type);
		} catch (Exception e) {
			log.error("{}, ParserFromJson error: {}", obj, e.getMessage());
		}
		return null;
	}
	
	public static String maskCardNumber(String value) {
		int lenght = value.length();
		if (StringUtils.isBlank(value) || lenght <= 6)
			return "xxxxxx" + value.substring(lenght - 4);
		return value.substring(0, 6) + "xxxxxx" + value.substring(lenght - 4);
	}

	public static String maskPhone(String value) {
		int lenght = value.length();
		if (StringUtils.isBlank(value) || lenght <= 6)
			return "xxxxxxx" + value.substring(lenght - 3);
		return value.substring(0, 3) + "xxxxxxx" + value.substring(lenght - 3);
	}
}
