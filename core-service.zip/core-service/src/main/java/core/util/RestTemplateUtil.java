package core.util;

import java.net.URI;
import java.util.Map;

import org.springframework.web.util.UriComponentsBuilder;

public class RestTemplateUtil {

	public static URI buildByParams(String baseUrl, Map<String, String> params) {
		var builder = UriComponentsBuilder.fromUriString(baseUrl);
		for (var entry : params.entrySet()) {
			builder = builder.queryParam(entry.getKey(), entry.getValue());
		}
		return builder.build().toUri();
	}

	public static URI buildByPathVariables(String baseUrl, Map<String, String> variables) {
		var builder = UriComponentsBuilder.fromUriString(baseUrl);
		if (!variables.isEmpty()) {
			builder.buildAndExpand(variables);
		}
		return builder.build().toUri();
	}
}
