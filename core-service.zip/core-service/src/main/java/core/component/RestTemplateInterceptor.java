package core.component;

import java.io.IOException;
import java.io.StringReader;
import java.nio.charset.StandardCharsets;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.input.SAXBuilder;
import org.jdom2.output.Format;
import org.jdom2.output.XMLOutputter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpRequest;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.stereotype.Component;
import org.springframework.util.StreamUtils;

import core.mapper.BufferingClientHttpResponseWrapper;
import core.setting.AppSetting;
import core.util.HelperUtil;

@Component
public class RestTemplateInterceptor implements ClientHttpRequestInterceptor {
	private static final Logger log = LoggerFactory.getLogger(RestTemplateInterceptor.class);

	@Autowired
	AppSetting appSetting;

	@Override
	public ClientHttpResponse intercept(HttpRequest request, byte[] body, ClientHttpRequestExecution execution)
			throws IOException {
		logRequest(request, body);
		long startTime = System.currentTimeMillis();
		ClientHttpResponse response = execution.execute(request, body);
		long duration = System.currentTimeMillis() - startTime;
		return logResponse(response, duration);
	}

	private void logRequest(HttpRequest request, byte[] body) {
		String requestBody = StringUtils.EMPTY;
		if (body.length > 0)
			requestBody = maskXmlData(new String(body, StandardCharsets.UTF_8));
		log.info("Method: {}, URI: {}, Request: {}", request.getMethod(), request.getURI(), requestBody);
	}

	private ClientHttpResponse logResponse(ClientHttpResponse response, long duration) throws IOException {
		byte[] responseBody = StreamUtils.copyToByteArray(response.getBody());
		String responseMasked = StringUtils.EMPTY;
		if (responseBody.length > 0)
			responseMasked = maskXmlData(new String(responseBody, StandardCharsets.UTF_8));
		log.info("Status: {}, Duration: {}, Response='{}'", response.getStatusCode(), duration, responseMasked);
		return new BufferingClientHttpResponseWrapper(response, responseBody);

	}

	private String maskXmlData(String xmlString) {
		try {
			SAXBuilder builder = new SAXBuilder();
			Document document = builder.build(new StringReader(xmlString));
			Element rootNode = document.getRootElement();
			maskElements(rootNode);
			XMLOutputter xmlOutput = new XMLOutputter();
			Format format = Format.getPrettyFormat();
			format.setTextMode(Format.TextMode.TRIM_FULL_WHITE); // not removing whitespace
			xmlOutput.setFormat(format);
			return xmlOutput.outputString(document);
		} catch (Exception e) {
			log.error("Masking XML error: {}", e.getMessage());
		}
		return null;
	}

	private void maskElements(Element element) {
		String name = element.getName();
		String text = element.getText();
		if (appSetting.getCard().contains(name))
			element.setText(HelperUtil.maskCardNumber(text));
		else if (appSetting.getPhone().contains(name))
			element.setText(HelperUtil.maskPhone(text));
		List<Element> children = element.getChildren();
		for (Element child : children)
			maskElements(child);
	}
}
