package core.component;

import java.nio.charset.StandardCharsets;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class OneWayClient {
	private static final String ONEWAY_WS_ENDPOINT = "http://10.8.13.70:20300/ws/ws";

	@Autowired
	RestTemplate restTemplate;

	public <T, R> R post(T payload, ParameterizedTypeReference<R> responseType) {
		HttpHeaders httpHeaders = new HttpHeaders();
		ResponseEntity<R> res;
		try {
			restTemplate.getMessageConverters().add(0, new StringHttpMessageConverter(StandardCharsets.UTF_8));
			httpHeaders.setContentType(MediaType.APPLICATION_XML);
			HttpEntity<T> entity = new HttpEntity<>(payload, httpHeaders);
			res = restTemplate.exchange(ONEWAY_WS_ENDPOINT, HttpMethod.POST, entity, responseType);
			return res.getBody();
		} catch (RestClientException e) {
			log.error("Method: POST, Endpoint: {}, Error: {}", ONEWAY_WS_ENDPOINT, e.getMessage());
		}
		return null;
	}
}
