package core.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import core.service.authentication.IAuthenticationService;

@RestController
@RequestMapping(value = "/api")
public class AuthenticationController {
	@Autowired
	IAuthenticationService authService;
	
	@PostMapping(value = "/v1/auth/token", consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public ResponseEntity<?> generateToken(@RequestParam(value = "client_id", required = false) String clientId,
			@RequestParam(value = "client_secret", required = false) String clientSecret) {
		var res = authService.token(clientId, clientSecret);
		if (res.isError())
			return new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
		return ResponseEntity.ok(res.getData());
	}
}
