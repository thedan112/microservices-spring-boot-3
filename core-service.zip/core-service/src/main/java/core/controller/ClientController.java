package core.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import core.model.client.request.GetClientAddressRequest;
import core.model.client.request.GetClientByContractNumberV2Request;
import core.model.client.request.GetClientByContractV2Request;
import core.model.client.request.GetClientByIdRequest;
import core.model.client.request.GetClientByNumberV2Request;
import core.model.client.request.SetClientClassifierRequest;
import core.model.client.request.UpdateClientAddInfoRequest;
import core.model.client.request.UpdateClientAddressRequest;
import core.service.oneway.IClientService;
import jakarta.validation.Valid;

@RestController
@RequestMapping(value = "/api/v1/clients", produces = "application/json")
public class ClientController {
	@Autowired
	IClientService clientService;

	@PostMapping(value = "/get/id")
	public ResponseEntity<?> getClientById(@RequestBody @Valid GetClientByIdRequest req) {
		return ResponseEntity.ok(clientService.getById(req));
	}

	@PostMapping(value = "/get/cif")
	public ResponseEntity<?> getClientByClientNumber(@RequestBody @Valid GetClientByNumberV2Request req) {
		return ResponseEntity.ok(clientService.getByClientNumber(req));
	}

	@PostMapping(value = "/get/contract-number")
	public ResponseEntity<?> getClientByContractNumber(@RequestBody @Valid GetClientByContractNumberV2Request req) {
		return ResponseEntity.ok(clientService.getByContractNumber(req));
	}

	@PostMapping(value = "/get/contract")
	public ResponseEntity<?> getClientByContractId(@RequestBody GetClientByContractV2Request req) {
		return ResponseEntity.ok(clientService.getByContractId(req));
	}

	@PostMapping(value = "/classifier")
	public ResponseEntity<?> getClientClassifiers(@PathVariable(value = "id", required = false) String id) {
		return ResponseEntity.ok(clientService.getByClassifier(id));
	}

	@PutMapping(value = "/set/classifier")
	public ResponseEntity<?> setClientClassifier(@RequestBody SetClientClassifierRequest request) {
		return ResponseEntity.ok(clientService.setClassifier(request));
	}

	@PostMapping(value = "/get/address")
	public ResponseEntity<?> getAddressByClientId(@RequestBody @Valid GetClientAddressRequest request) {
		return ResponseEntity.ok(clientService.getAddress(request));
	}

	@PostMapping(value = "/get/identity-card")
	public ResponseEntity<?> getClientByIdCardNumber(
			@PathVariable(value = "idCard", required = false) String identityCard) {
		return ResponseEntity.ok(clientService.getByIdentityCard(identityCard));
	}

	@PutMapping(value = "/edit/add-info")
	public ResponseEntity<?> editClientAddInfo(@RequestBody UpdateClientAddInfoRequest request) {
		return ResponseEntity.ok(clientService.editClient(request));
	}

	@PutMapping(value = "/edit/address")
	public ResponseEntity<?> editClientAddress(@RequestBody UpdateClientAddressRequest request) {
		return ResponseEntity.ok(clientService.editAddress(request));
	}
}
