package core.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import core.model.transaction.request.IssueFundsTransferIssueRequest;
import core.model.transaction.request.InstallmentPlanByBalanceRequest;
import core.model.transaction.request.CreateInstallmentPlanByTransactionRequest;
import core.model.transaction.request.GetInstallmentPlansByContractRequest;
import core.model.transaction.request.PaymentIssueRequest;
import core.model.transaction.request.TransactionGetHistoryRequest;
import core.service.oneway.ITransactionService;

@RestController
@RequestMapping(value = "/api/v1/transactions", produces = "application/json")
public class TransactionController {
	@Autowired
	ITransactionService transactionService;

	@PostMapping(value = "/history")
	public ResponseEntity<?> getTransactionHistory(@RequestBody TransactionGetHistoryRequest req) {
		return ResponseEntity.ok(transactionService.history(req));
	}

	@PostMapping(value = "/issue/transfer")
	public ResponseEntity<?> issFundsTransfer(@RequestBody IssueFundsTransferIssueRequest req) {
		return ResponseEntity.ok(transactionService.issFundsTransfer(req));
	}

	@PostMapping(value = "/issue/payment")
	public ResponseEntity<?> issuePayment(@RequestBody PaymentIssueRequest req) {
		return ResponseEntity.ok(transactionService.issPaymentToContract(req));
	}

	@PostMapping(value = "/installment/transaction")
	public ResponseEntity<?> createInstallmentPlanByTransaction(
			@RequestBody CreateInstallmentPlanByTransactionRequest req) {
		return ResponseEntity.ok(transactionService.createInstallmentPlanByTransaction(req));
	}

	@PostMapping(value = "/installment/balance")
	public ResponseEntity<?> createInstallmentPlanByBalance(@RequestBody InstallmentPlanByBalanceRequest req) {
		return ResponseEntity.ok(transactionService.createInstallmentPlanByBalance(req));
	}

	@PostMapping(value = "/installments/contract") // issue contract installment plan
	public ResponseEntity<?> getInstallmentPlansByContract(@RequestBody GetInstallmentPlansByContractRequest req) {
		return ResponseEntity.ok(transactionService.getInstallmentPlansByContract(req));
	}

	@PostMapping(value = "/installments/portions/{planId}")
	public ResponseEntity<?> getInstallmentPortionsByPlanId(@PathVariable(value = "/planId") String planId) {
		return ResponseEntity.ok(transactionService.getInstallmentPortionsByPlanId(planId));
	}
}
