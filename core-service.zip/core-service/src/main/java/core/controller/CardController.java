package core.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import core.model.card.request.ActivateCardRequest;
import core.model.card.request.CreateVirtualCardRequest;
import core.model.card.request.GenerateCVV2Request;
import core.model.card.request.GenerateDynamicCVV2Request;
import core.model.card.request.ReissueCardRequest;
import core.model.card.request.SetPINRequest;
import core.model.card.request.UpdateVirtualCardPlasticRequest;
import core.service.oneway.ICardService;

@RestController
@RequestMapping(value = "/api/v1/cards", produces = "application/json")
public class CardController {
	@Autowired
	ICardService cardService;

	@GetMapping(value = "/{id}")
	public ResponseEntity<?> getCardById(@PathVariable(value = "id") String id) {
		return ResponseEntity.ok(cardService.getByCardId(id));
	}

	@GetMapping(value = "/{id}/plastic")
	public ResponseEntity<?> getCardPlasticById(@PathVariable(value = "id") String id) {
		return ResponseEntity.ok(cardService.getByCardId(id));
	}

	@GetMapping(value = "/number/{number}")
	public ResponseEntity<?> getCardByNumber(@PathVariable(value = "number") String cardNumber) {
		return ResponseEntity.ok(cardService.getByCardNumber(cardNumber));
	}

	@PostMapping(value = "/activate")
	public ResponseEntity<?> activateCard(@RequestBody ActivateCardRequest req) {
		return ResponseEntity.ok(cardService.activateCard(req));
	}

	@PutMapping(value = "/reissue")
	public ResponseEntity<?> reissueCard(@RequestBody ReissueCardRequest req) {
		return ResponseEntity.ok(cardService.reissueCard(req));
	}

	@PostMapping(value = "/create/virtual")
	public ResponseEntity<?> createVirtualCard(@RequestBody CreateVirtualCardRequest req) {
		return ResponseEntity.ok(cardService.createVirtualCard(req));
	}

	@PutMapping(value = "/update/virtual/plastic")
	public ResponseEntity<?> updateVirtualCardPlastic(@RequestBody UpdateVirtualCardPlasticRequest req) {
		return ResponseEntity.ok(cardService.updateVirtualCardPlastic(req));
	}

	@PostMapping(value = "/generate/dynamic/cvv2")
	public ResponseEntity<?> generateDynamicCVV2(@RequestBody GenerateDynamicCVV2Request req) {
		return ResponseEntity.ok(cardService.generateDynamicCVV2(req));
	}

	@PostMapping(value = "/generate/cvv2")
	public ResponseEntity<?> generateCVV2(@RequestBody GenerateCVV2Request req) {
		return ResponseEntity.ok(cardService.generateCVV2(req));
	}

	@PutMapping(value = "/set/pin")
	public ResponseEntity<?> setPIN(@RequestBody SetPINRequest req) {
		return ResponseEntity.ok(cardService.setPIN(req));
	}
}
