package core.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import core.model.contract.request.AddressesGetContractRequest;
import core.model.contract.request.BalanceHistoryGetRequest;
import core.model.contract.request.BalancesGetContractRequest;
import core.model.contract.request.BillingHistoryGetRequest;
import core.model.contract.request.ClassifierGetContractRequest;
import core.model.contract.request.ClassifierSetContractRequest;
import core.model.contract.request.CreditLimitSetContractRequest;
import core.model.contract.request.CustomSetContractDataRequest;
import core.model.contract.request.GetContractByClientV2Request;
import core.model.contract.request.StatusSetContractRequest;
import core.model.contract.request.TariffGetContractRequest;
import core.model.contract.request.TariffSetRiskControlRequest;
import core.model.contract.request.TreeGetContractRequest;
import core.service.oneway.IContractService;
import jakarta.validation.Valid;

@RestController
@RequestMapping(value = "/api/v1/contracts")
public class ContractController {
	@Autowired
	IContractService contractService;

	@PostMapping(value = "/get/client")
	public ResponseEntity<?> getContractByClient(@RequestBody @Valid GetContractByClientV2Request req) {
		return ResponseEntity.ok(contractService.getByClient(req));
	}
	
	@GetMapping(value = "/{id}")
	public ResponseEntity<?> getContractById(@PathVariable(value = "id", required = false) String id) {
		return ResponseEntity.ok(null);
	}

	@PutMapping(value = "/status")
	public ResponseEntity<?> setContractStatus(@RequestBody StatusSetContractRequest req) {
		return ResponseEntity.ok(null);
	}

	@PostMapping(value = "/get/classifiers")
	public ResponseEntity<?> getContractClassifiers(@RequestBody ClassifierGetContractRequest req) {
		return ResponseEntity.ok(null);
	}

	@PutMapping(value = "/classifier")
	public ResponseEntity<?> setContractClassifier(@RequestBody ClassifierSetContractRequest req) {
		return ResponseEntity.ok(null);
	}

	@PostMapping(value = "/get/balances")
	public ResponseEntity<?> getContractBalances(@RequestBody BalancesGetContractRequest req) {
		return ResponseEntity.ok(null);
	}

	@PostMapping(value = "/get/addresses")
	public ResponseEntity<?> getAddressesByContractId(@RequestBody AddressesGetContractRequest req) {
		return ResponseEntity.ok(null);
	}

	@GetMapping(value = "/number/{contractNumber}")
	public ResponseEntity<?> getContractByNumber(@PathVariable(value = "contractNumber") String contractNumber) {
		return ResponseEntity.ok(null);
	}

	@PostMapping(value = "/get/tree")
	public ResponseEntity<?> getContractTree(@RequestBody TreeGetContractRequest req) {
		return ResponseEntity.ok(null);
	}

	@PutMapping(value = "/creditlimit")
	public ResponseEntity<?> setContractCreditLimit(@RequestBody CreditLimitSetContractRequest req) {
		return ResponseEntity.ok(null);
	}

	@PutMapping(value = "/custom/contractdata")
	public ResponseEntity<?> setCustomContractData(@RequestBody CustomSetContractDataRequest req) {
		return ResponseEntity.ok(null);
	}

	@PostMapping(value = "/get/tariff")
	public ResponseEntity<?> getTariffDataByContract(@RequestBody TariffGetContractRequest req) {
		return ResponseEntity.ok(null);
	}

	@PutMapping(value = "/tariff/risk-control")
	public ResponseEntity<?> setRiskControlTariff(@RequestBody TariffSetRiskControlRequest req) {
		return ResponseEntity.ok(null);
	}

	@PostMapping(value = "/get/billing-history")
	public ResponseEntity<?> getBillingHistoryByContract(@RequestBody BillingHistoryGetRequest req) {
		return ResponseEntity.ok(null);
	}

	@PostMapping(value = "/get/balance-history")
	public ResponseEntity<?> getBalanceHistoryByContract(@RequestBody BalanceHistoryGetRequest req) {
		return ResponseEntity.ok(null);
	}

	@PostMapping(value = "/get/issuing/transactions")
	public ResponseEntity<?> getIssuingContractTransactions(@RequestBody BalanceHistoryGetRequest req) {
		return ResponseEntity.ok(null);
	}
}