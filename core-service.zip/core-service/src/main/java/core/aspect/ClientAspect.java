package core.aspect;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;

import lombok.extern.slf4j.Slf4j;

@Aspect
@Slf4j
@Component
public class ClientAspect {
	/*
	 * Pointcut định nghĩa nơi advice sẽ được áp dụng.
	 * 
	 * @Before cho phép ghi log trước khi thực thi phương thức
	 * 
	 * @Around advice cho phép chúng ta thực thi logic trước và sau
	 */

	@Pointcut("execution(* core.service.oneway.impl.ClientServiceImpl.*(..))")
	public void clientServiceImplMethod() {
	}

	@Pointcut("execution(* core.service.oneway.impl.ClientServiceImpl.getById(String))")
	public void getByIdMethod() {
	}

	@Before("clientService()")
	public void before(JoinPoint point) {
		log.error("Request: {}", point.toString());
	}

	@Around("getByIdMethod()")
	public Object around(ProceedingJoinPoint joinPoint) throws Throwable {
		Object[] args = joinPoint.getArgs();
		String method = joinPoint.getSignature().getName();
		log.info("Method= {}, Arguments: {}", method, args[0]);
		var rs = joinPoint.proceed();
		log.info("Method= {}, Arguments: {}, response: {}", method, args[0], rs);
		return rs;
	}
	
	@AfterThrowing("clientService()")
	public void afterException(JoinPoint point) {
		log.error("Throwing by method: {}, message: {}", point.toString());
	}
}
