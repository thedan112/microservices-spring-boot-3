package core.service.oneway;

import core.model.ApiResponse;
import core.model.client.request.GetClientAddressRequest;
import core.model.client.request.GetClientByContractNumberV2Request;
import core.model.client.request.GetClientByContractV2Request;
import core.model.client.request.GetClientByIdRequest;
import core.model.client.request.GetClientByNumberV2Request;
import core.model.client.request.SetClientClassifierRequest;
import core.model.client.request.UpdateClientAddInfoRequest;
import core.model.client.request.UpdateClientAddressRequest;

public interface IClientService {

	public ApiResponse<?> getById(GetClientByIdRequest req);

	public ApiResponse<?> getByClientNumber(GetClientByNumberV2Request req);

	public ApiResponse<?> getByContractNumber(GetClientByContractNumberV2Request req);

	public ApiResponse<?> getByContractId(GetClientByContractV2Request req);

	public ApiResponse<?> getByClassifier(String id);

	public ApiResponse<?> setClassifier(SetClientClassifierRequest request);

	public ApiResponse<?> getByIdentityCard(String identityCardNumber);

	public ApiResponse<?> getAddress(GetClientAddressRequest request);

	public ApiResponse<?> editAddress(UpdateClientAddressRequest request);
	
	public ApiResponse<?> editClient(UpdateClientAddInfoRequest request);
}
