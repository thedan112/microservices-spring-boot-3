package core.service.oneway.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import core.component.OneWayClient;
import core.constant.Constant;
import core.model.ApiResponse;
import core.model.contract.request.AddressesGetContractRequest;
import core.model.contract.request.BalanceHistoryGetRequest;
import core.model.contract.request.BalancesGetContractRequest;
import core.model.contract.request.BillingHistoryGetRequest;
import core.model.contract.request.ClassifierGetContractRequest;
import core.model.contract.request.ClassifierSetContractRequest;
import core.model.contract.request.CreditLimitSetContractRequest;
import core.model.contract.request.CustomSetContractDataRequest;
import core.model.contract.request.GetContractByClientV2Request;
import core.model.contract.request.IssuingContractTransactionRequest;
import core.model.contract.request.StatusSetContractRequest;
import core.model.contract.request.TariffGetContractRequest;
import core.model.contract.request.TariffSetRiskControlRequest;
import core.model.contract.request.TreeGetContractRequest;
import core.model.contract.response.GetContractByClientV2Response;
import core.service.oneway.IContractService;
import core.util.HelperUtil;
import core.util.OneWayUtil;

@Service
public class ConstractServiceImpl implements IContractService {
	@Autowired
	OneWayClient oneWayClient;

	@Override
	public ApiResponse<?> getById(String id) {

		return ApiResponse.success(null);
	}

	@Override
	public ApiResponse<?> getByNumber(String contractNumber) {

		return ApiResponse.success(null);
	}

	@Override
	public ApiResponse<?> setStatus(StatusSetContractRequest req) {

		return ApiResponse.success(null);
	}

	@Override
	public ApiResponse<?> getClassifier(ClassifierGetContractRequest req) {

		return ApiResponse.success(null);
	}

	@Override
	public ApiResponse<?> setClassifier(ClassifierSetContractRequest req) {

		return ApiResponse.success(null);
	}

	@Override
	public ApiResponse<?> getBalances(BalancesGetContractRequest req) {

		return ApiResponse.success(null);
	}

	@Override
	public ApiResponse<?> getAddressesByContractId(AddressesGetContractRequest req) {

		return ApiResponse.success(null);
	}

	@Override
	public ApiResponse<?> getContractTree(TreeGetContractRequest req) {

		return ApiResponse.success(null);
	}

	@Override
	public ApiResponse<?> setContractCreditLimit(CreditLimitSetContractRequest req) {

		return ApiResponse.success(null);
	}

	@Override
	public ApiResponse<?> setCustomContractData(CustomSetContractDataRequest req) {

		return ApiResponse.success(null);
	}

	@Override
	public ApiResponse<?> getByClient(GetContractByClientV2Request req) {
		var soapRequest = HelperUtil.generateSoapRequest(req);
		String xml = HelperUtil.marshaller(soapRequest, GetContractByClientV2Request.class);
		String response = oneWayClient.post(xml, Constant.STRING_TYPE_REFERENCE);
		GetContractByClientV2Response res = HelperUtil.unmarshaller(response, GetContractByClientV2Response.class);
		var rs = OneWayUtil.validationResult(res);
		if (rs.isError())
			return rs;
		return ApiResponse.success(res.getBody().getResponse());
	}

	@Override
	public ApiResponse<?> getTariffDataByContract(TariffGetContractRequest req) {
		return ApiResponse.success(null);
	}

	@Override
	public ApiResponse<?> setRiskControlTariff(TariffSetRiskControlRequest req) {

		return ApiResponse.success(null);
	}

	@Override
	public ApiResponse<?> getBillingHistory(BillingHistoryGetRequest req) {

		return ApiResponse.success(null);
	}

	@Override
	public ApiResponse<?> getBalanceHistory(BalanceHistoryGetRequest req) {

		return ApiResponse.success(null);
	}

	@Override
	public ApiResponse<?> getIssuingContractTransactions(IssuingContractTransactionRequest req) {

		return ApiResponse.success(null);
	}

	@Override
	public ApiResponse<?> openEvent() {

		return ApiResponse.success(null);
	}

	@Override
	public ApiResponse<?> getTariffDataBy() {

		return ApiResponse.success(null);
	}

//	@Override
//	public ApiResponse<?> getByClient(GetContractByClientV2Request req) {
//		var request = req.buildSoapRequest();
//		String xml = HelperUtil.marshaller(request, GetContractByClientV2Request.class);
//		if (StringUtils.isBlank(xml))
//			return ApiResponse.error(StatusCode.ERROR_BUILD_REQUEST_XML);
//		String response = oneWayClient.post(xml, Constant.STRING_TYPE_REFERENCE);
//		GetContractByClientV2Response resp = HelperUtil.unmarshaller(response, GetContractByClientV2Response.class);
//		var rs = OneWayUtil.validationResult(resp);
//		if (rs.isError())
//			return rs;
//		return ApiResponse.success(resp.getBody().getResponse().getResult().getOutObject().getRecords());
//		return ApiResponse.success(null);
//	}

//	@Override
//	public ApiResponse<?> getByContractNumber(String contractNumber) {
//		if (StringUtils.isBlank(contractNumber))
//			throw new MissingPathVariableException("contractNumber");
//		var request = new GetContractByNumberV2Request(contractNumber).buildSoapRequest();
//		String xml = HelperUtil.marshaller(request, GetContractByNumberV2Request.class);
//		if (StringUtils.isBlank(xml))
//			return ApiResponse.error(StatusCode.ERROR_BUILD_REQUEST_XML);
//		String response = oneWayClient.post(xml, Constant.STRING_TYPE_REFERENCE);
//		GetContractByNumberV2Response resp = HelperUtil.unmarshaller(response, GetContractByNumberV2Response.class);
//		var rs = OneWayUtil.validationResult(resp);
//		if (rs.isError())
//			return rs;
//		return ApiResponse.success(resp.getBody().getResponse().getResult().getOutObject().getRecords());
//	}
//
//	@Override
//	public ApiResponse<?> getById(String id) {
//		if (StringUtils.isBlank(id))
//			throw new MissingPathVariableException("id");
//		var request = new GetContractByIDV2Request(id).buildSoapRequest();
//		String xml = HelperUtil.marshaller(request, GetContractByIDV2Request.class);
//		if (StringUtils.isBlank(xml))
//			return ApiResponse.error(StatusCode.ERROR_BUILD_REQUEST_XML);
//		String response = oneWayClient.post(xml, Constant.STRING_TYPE_REFERENCE);
//		GetContractByIDV2Response resp = HelperUtil.unmarshaller(response, GetContractByIDV2Response.class);
//		var rs = OneWayUtil.validationResult(resp);
//		if (rs.isError())
//			return rs;
//		return ApiResponse.success(resp.getBody().getResponse().getResult().getOutObject().getRecord());
//	}

}
