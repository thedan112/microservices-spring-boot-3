package core.service.oneway;

import core.model.ApiResponse;
import core.model.contract.request.AddressesGetContractRequest;
import core.model.contract.request.BalanceHistoryGetRequest;
import core.model.contract.request.BalancesGetContractRequest;
import core.model.contract.request.BillingHistoryGetRequest;
import core.model.contract.request.ClassifierGetContractRequest;
import core.model.contract.request.ClassifierSetContractRequest;
import core.model.contract.request.GetContractByClientV2Request;
import core.model.contract.request.CreditLimitSetContractRequest;
import core.model.contract.request.CustomSetContractDataRequest;
import core.model.contract.request.IssuingContractTransactionRequest;
import core.model.contract.request.StatusSetContractRequest;
import core.model.contract.request.TariffGetContractRequest;
import core.model.contract.request.TariffSetRiskControlRequest;
import core.model.contract.request.TreeGetContractRequest;

public interface IContractService {

	public ApiResponse<?> getById(String id);
	
	public ApiResponse<?> getByNumber(String contractNumber);
	
	public ApiResponse<?> setStatus(StatusSetContractRequest req);
	
	public ApiResponse<?> getClassifier(ClassifierGetContractRequest req);
	
	public ApiResponse<?> setClassifier(ClassifierSetContractRequest req);
	
	public ApiResponse<?> getBalances(BalancesGetContractRequest req);
	
	public ApiResponse<?> getAddressesByContractId(AddressesGetContractRequest req);
	
	public ApiResponse<?> getContractTree(TreeGetContractRequest req);
	
	public ApiResponse<?> setContractCreditLimit(CreditLimitSetContractRequest req);
	
	public ApiResponse<?> setCustomContractData(CustomSetContractDataRequest req);
	
	public ApiResponse<?> getByClient(GetContractByClientV2Request req);
	
	public ApiResponse<?> getTariffDataByContract(TariffGetContractRequest req);
	
	public ApiResponse<?> setRiskControlTariff(TariffSetRiskControlRequest req);
	
	public ApiResponse<?> getBillingHistory(BillingHistoryGetRequest req);
	
	public ApiResponse<?> getBalanceHistory(BalanceHistoryGetRequest req);
	
	public ApiResponse<?> getIssuingContractTransactions(IssuingContractTransactionRequest req);
	
	public ApiResponse<?> openEvent();
	
	public ApiResponse<?> getTariffDataBy();
}