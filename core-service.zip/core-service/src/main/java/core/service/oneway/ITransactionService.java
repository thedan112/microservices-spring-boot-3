package core.service.oneway;

import core.model.ApiResponse;
import core.model.transaction.request.IssueFundsTransferIssueRequest;
import core.model.transaction.request.InstallmentPlanByBalanceRequest;
import core.model.transaction.request.CreateInstallmentPlanByTransactionRequest;
import core.model.transaction.request.GetInstallmentPlansByContractRequest;
import core.model.transaction.request.PaymentIssueRequest;
import core.model.transaction.request.TransactionGetHistoryRequest;

public interface ITransactionService {

	public ApiResponse<?> history(TransactionGetHistoryRequest req);
	
	public ApiResponse<?> issFundsTransfer(IssueFundsTransferIssueRequest req);
	
	public ApiResponse<?> issPaymentToContract(PaymentIssueRequest req);

	public ApiResponse<?> createInstallmentPlanByTransaction(CreateInstallmentPlanByTransactionRequest req);
	
	public ApiResponse<?> createInstallmentPlanByBalance(InstallmentPlanByBalanceRequest req);
	
	public ApiResponse<?> getInstallmentPlansByContract(GetInstallmentPlansByContractRequest req);
	
	public ApiResponse<?> getInstallmentPortionsByPlanId(String id);
}
