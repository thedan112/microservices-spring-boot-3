package core.service.oneway.impl;

import org.springframework.stereotype.Service;

import core.model.ApiResponse;
import core.model.card.request.ActivateCardRequest;
import core.model.card.request.CreateVirtualCardRequest;
import core.model.card.request.GenerateCVV2Request;
import core.model.card.request.GenerateDynamicCVV2Request;
import core.model.card.request.ReissueCardRequest;
import core.model.card.request.SetPINRequest;
import core.model.card.request.UpdateVirtualCardPlasticRequest;
import core.service.oneway.ICardService;

@Service
public class CardServiceImpl implements ICardService {

	@Override
	public ApiResponse<?> getByCardId(String cardId) {
		return null;
	}

	@Override
	public ApiResponse<?> getByCardNumber(String cardNumber) {
		return null;
	}

	@Override
	public ApiResponse<?> activateCard(ActivateCardRequest req) {
		return null;
	}

	@Override
	public ApiResponse<?> reissueCard(ReissueCardRequest req) {
		return null;
	}

	@Override
	public ApiResponse<?> createVirtualCard(CreateVirtualCardRequest req) {
		return null;
	}

	@Override
	public ApiResponse<?> updateVirtualCardPlastic(UpdateVirtualCardPlasticRequest req) {
		return null;
	}

	@Override
	public ApiResponse<?> generateDynamicCVV2(GenerateDynamicCVV2Request req) {
		return null;
	}

	@Override
	public ApiResponse<?> generateCVV2(GenerateCVV2Request req) {
		return null;
	}

	@Override
	public ApiResponse<?> setPIN(SetPINRequest req) {
		return null;
	}
}