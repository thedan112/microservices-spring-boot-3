package core.service.oneway.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import core.component.OneWayClient;
import core.constant.Constant;
import core.model.ApiResponse;
import core.model.client.request.GetClientAddressRequest;
import core.model.client.request.GetClientByContractNumberV2Request;
import core.model.client.request.GetClientByContractV2Request;
import core.model.client.request.GetClientByIdRequest;
import core.model.client.request.GetClientByNumberV2Request;
import core.model.client.request.SetClientClassifierRequest;
import core.model.client.request.UpdateClientAddInfoRequest;
import core.model.client.request.UpdateClientAddressRequest;
import core.model.client.response.GetClientByContractNumberV2Response;
import core.model.client.response.GetClientByContractV2Response;
import core.model.client.response.GetClientByIdResponse;
import core.model.client.response.GetClientByNumberV2Response;
import core.service.oneway.IClientService;
import core.setting.AppSetting;
import core.util.HelperUtil;
import core.util.OneWayUtil;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class ClientServiceImpl implements IClientService {
	@Autowired
	OneWayClient oneWayClient;
	@Autowired
	AppSetting appSetting;

	@Override
	public ApiResponse<?> getById(GetClientByIdRequest req) {
		var request = HelperUtil.generateSoapRequest(req);
		String xml = HelperUtil.marshaller(request, GetClientByIdRequest.class);
		String response = oneWayClient.post(xml, Constant.STRING_TYPE_REFERENCE);
		GetClientByIdResponse resp = HelperUtil.unmarshaller(response, GetClientByIdResponse.class);
		var rs = OneWayUtil.validationResult(resp);
		if (rs.isError())
			return rs;
		return ApiResponse.success(resp.getBody().getResponse());
	}

	@Override
	public ApiResponse<?> getByClientNumber(GetClientByNumberV2Request req) {
		var request = HelperUtil.generateSoapRequest(req);
		String xml = HelperUtil.marshaller(request, GetClientByNumberV2Request.class);
		String response = oneWayClient.post(xml, Constant.STRING_TYPE_REFERENCE);
		GetClientByNumberV2Response resp = HelperUtil.unmarshaller(response, GetClientByNumberV2Response.class);
		var rs = OneWayUtil.validationResult(resp);
		if (rs.isError())
			return rs;
		return ApiResponse.success(resp.getBody().getResponse());
	}

	@Override
	public ApiResponse<?> getByContractNumber(GetClientByContractNumberV2Request req) {
		var request = HelperUtil.generateSoapRequest(req);
		String xml = HelperUtil.marshaller(request, GetClientByContractNumberV2Request.class);
		String response = oneWayClient.post(xml, Constant.STRING_TYPE_REFERENCE);
		GetClientByContractNumberV2Response resp = HelperUtil.unmarshaller(response,
				GetClientByContractNumberV2Response.class);
		var rs = OneWayUtil.validationResult(resp);
		if (rs.isError())
			return rs;
		return ApiResponse.success(resp.getBody().getResponse());
	}

	@Override
	public ApiResponse<?> getByContractId(GetClientByContractV2Request req) {
		var request = HelperUtil.generateSoapRequest(req);
		String xml = HelperUtil.marshaller(request, GetClientByContractV2Request.class);
		String response = oneWayClient.post(xml, Constant.STRING_TYPE_REFERENCE);
		GetClientByContractV2Response resp = HelperUtil.unmarshaller(response, GetClientByContractV2Response.class);
		var rs = OneWayUtil.validationResult(resp);
		if (rs.isError())
			return rs;
		return ApiResponse.success(resp.getBody().getResponse().getResult());
	}

	@Override
	public ApiResponse<?> getByClassifier(String id) {
		return ApiResponse.success(null);
	}

	@Override
	public ApiResponse<?> setClassifier(SetClientClassifierRequest request) {
		return ApiResponse.success(null);
	}

	@Override
	public ApiResponse<?> getByIdentityCard(String identityCardNumber) {
		return ApiResponse.success(null);
	}

	@Override
	public ApiResponse<?> getAddress(GetClientAddressRequest request) {
		var payload = HelperUtil.generateSoapRequest(request);
		String xml = HelperUtil.marshaller(payload, GetClientAddressRequest.class);
		log.info("Payload: {}", xml);
		return ApiResponse.success(null);
	}

	@Override
	public ApiResponse<?> editAddress(UpdateClientAddressRequest request) {
		return ApiResponse.success(null);
	}

	@Override
	public ApiResponse<?> editClient(UpdateClientAddInfoRequest request) {
		return ApiResponse.success(null);
	}
}
