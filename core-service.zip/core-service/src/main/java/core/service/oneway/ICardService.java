package core.service.oneway;

import core.model.ApiResponse;
import core.model.card.request.ActivateCardRequest;
import core.model.card.request.CreateVirtualCardRequest;
import core.model.card.request.GenerateCVV2Request;
import core.model.card.request.GenerateDynamicCVV2Request;
import core.model.card.request.ReissueCardRequest;
import core.model.card.request.SetPINRequest;
import core.model.card.request.UpdateVirtualCardPlasticRequest;

public interface ICardService {

	public ApiResponse<?> getByCardId(String cardId);

	public ApiResponse<?> getByCardNumber(String cardNumber);

	public ApiResponse<?> activateCard(ActivateCardRequest req);

	public ApiResponse<?> reissueCard(ReissueCardRequest req);

	public ApiResponse<?> createVirtualCard(CreateVirtualCardRequest req);

	public ApiResponse<?> updateVirtualCardPlastic(UpdateVirtualCardPlasticRequest req);

	public ApiResponse<?> generateDynamicCVV2(GenerateDynamicCVV2Request req);

	public ApiResponse<?> generateCVV2(GenerateCVV2Request req);

	public ApiResponse<?> setPIN(SetPINRequest req);
}
