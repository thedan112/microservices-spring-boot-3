package core.service.oneway.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import core.component.OneWayClient;
import core.model.ApiResponse;
import core.model.transaction.request.IssueFundsTransferIssueRequest;
import core.model.transaction.request.InstallmentPlanByBalanceRequest;
import core.model.transaction.request.CreateInstallmentPlanByTransactionRequest;
import core.model.transaction.request.GetInstallmentPlansByContractRequest;
import core.model.transaction.request.PaymentIssueRequest;
import core.model.transaction.request.TransactionGetHistoryRequest;
import core.service.oneway.ITransactionService;

@Service
public class TransactionServiceImpl implements ITransactionService {
	@Autowired
	OneWayClient oneWayClient;

	@Override
	public ApiResponse<?> history(TransactionGetHistoryRequest req) {
		return ApiResponse.success(null);
	}

	@Override
	public ApiResponse<?> issFundsTransfer(IssueFundsTransferIssueRequest req) {
		return ApiResponse.success(null);
	}

	@Override
	public ApiResponse<?> issPaymentToContract(PaymentIssueRequest req) {
		return ApiResponse.success(null);
	}

	@Override
	public ApiResponse<?> createInstallmentPlanByTransaction(CreateInstallmentPlanByTransactionRequest req) {
		return ApiResponse.success(null);
	}

	@Override
	public ApiResponse<?> createInstallmentPlanByBalance(InstallmentPlanByBalanceRequest req) {
		return ApiResponse.success(null);
	}

	@Override
	public ApiResponse<?> getInstallmentPlansByContract(GetInstallmentPlansByContractRequest req) {
		return ApiResponse.success(null);
	}

	@Override
	public ApiResponse<?> getInstallmentPortionsByPlanId(String id) {
		return ApiResponse.success(null);
	}
}
