package core.service.authentication;

import core.model.ApiResponse;

public interface IAuthenticationService {

	public ApiResponse<?> token(String clientId, String clientSecret);
}
