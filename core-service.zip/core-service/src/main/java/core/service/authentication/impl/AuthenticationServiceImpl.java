package core.service.authentication.impl;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.stereotype.Service;

import core.dto.BearerTokenDto;
import core.dto.UserDetailDto;
import core.enums.StatusCode;
import core.filter.JwtTokenFilter;
import core.model.ApiResponse;
import core.service.authentication.IAuthenticationService;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class AuthenticationServiceImpl implements IAuthenticationService {
	@Autowired
	AuthenticationManager authenticationManager;

	@Autowired
	JwtTokenFilter jwtTokenFilter;

	@Override
	public ApiResponse<?> token(String clientId, String clientSecret) {
		try {
			if (StringUtils.isBlank(clientId) || StringUtils.isBlank(clientSecret))
				return ApiResponse.error(StatusCode.UNAUTHORIZED);
			if (jwtTokenFilter.hasAuthorized(clientId, clientSecret)) {
				Authentication authentication = authenicate(clientId, clientSecret);
				UserDetailDto userDetail = (UserDetailDto) authentication.getPrincipal();
				String token = jwtTokenFilter.doGenerateToken(userDetail);
				if (StringUtils.isBlank(token))
					return ApiResponse.error(StatusCode.UNAUTHORIZED);
				var response = new BearerTokenDto(token, userDetail.getExpiry().getTime(), "Bearer");
				return ApiResponse.success(response);
			}
		} catch (AuthenticationException ex) {
			log.error("ClientId: {}, Unauthorized by: {}", clientId, ex.getMessage());
		}
		return ApiResponse.error(StatusCode.UNAUTHORIZED);
	}

	private Authentication authenicate(String clientId, String clientSecret) {
		return authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(clientId, clientSecret));
	}
}