package core.service.aws;

import java.io.File;
import java.util.List;

import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.model.PutObjectResponse;

public interface IS3Service {

	public S3Client s3Client();

	public PutObjectResponse put(String bucket, String objectName, byte[] file);

	public PutObjectResponse put(String bucket, String objectName, File file);

	public byte[] pull(String bucket, String objectName);

	public Boolean delete(String bucket, String objectName);

	public List<String> getObjects(String bucket, String prefix);

	public Boolean doesBucketExisted(String bucket);

	public Boolean doesObjectExisted(String bucket, String objectName);
}
