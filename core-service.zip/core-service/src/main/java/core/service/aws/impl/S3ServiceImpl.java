package core.service.aws.impl;

import java.io.File;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import core.service.aws.IS3Service;
import lombok.extern.slf4j.Slf4j;
import software.amazon.awssdk.core.ResponseInputStream;
import software.amazon.awssdk.core.sync.RequestBody;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.model.DeleteObjectRequest;
import software.amazon.awssdk.services.s3.model.GetObjectRequest;
import software.amazon.awssdk.services.s3.model.GetObjectResponse;
import software.amazon.awssdk.services.s3.model.HeadBucketRequest;
import software.amazon.awssdk.services.s3.model.HeadBucketResponse;
import software.amazon.awssdk.services.s3.model.HeadObjectRequest;
import software.amazon.awssdk.services.s3.model.HeadObjectResponse;
import software.amazon.awssdk.services.s3.model.ListObjectsV2Request;
import software.amazon.awssdk.services.s3.model.ListObjectsV2Response;
import software.amazon.awssdk.services.s3.model.PutObjectRequest;
import software.amazon.awssdk.services.s3.model.PutObjectResponse;
import software.amazon.awssdk.services.s3.model.S3Exception;
import software.amazon.awssdk.services.s3.model.S3Object;

@Service
@Slf4j
public class S3ServiceImpl implements IS3Service {

	private static final String region = "ap-southeast-1";
//	private static final String webIdentityTokenFile = System.getenv("AWS_WEB_IDENTITY_TOKEN_FILE");

	@Override
	public S3Client s3Client() {
		return S3Client.builder().region(Region.of(region)).build();
	}

	@Override
	public PutObjectResponse put(String bucket, String objectName, byte[] file) {
		PutObjectRequest request = PutObjectRequest.builder().bucket(bucket).key(objectName).build();
		return s3Client().putObject(request, RequestBody.fromBytes(file));
	}

	@Override
	public PutObjectResponse put(String bucket, String objectName, File file) {
		PutObjectRequest request = PutObjectRequest.builder().bucket(bucket).key(objectName).build();
		return s3Client().putObject(request, RequestBody.fromFile(file));
	}

	@Override
	public byte[] pull(String bucket, String objectName) {
		if (!doesObjectExisted(bucket, objectName))
			return null;
		GetObjectRequest request = GetObjectRequest.builder().bucket(bucket).key(objectName).build();
		try (ResponseInputStream<GetObjectResponse> response = s3Client().getObject(request)) {
			return response.readAllBytes();
		} catch (Exception e) {
			log.error("[Bucket: {}, ObjectName: {}] Pull error: {} !", bucket, objectName, e.getMessage());
		}
		return null;
	}

	@Override
	public Boolean delete(String bucket, String objectName) {
		if (!doesObjectExisted(bucket, objectName))
			return false;
		try {
			DeleteObjectRequest request = DeleteObjectRequest.builder().bucket(bucket).key(objectName).build();
			s3Client().deleteObject(request);
			return true;
		} catch (Exception e) {
			log.error("[Bucket: {}, ObjectName: {}] Pull error: {} !", bucket, objectName, e.getMessage());
		}
		return false;
	}

	@Override
	public List<String> getObjects(String bucket, String prefix) {
		ListObjectsV2Request request = ListObjectsV2Request.builder().bucket(bucket).prefix(prefix).build();
		ListObjectsV2Response response = s3Client().listObjectsV2(request);
		if (response.contents().isEmpty()) {
			log.error("Not exist any file in Bucket: {} and Prefix: {}  !", bucket, prefix);
			return null;
		}
		return response.contents().stream().map(S3Object::key).collect(Collectors.toList());
	}

	@Override
	public Boolean doesBucketExisted(String bucket) {
		try {
			HeadBucketResponse res = s3Client().headBucket(HeadBucketRequest.builder().bucket(bucket).build());
			if (res != null)
				return true;
			log.error("[S3Bucket: {}] Response is null {}", bucket);
		} catch (S3Exception e) {
			if (e.statusCode() == 404)
				log.error("[S3Bucket: {}] Not found data !", bucket);
			else
				log.error("[S3Bucket: {}] Error by msg: {}", bucket, e.getMessage());
		}
		return false;
	}

	@Override
	public Boolean doesObjectExisted(String bucket, String objectName) {
		try {
			HeadObjectResponse res = s3Client()
					.headObject(HeadObjectRequest.builder().bucket(bucket).key(objectName).build());
			if (res != null)
				return true;
			log.error("[S3Bucket: {} - Object: {}] Response is null {}", bucket, objectName);
		} catch (S3Exception e) {
			if (e.statusCode() == 404)
				log.error("[S3Bucket: {}, Object: {}] Not found data !", bucket, objectName);
			else
				log.error("[S3Bucket: {}, Object: {}] Error by msg: {}", bucket, objectName, e.getMessage());
		}
		return false;
	}
}
