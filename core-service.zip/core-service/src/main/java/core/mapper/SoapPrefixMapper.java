package core.mapper;

import org.glassfish.jaxb.runtime.marshaller.NamespacePrefixMapper;

public class SoapPrefixMapper extends NamespacePrefixMapper {
	public static final String SOAP_NAMESPACE_ENV = "http://schemas.xmlsoap.org/soap/envelope/";
	public static final String SOAP_NAMESPACE_WSIN = "http://www.openwaygroup.com/wsint";
	public static final String SOAPENV_PREFIX = "soapenv";
	public static final String WSIN_PREFIX = "wsin";

	@Override
	public String getPreferredPrefix(String namespaceUri, String suggestion, boolean requirePrefix) {
		if (SOAP_NAMESPACE_ENV.equals(namespaceUri)) {
			return SOAPENV_PREFIX;
		} else if (SOAP_NAMESPACE_WSIN.equals(namespaceUri)) {
			return WSIN_PREFIX;
		}
		return suggestion;
	}

}
