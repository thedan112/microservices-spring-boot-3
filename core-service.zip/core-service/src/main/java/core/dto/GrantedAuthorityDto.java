package core.dto;

import java.util.List;
import java.util.Set;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.util.CollectionUtils;

import com.fasterxml.jackson.annotation.JsonIgnore;

import core.enums.RoleEnum;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class GrantedAuthorityDto implements GrantedAuthority {
	private static final long serialVersionUID = 5101781360477935766L;

	private List<String> roles;
	private Set<String> scopes;
	@JsonIgnore
	private String authority;

	public GrantedAuthorityDto(List<String> roles, Set<String> scopes) {
		this.roles = roles;
		this.scopes = scopes;
		this.authority = null;
	}

	@JsonIgnore
	public Boolean isNotEmpty() {
		if(this.roles.contains(RoleEnum.ADMIN.toString()))
			return true;
		if(CollectionUtils.isEmpty(this.roles) || CollectionUtils.isEmpty(this.scopes))
			return false;
		return true;
	}
	
	@Override
	public String getAuthority() {
		return authority;
	}
}
