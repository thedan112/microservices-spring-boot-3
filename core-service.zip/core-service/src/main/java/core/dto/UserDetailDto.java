package core.dto;

import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Collection;
import java.util.Date;
import java.util.UUID;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import core.config.AuthorityConfig;
import core.util.HelperUtil;
import io.jsonwebtoken.Claims;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonDeserialize
public class UserDetailDto implements UserDetails {
	private static final long serialVersionUID = -8516955158955716797L;
	private String id;
	private String username;
	@JsonIgnore
	private String password;
	private Date expiry;
	private GrantedAuthorityDto authority;
	@JsonIgnore
	private Collection<? extends GrantedAuthority> authorities;

	public UserDetailDto(String clientId, String clientSecret, GrantedAuthorityDto authority) {
		this.id = UUID.randomUUID().toString();
		this.username = clientId;
		this.password = clientSecret;
		this.expiry = Date.from(Instant.now().plus(15, ChronoUnit.MINUTES));
		this.authority = authority;
		this.authorities = null;
	}

	public UserDetailDto(Claims claims) {
		this.id = claims.getId();
		this.username = claims.getSubject();
		this.password = new BCryptPasswordEncoder().encode(AuthorityConfig.getClientSecretByKey(username));
		this.expiry = Date.from(Instant.now().plus(15, ChronoUnit.MINUTES));
		TypeReference<GrantedAuthorityDto> responType = new TypeReference<GrantedAuthorityDto>() {
		};
		this.authority = HelperUtil.parserFromValue(claims.get("authority"), responType);
	}
}
