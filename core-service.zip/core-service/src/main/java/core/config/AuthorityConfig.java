package core.config;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import core.util.HelperUtil;
import lombok.extern.slf4j.Slf4j;

@Configuration
@Slf4j
public class AuthorityConfig {

	public static Map<String, String> CLIENT_SECRETS = new HashMap<>();
	public static Map<String, String> RESOURCE_SCOPE = new HashMap<>();
	public static Map<String, List<String>> CLIENT_ROLES = new HashMap<>();
	public static Map<String, List<String>> ROLE_SCOPES = new HashMap<>();

	@Bean
	public Boolean initAuthorities() {
		initAuthoriies();
		return true;
	}

	private void initAuthoriies() {
		CLIENT_SECRETS = getClientSecrets();
		CLIENT_ROLES = getClientRoles();
		ROLE_SCOPES = getRoleScope();
		RESOURCE_SCOPE = getResourceRole();
	}

	public static String readFile(String path) {
		try {
			File file = new File(path);
			byte[] bytes = Files.readAllBytes(file.toPath());
			return new String(bytes, StandardCharsets.UTF_8);
		} catch (IOException e) {
			log.error("Get Secret Error: {}", e.getMessage());
		}
		return null;
	}

	public static Map<String, String> getClientSecrets() {
		String rs = readFile("/Users/hienle1997/Work/0. Project/5. FE/Authenticate/secret.json");
		return HelperUtil.parserFromJson(rs, HashMap.class);
	}

	public static Map<String, List<String>> getClientRoles() {
		String rs = readFile("/Users/hienle1997/Work/0. Project/5. FE/Authenticate/client_app.json");
		return HelperUtil.parserFromJson(rs, HashMap.class);
	}

	public static Map<String, String> getResourceRole() {
		String rs = readFile("/Users/hienle1997/Work/0. Project/5. FE/Authenticate/resource_scope.json");
		return HelperUtil.parserFromJson(rs, HashMap.class);
	}

	public static Map<String, List<String>> getRoleScope() {
		String rs = readFile("/Users/hienle1997/Work/0. Project/5. FE/Authenticate/permission.json");
		return HelperUtil.parserFromJson(rs, HashMap.class);
	}

	public static String getClientSecretByKey(String key) {
		return CLIENT_SECRETS.get(key);
	}

	public static List<String> getRolesByClient(String key) {
		return CLIENT_ROLES.get(key);
	}

	public static String getScopeByUri(String key) {
		return RESOURCE_SCOPE.get(key);
	}

	public static List<String> getScopesByRole(String key) {
		return ROLE_SCOPES.get(key);
	}

	public static void putClientSecret(String key, String value) {
		CLIENT_SECRETS.put(key, value);
		log.info("ClientSecrets Putted Success: {}", key);
	}

	public static void putClientRoles(String key, List<String> value) {
		CLIENT_ROLES.put(key, value);
		log.info("ClientRoles Putted Success: {}", key);
	}

	public static void putResourceScope(String key, String value) {
		RESOURCE_SCOPE.put(key, value);
		log.info("ResourceScope Putted Success: {}", key);
	}
}
