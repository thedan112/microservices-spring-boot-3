package core.model.client.request;

import com.fasterxml.jackson.annotation.JsonProperty;

import core.mapper.SoapPrefixMapper;
import jakarta.validation.constraints.NotBlank;
import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "GetClientByNumberV2", namespace = SoapPrefixMapper.SOAP_NAMESPACE_WSIN)
public class GetClientByNumberV2Request {

	@NotBlank(message = "cannot null or empty")
	@XmlElement(name = "ClientNumber", namespace = SoapPrefixMapper.SOAP_NAMESPACE_WSIN)
	@JsonProperty(value = "clientNumber")
	private String clientNumber;
}