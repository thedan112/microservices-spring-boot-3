package core.model.client.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class GetClientByContractV2Response {

	@JsonProperty(value = "Body")
	private Body body;

	@Data
	public static class Body {
		@JsonProperty(value = "GetClientByContractV2Response")
		private GetClientByContractV2 response;
	}

	@Data
	public static class GetClientByContractV2 {
		@JsonProperty(value = "GetClientByContractV2Result")
		private GetClientByContractV2Result result;
	}

	@Data
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class GetClientByContractV2Result {
		@JsonProperty(value = "RetCode")
		private String retCode;

		@JsonProperty(value = "RetMsg")
		private String retMsg;

		@JsonProperty(value = "ResultInfo")
		private String resultInfo;

		@JsonProperty(value = "OutObject")
		private OutObject outObject;
	}

	@Data
	public static class OutObject {
		@JsonProperty(value = "IssClientDetailsV2APIRecord")
		private IssClientDetailsV2APIRecord record;
	}

	@Data
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class IssClientDetailsV2APIRecord {
		@JsonProperty(value = "Institution")
		private String institution;

		@JsonProperty(value = "ClientCategory")
		private String clientCategory;

		@JsonProperty(value = "ClientType")
		private String clientType;

		@JsonProperty(value = "Icon")
		private String icon;

		@JsonProperty(value = "Name")
		private String name;

		@JsonProperty(value = "FullName")
		private String fullName;

		@JsonProperty(value = "ShortName")
		private String shortName;

		@JsonProperty(value = "Gender")
		private String gender;

		@JsonProperty(value = "FirstName")
		private String firstName;

		@JsonProperty(value = "MiddleName")
		private String middleName;

		@JsonProperty(value = "LastName")
		private String lastName;

		@JsonProperty(value = "BirthDate")
		private String birthDate;

		@JsonProperty(value = "BirthName")
		private String birthName;

		@JsonProperty(value = "Citizenship")
		private String citizenship;

		@JsonProperty(value = "TaxBracket")
		private String taxBracket;

		@JsonProperty(value = "IndividualTaxpayerNumber")
		private String individualTaxpayerNumber;

		@JsonProperty(value = "HomePhone")
		private String homePhone;

		@JsonProperty(value = "MobilePhone")
		private String mobilePhone;

		@JsonProperty(value = "BusinessPhone")
		private String businessPhone;

		@JsonProperty(value = "EMail")
		private String eMail;

		@JsonProperty(value = "Address")
		private String address;

		@JsonProperty(value = "City")
		private String city;

		@JsonProperty(value = "AddressLine1")
		private String addressLine1;

		@JsonProperty(value = "CompanyName")
		private String companyName;

		@JsonProperty(value = "Department")
		private String department;

		@JsonProperty(value = "Profession")
		private String profession;

		@JsonProperty(value = "EmbossedLastName")
		private String embossedLastName;

		@JsonProperty(value = "EmbossedFirstName")
		private String embossedFirstName;

		@JsonProperty(value = "EmbossedCompanyName")
		private String embossedCompanyName;

		@JsonProperty(value = "IdentityCard")
		private String identityCard;

		@JsonProperty(value = "IdentityCardType")
		private String identityCardType;

		@JsonProperty(value = "IdentityCardNumber")
		private String identityCardNumber;

		@JsonProperty(value = "IdentityCardDetails")
		private String identityCardDetails;

		@JsonProperty(value = "ClientNumber")
		private String clientNumber;

		@JsonProperty(value = "SecretPhrase")
		private String secretPhrase;

		@JsonProperty(value = "SocialSecurityNumber")
		private String socialSecurityNumber;

		@JsonProperty(value = "AddDate01")
		private String addDate01;

		@JsonProperty(value = "RegistrationDate")
		private String registrationDate;

		@JsonProperty(value = "LastApplicationOfficer")
		private String lastApplicationOfficer;

		@JsonProperty(value = "LastApplicationDate")
		private String lastApplicationDate;

		@JsonProperty(value = "LastApplicationStatus")
		private String lastApplicationStatus;

		@JsonProperty(value = "Ready")
		private String ready;

		@JsonProperty(value = "AmendmentDate")
		private String amendmentDate;

		@JsonProperty(value = "amendmentOfficer")
		private String AmendmentOfficer;

		@JsonProperty(value = "ID")
		private String id;
	}
}
