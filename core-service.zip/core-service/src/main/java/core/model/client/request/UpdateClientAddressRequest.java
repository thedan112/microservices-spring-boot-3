package core.model.client.request;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import core.mapper.SoapPrefixMapper;
import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "EditClientAddressV3", namespace = SoapPrefixMapper.SOAP_NAMESPACE_WSIN)
public class UpdateClientAddressRequest {

	@XmlElement(name = "ClientSearchMethod", namespace = SoapPrefixMapper.SOAP_NAMESPACE_WSIN)
	@JsonProperty(value = "clientSearchMethod")
	private String clientSearchMethod;
	
	@XmlElement(name = "ClientIdentifier", namespace = SoapPrefixMapper.SOAP_NAMESPACE_WSIN)
	@JsonProperty(value = "clientIdentifier")
	private String clientIdentifier;
	
	@XmlElement(name = "AddressTypeCode", namespace = SoapPrefixMapper.SOAP_NAMESPACE_WSIN)
	@JsonProperty(value = "addressTypeCode")
	private String addressTypeCode;
	
	@XmlElement(name = "Reason", namespace = SoapPrefixMapper.SOAP_NAMESPACE_WSIN)
	@JsonProperty(value = "reason")
	private String reason;
	
	@XmlElement(name = "InObject", namespace = SoapPrefixMapper.SOAP_NAMESPACE_WSIN)
	@JsonProperty(value = "inObject")
	private String inObject;
	
	@Data
	@JsonIgnoreProperties(ignoreUnknown = true)
	@XmlAccessorType(XmlAccessType.FIELD)
	@XmlRootElement(name = "InObject", namespace = SoapPrefixMapper.SOAP_NAMESPACE_WSIN)
	public static class InObject {
		
		@XmlElement(name = "City", namespace = SoapPrefixMapper.SOAP_NAMESPACE_WSIN)
		@JsonProperty(value = "city")
		private String city;
		
		@XmlElement(name = "Line1", namespace = SoapPrefixMapper.SOAP_NAMESPACE_WSIN)
		@JsonProperty(value = "line1")
		private String line1;
		
		@XmlElement(name = "Line2", namespace = SoapPrefixMapper.SOAP_NAMESPACE_WSIN)
		@JsonProperty(value = "line2")
		private String line2;
		
		@XmlElement(name = "Line3", namespace = SoapPrefixMapper.SOAP_NAMESPACE_WSIN)
		@JsonProperty(value = "line3")
		private String line3;
	}
}
