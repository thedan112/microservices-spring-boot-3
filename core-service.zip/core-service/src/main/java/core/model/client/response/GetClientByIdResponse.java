package core.model.client.response;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class GetClientByIdResponse {

	@JsonProperty(value = "Body")
	private Body body;

	@Data
	public static class Body {
		@JsonProperty(value = "GetClientByIDV2Response")
		private GetClientByIDV2Response response;
	}

	@Data
	public static class GetClientByIDV2Response {
		@JsonProperty(value = "GetClientByIDV2Result")
		private GetClientByIDV2Result result;
	}

	@Data
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class GetClientByIDV2Result {
		@JsonProperty(value = "RetCode")
		private String retCode;

		@JsonProperty(value = "RetMsg")
		private String retMsg;

		@JsonIgnore
		@JsonProperty(value = "ResultInfo")
		private String resultInfo;

		@JsonProperty(value = "OutObject")
		private OutObject outObject;
	}

	@Data
	public static class OutObject {
		@JsonProperty(value = "IssClientDetailsV2APIRecord")
		private IssClientDetailsV2APIRecord record;
	}

	@Data
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class IssClientDetailsV2APIRecord {
		@JsonProperty(value = "Institution")
        private String institution;

        @JsonProperty(value = "ClientCategory")
        private String clientCategory;

        @JsonProperty(value = "ClientType")
        private String clientType;

        @JsonProperty(value = "Icon")
        private String icon;

        @JsonProperty(value = "Name")
        private String name;

        @JsonProperty(value = "FullName")
        private String fullName;

        @JsonProperty(value = "ShortName")
        private String shortName;

        @JsonProperty(value = "FirstName")
        private String firstName;

        @JsonProperty(value = "MiddleName")
        private String middleName;

        @JsonProperty(value = "LastName")
        private String lastName;

        @JsonProperty(value = "HomePhone")
        private String homePhone;

        @JsonProperty(value = "MobilePhone")
        private String mobilePhone;

        @JsonProperty(value = "BusinessPhone")
        private String businessPhone;

        @JsonProperty(value = "EmbossedLastName")
        private String embossedLastName;

        @JsonProperty(value = "EmbossedFirstName")
        private String embossedFirstName;

        @JsonProperty(value = "IdentityCard")
        private String identityCard;

        @JsonProperty(value = "IdentityCardNumber")
        private String identityCardNumber;

        @JsonProperty(value = "ClientNumber")
        private String clientNumber;

        @JsonProperty(value = "RegistrationDate")
        private String registrationDate;

        @JsonProperty(value = "LastApplicationOfficer")
        private String lastApplicationOfficer;

        @JsonProperty(value = "LastApplicationDate")
        private String lastApplicationDate;

        @JsonProperty(value = "LastApplicationStatus")
        private String lastApplicationStatus;

        @JsonProperty(value = "Ready")
        private String ready;

        @JsonProperty(value = "AmendmentDate")
        private String amendmentDate;

        @JsonProperty(value = "AmendmentOfficer")
        private String amendmentOfficer;

        @JsonProperty(value = "ID")
        private String id;
	}
}
