package core.model.client.response;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class GetClientByNumberV2Response {

	@JsonProperty(value = "Body")
	private Body body;

	@Data
	public static class Body {
		@JsonProperty(value = "GetClientByNumberV2Response")
		private GetClientByNumberV2 response;
	}

	@Data
	public static class GetClientByNumberV2 {
		@JsonProperty(value = "GetClientByNumberV2Result")
		private GetClientByNumberV2Result result;
	}

	@Data
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class GetClientByNumberV2Result {
		@JsonProperty(value = "RetCode")
		private String retCode;

		@JsonProperty(value = "RetMsg")
		private String retMsg;

		@JsonIgnore
		@JsonProperty(value = "ResultInfo")
		private String resultInfo;

		@JsonProperty(value = "OutObject")
		private OutObject outObject;
	}

	@Data
	public static class OutObject {
		@JsonProperty(value = "IssClientDetailsV2APIRecord")
		private IssClientDetailsV2APIRecord record;
	}

	@Data
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class IssClientDetailsV2APIRecord {
		@JsonProperty(value = "Institution")
		private String institution;

		@JsonProperty(value = "Branch")
		private String branch;

		@JsonProperty(value = "ClientCategory")
		private String clientCategory;

		@JsonProperty(value = "ClientType")
		private String clientType;

		@JsonProperty(value = "Icon")
		private String icon;

		@JsonProperty(value = "Name")
		private String name;

		@JsonProperty(value = "FullName")
		private String fullName;

		@JsonProperty(value = "ShortName")
		private String shortName;

		@JsonProperty(value = "Gender")
		private String gender;

		@JsonProperty(value = "BirthDate")
		private String birthDate;

		@JsonProperty(value = "Language")
		private String language;

		@JsonProperty(value = "Citizenship")
		private String citizenship;

		@JsonProperty(value = "TaxBracket")
		private String taxBracket;

		@JsonProperty(value = "HomePhone")
		private String homePhone;

		@JsonProperty(value = "EMail")
		private String eMail;

		@JsonProperty(value = "Address")
		private String address;

		@JsonProperty(value = "City")
		private String city;

		@JsonProperty(value = "AddressLine1")
		private String addressLine1;

		@JsonProperty(value = "AddressLine2")
		private String addressLine2;

		@JsonProperty(value = "CompanyName")
		private String companyName;

		@JsonProperty(value = "Department")
		private String department;
//		---
		@JsonProperty(value = "Profession")
		private String profession;

		@JsonProperty(value = "EmbossedTitle")
		private String embossedTitle;

		@JsonProperty(value = "EmbossedLastName")
		private String embossedLastName;

		@JsonProperty(value = "EmbossedFirstName")
		private String embossedFirstName;

		@JsonProperty(value = "EmbossedCompanyName")
		private String embossedCompanyName;

		@JsonProperty(value = "IdentityCard")
		private String identityCard;

		@JsonProperty(value = "IdentityCardType")
		private String identityCardType;

		@JsonProperty(value = "IdentityCardNumber")
		private String identityCardNumber;

		@JsonProperty(value = "IdentityCardDetails")
		private String identityCardDetails;

		@JsonProperty(value = "ClientNumber")
		private String clientNumber;

		@JsonProperty(value = "AddDate01")
		private String addDate01;

		@JsonProperty(value = "RegistrationDate")
		private String registrationDate;

		@JsonProperty(value = "LastApplicationOfficer")
		private String lastApplicationOfficer;

		@JsonProperty(value = "LastApplicationDate")
		private String lastApplicationDate;

		@JsonProperty(value = "LastApplicationStatus")
		private String lastApplicationStatus;

		@JsonProperty(value = "Ready")
		private String ready;

		@JsonProperty(value = "AmendmentDate")
		private String amendmentDate;

		@JsonProperty(value = "AmendmentOfficer")
		private String amendmentOfficer;

		@JsonProperty(value = "ID")
		private String id;
	}
}
