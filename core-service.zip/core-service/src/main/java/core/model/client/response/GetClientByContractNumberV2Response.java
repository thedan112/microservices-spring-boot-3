package core.model.client.response;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class GetClientByContractNumberV2Response {

	@JsonProperty(value = "Body")
	private Body body;

	@Data
	public static class Body {
		@JsonProperty(value = "GetClientByContractNumberV2Response")
		private GetClientByContractNumberV2 response;
	}

	@Data
	public static class GetClientByContractNumberV2 {
		@JsonProperty(value = "GetClientByContractNumberV2Result")
		private GetClientByContractNumberV2Result result;
	}

	@Data
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class GetClientByContractNumberV2Result {
		@JsonProperty(value = "RetCode")
		private String retCode;

		@JsonProperty(value = "RetMsg")
		private String retMsg;

		@JsonIgnore
		@JsonProperty(value = "ResultInfo")
		private String resultInfo;

		@JsonProperty(value = "OutObject")
		private OutObject outObject;
	}

	@Data
	public static class OutObject {
		@JsonProperty(value = "IssClientDetailsV2APIRecord")
		private IssClientDetailsV2APIRecord record;
	}

	@Data
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class IssClientDetailsV2APIRecord {
		@JsonProperty(value = "Institution")
		private String institution;

		@JsonProperty(value = "Branch")
		private String branch;

		@JsonProperty(value = "ClientCategory")
		private String clientCategory;

		@JsonProperty(value = "ClientType")
		private String clientType;

		@JsonProperty(value = "Icon")
		private String icon;

		@JsonProperty(value = "Name")
		private String name;

		@JsonProperty(value = "FullName")
		private String fullName;

		@JsonProperty(value = "ShortName")
		private String shortName;

		@JsonProperty(value = "MobilePhone")
		private String mobilePhone;

		@JsonProperty(value = "EmbossedTitle")
		private String embossedTitle;

		@JsonProperty(value = "EmbossedLastName")
		private String embossedLastName;

		@JsonProperty(value = "EmbossedFirstName")
		private String embossedFirstName;

		@JsonProperty(value = "IdentityCard")
		private String identityCard;

		@JsonProperty(value = "IdentityCardNumber")
		private String identityCardNumber;

		@JsonProperty(value = "ClientNumber")
		private String clientNumber;

		@JsonProperty(value = "RegistrationDate")
		private String registrationDate;

		@JsonProperty(value = "LastApplicationOfficer")
		private String lastApplicationOfficer;

		@JsonProperty(value = "LastApplicationDate")
		private String lastApplicationDate;

		@JsonProperty(value = "LastApplicationStatus")
		private String lastApplicationStatus;

		@JsonProperty(value = "Ready")
		private String ready;

		@JsonProperty(value = "AmendmentDate")
		private String amendmentDate;

		@JsonProperty(value = "AmendmentOfficer")
		private String amendmentOfficer;

		@JsonProperty(value = "ID")
		private String id;
	}
}
