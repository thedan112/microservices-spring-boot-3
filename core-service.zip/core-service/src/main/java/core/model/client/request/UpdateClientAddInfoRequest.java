package core.model.client.request;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import core.mapper.SoapPrefixMapper;
import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "EditClientV6", namespace = SoapPrefixMapper.SOAP_NAMESPACE_WSIN)
public class UpdateClientAddInfoRequest {

	@XmlElement(name = "ClientSearchMethod", namespace = SoapPrefixMapper.SOAP_NAMESPACE_WSIN)
	@JsonProperty(value = "clientSearchMethod")
	private String clientSearchMethod;

	@XmlElement(name = "ClientIdentifier", namespace = SoapPrefixMapper.SOAP_NAMESPACE_WSIN)
	@JsonProperty(value = "clientIdentifier")
	private String clientIdentifier;

	@XmlElement(name = "Reason", namespace = SoapPrefixMapper.SOAP_NAMESPACE_WSIN)
	@JsonProperty(value = "reason")
	private String reason;

	@XmlElement(name = "EditClient_InObject", namespace = SoapPrefixMapper.SOAP_NAMESPACE_WSIN)
	@JsonProperty(value = "editClientInObject")
	private EditClientInObject editClientInObject;

	@XmlElement(name = "EditClient_InObject", namespace = SoapPrefixMapper.SOAP_NAMESPACE_WSIN)
	@JsonProperty(value = "customDataInObject")
	private List<SetCustomDataInObject> customDataInObject;

	@Data
	@JsonIgnoreProperties(ignoreUnknown = true)
	@XmlAccessorType(XmlAccessType.FIELD)
	@XmlRootElement(name = "EditClient_InObject", namespace = SoapPrefixMapper.SOAP_NAMESPACE_WSIN)
	public static class EditClientInObject {
		// Example postman empty
	}

	@Data
	@JsonIgnoreProperties(ignoreUnknown = true)
	@XmlAccessorType(XmlAccessType.FIELD)
	@XmlRootElement(name = "SetCustomData_InObject", namespace = SoapPrefixMapper.SOAP_NAMESPACE_WSIN)
	public static class SetCustomDataInObject {
		@XmlElement(name = "AddInfoType", namespace = SoapPrefixMapper.SOAP_NAMESPACE_WSIN)
		@JsonProperty(value = "addInfoType")
		private String addInfoType;

		@XmlElement(name = "TagName", namespace = SoapPrefixMapper.SOAP_NAMESPACE_WSIN)
		@JsonProperty(value = "tagName")
		private String tagName;

		@XmlElement(name = "TagValue", namespace = SoapPrefixMapper.SOAP_NAMESPACE_WSIN)
		@JsonProperty(value = "tagValue")
		private String tagValue;
	}
}
