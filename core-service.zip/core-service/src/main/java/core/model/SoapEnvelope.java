package core.model;

import java.util.UUID;

import core.mapper.SoapPrefixMapper;
import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlAnyElement;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
@XmlRootElement(name = "Envelope", namespace = SoapPrefixMapper.SOAP_NAMESPACE_ENV)
@XmlAccessorType(XmlAccessType.FIELD)
public class SoapEnvelope<T> {

	@XmlElement(name = "Header", namespace = SoapPrefixMapper.SOAP_NAMESPACE_ENV)
	private SoapHeader header;

	@XmlElement(name = "Body", namespace = SoapPrefixMapper.SOAP_NAMESPACE_ENV)
	private SoapBody<T> body;

	@AllArgsConstructor
	@NoArgsConstructor
	@Builder
	@Data
	@XmlAccessorType(XmlAccessType.FIELD)
	@XmlRootElement(name = "Header")
	public static class SoapHeader {
		@XmlElement(name = "SessionContextStr", namespace = SoapPrefixMapper.SOAP_NAMESPACE_WSIN)
		private String sessionContextStr;

		@XmlElement(name = "UserInfo", namespace = SoapPrefixMapper.SOAP_NAMESPACE_WSIN)
		private String userInfo;

		@XmlElement(name = "CorrelationId", namespace = SoapPrefixMapper.SOAP_NAMESPACE_WSIN)
		private String correlationId;

		public static SoapHeader buildSoapHeader() {
			return SoapHeader.builder().correlationId(UUID.randomUUID().toString())
					.sessionContextStr(UUID.randomUUID().toString().replace("-", "").toUpperCase())
					.userInfo("officer=\"WX_ADMIN\"").build();
		}
	}

	@AllArgsConstructor
	@NoArgsConstructor
	@Data
	@XmlAccessorType(XmlAccessType.FIELD)
	@XmlRootElement(name = "Body")
	public static class SoapBody<T> {

		/**
		 * @XmlAnyElement(lax = true) cho phép JAXB đặt bất kỳ đối tượng nào vào đây.
		 *                    Tên thẻ XML sẽ được lấy từ annotation @XmlRootElement của
		 *                    đối tượng đó.
		 */
		@XmlAnyElement(lax = true)
		private T content;
	}
}
