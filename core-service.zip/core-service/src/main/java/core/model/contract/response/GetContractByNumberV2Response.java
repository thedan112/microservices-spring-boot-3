package core.model.contract.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class GetContractByNumberV2Response {

	@JsonProperty(value = "Body")
	private Body body;

	@Data
	public static class Body {
		@JsonProperty(value = "GetContractByNumberV2Response")
		private GetContractByNumberV2 response;
	}

	@Data
	public static class GetContractByNumberV2 {
		@JsonProperty(value = "GetContractByNumberV2Result")
		private GetContractByNumberV2Result result;
	}

	@Data
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class GetContractByNumberV2Result {
		@JsonProperty(value = "RetCode")
		private String retCode;

		@JsonProperty(value = "RetMsg")
		private String retMsg;

		@JsonProperty(value = "ResultInfo")
		private String resultInfo;

		@JsonProperty(value = "OutObject")
		private OutObject outObject;
	}

	@Data
	public static class OutObject {
		@JsonProperty(value = "IssContractDetailsAPIOutputV2Record")
		private IssContractDetailsAPIOutputV2Record records;
	}

	@Data
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class IssContractDetailsAPIOutputV2Record {
		@JsonProperty(value = "Institution")
		private String institution;

		@JsonProperty(value = "ClientCategory")
		private String clientCategory;

		@JsonProperty(value = "ClientType")
		private String clientType;

		@JsonProperty(value = "ProductCategory")
		private String productCategory;

		@JsonProperty(value = "RedefinedProductCategory")
		private String redefinedProductCategory;

		@JsonProperty(value = "ContractCategory")
		private String contractCategory;

		@JsonProperty(value = "ParentProduct")
		private String parentProduct;

		@JsonProperty(value = "MainProductCorrected")
		private String mainProductCorrected;

		@JsonProperty(value = "MainProductIDT")
		private String mainProductIDT;

		@JsonProperty(value = "Product")
		private String product;

		@JsonProperty(value = "ContractSubtype")
		private String contractSubtype;

		@JsonProperty(value = "ReportType")
		private String reportType;

		@JsonProperty(value = "Role")
		private String role;

		@JsonProperty(value = "Icon")
		private String icon;

		@JsonProperty(value = "Leaf")
		private String leaf;

		@JsonProperty(value = "Client")
		private String client;

		@JsonProperty(value = "ContractNumber")
		private String contractNumber;

		@JsonProperty(value = "SafeContractNumber")
		private String safeContractNumber;

		@JsonProperty(value = "ContractName")
		private String contractName;

		@JsonProperty(value = "ContractLevel")
		private String contractLevel;

		@JsonProperty(value = "ParentContract")
		private String parentContract;

		@JsonProperty(value = "BillingContract")
		private String billingContract;

		@JsonProperty(value = "TopContract")
		private String topContract;

		@JsonProperty(value = "OpenDate")
		private String openDate;

		@JsonProperty(value = "CheckUsage")
		private String checkUsage;

		@JsonProperty(value = "Currency")
		private String currency;

		@JsonProperty(value = "Available")
		private String available;

		@JsonProperty(value = "Balance")
		private String balance;

		@JsonProperty(value = "CreditLimit")
		private String creditLimit;

		@JsonProperty(value = "AddLimit")
		private String addLimit;

		@JsonProperty(value = "Blocked")
		private String blocked;

		@JsonProperty(value = "TotalDue")
		private String totalDue;

		@JsonProperty(value = "PastDue")
		private String pastDue;

		@JsonProperty(value = "ShadowAuthLimit")
		private String shadowAuthLimit;

		@JsonProperty(value = "LastBillingDate")
		private String lastBillingDate;

		@JsonProperty(value = "NextBillingDate")
		private String nextBillingDate;

		@JsonProperty(value = "AddInfo02")
		private String addInfo02;

		@JsonProperty(value = "AddParmString")
		private String addParmString;

		@JsonProperty(value = "Status")
		private String status;

		@JsonProperty(value = "StatusCode")
		private String statusCode;

		@JsonProperty(value = "ExternalCode")
		private String externalCode;

		@JsonProperty(value = "LastActivityDate")
		private String lastActivityDate;

		@JsonProperty(value = "Ready")
		private String ready;

		@JsonProperty(value = "AmendmentDate")
		private String amendmentDate;

		@JsonProperty(value = "AmendmentOfficer")
		private String amendmentOfficer;

		@JsonProperty(value = "ID")
		private String id;

		@JsonProperty(value = "ClientFullName")
		private String clientFullName;

		@JsonProperty(value = "LiabilityCategory")
		private String liabilityCategory;

		@JsonProperty(value = "LiabilityContract")
		private String liabilityContract;
	}
}
