package core.model.contract.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class GetIssuingContractTransactionsV3Response {

	@JsonProperty(value = "Body")
	private Body body;

	@Data
	public static class Body {
		@JsonProperty(value = "GetIssuingContractTransactionsV3Response")
		private GetIssuingContractTransactionsV3 response;
	}

	@Data
	public static class GetIssuingContractTransactionsV3 {
		@JsonProperty(value = "GetIssuingContractTransactionsV3Result")
		private GetIssuingContractTransactionsV3Result result;
	}

	@Data
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class GetIssuingContractTransactionsV3Result {
		@JsonProperty(value = "RetCode")
		private String retCode;

		@JsonProperty(value = "RetMsg")
		private String retMsg;
		
		@JsonProperty(value = "ResultInfo")
		private String resultInfo;

		@JsonProperty(value = "OutObject")
		private OutObject outObject;
	}

	@Data
	public static class OutObject {
		@JsonProperty(value = "IssuingContractTransactionsDetail")
		private IssuingContractTransactionsDetail record;
	}

	@Data
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class IssuingContractTransactionsDetail {
	}
}
