package core.model.contract.response;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class GetContractByClientV2Response {

	@JsonProperty(value = "body")
	private Body body;

	@Data
	public static class Body {
		@JsonProperty(value = "getContractsByClientV2Response")
		private GetContractsByClientV2 response;
	}

	@Data
	public static class GetContractsByClientV2 {
		@JsonProperty(value = "getContractsByClientV2Result")
		private GetContractsByClientV2Result result;
	}

	@Data
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class GetContractsByClientV2Result {
		@JsonProperty(value = "retCode")
		private String retCode;

		@JsonProperty(value = "retMsg")
		private String retMsg;

		@JsonIgnore
		@JsonProperty(value = "resultInfo")
		private String resultInfo;

		@JsonProperty(value = "outObject")
		private OutObject outObject;
	}

	@Data
	public static class OutObject {
		@JsonProperty(value = "issContractDetailsAPIOutputV2Record")
		private List<IssContractDetailsAPIOutputV2Record> records;
	}

	@Data
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class IssContractDetailsAPIOutputV2Record {
		@JsonProperty(value = "institution")
		private String institution;

		@JsonProperty(value = "branch")
		private String branch;

		@JsonProperty(value = "clientCategory")
		private String clientCategory;

		@JsonProperty(value = "clientType")
		private String clientType;

		@JsonProperty(value = "productCategory")
		private String productCategory;

		@JsonProperty(value = "redefinedProductCategory")
		private String redefinedProductCategory;

		@JsonProperty(value = "contractCategory")
		private String contractCategory;

		@JsonProperty(value = "relationType")
		private String relationType;
		
		@JsonProperty(value = "relationTag")
		private String relationTag;
		
		@JsonProperty(value = "lialibityCategory")
		private String lialibityCategory;
		
		@JsonProperty(value = "parentProduct")
		private String parentProduct;

		@JsonProperty(value = "mainProductCorrected")
		private String mainProductCorrected;

		@JsonProperty(value = "mainProductIDT")
		private String mainProductIDT;

		@JsonProperty(value = "product")
		private String product;

		@JsonProperty(value = "contractSubtype")
		private String contractSubtype;

		@JsonProperty(value = "ReportType")
		private String reportType;

		@JsonProperty(value = "role")
		private String role;

		@JsonProperty(value = "icon")
		private String icon;

		@JsonProperty(value = "leaf")
		private String leaf;

		@JsonProperty(value = "currency")
		private String currency;

		@JsonProperty(value = "available")
		private String available;

		@JsonProperty(value = "balance")
		private String balance;

		@JsonProperty(value = "creditLimit")
		private String creditLimit;

		@JsonProperty(value = "addLimit")
		private String addLimit;

		@JsonProperty(value = "blocked")
		private String blocked;

		@JsonProperty(value = "totalDue")
		private String totalDue;

		@JsonProperty(value = "pastDue")
		private String pastDue;

		@JsonProperty(value = "shadowAuthLimit")
		private String shadowAuthLimit;

		@JsonProperty(value = "client")
		private String client;

		@JsonProperty(value = "contractNumber")
		private String contractNumber;

		@JsonProperty(value = "safeContractNumber")
		private String safeContractNumber;

		@JsonProperty(value = "contractName")
		private String contractName;

		@JsonProperty(value = "contractLevel")
		private String contractLevel;

		@JsonProperty(value = "parentContract")
		private String ParentContract;

		@JsonProperty(value = "billingContract")
		private String billingContract;

		@JsonProperty(value = "topContract")
		private String topContract;

		@JsonProperty(value = "openDate")
		private String openDate;

		@JsonProperty(value = "checkUsage")
		private String checkUsage;

		@JsonProperty(value = "lastBillingDate")
		private String lastBillingDate;

		@JsonProperty(value = "nextBillingDate")
		private String nextBillingDate;

		@JsonProperty(value = "pastDueDays")
		private String pastDueDays;

		@JsonProperty(value = "addInfo04")
		private String addInfo04;

		@JsonProperty(value = "addParmString")
		private String addParmString;

		@JsonProperty(value = "status")
		private String status;

		@JsonProperty(value = "statusCode")
		private String statusCode;

		@JsonProperty(value = "externalCode")
		private String externalCode;

		@JsonProperty(value = "lastApplicationDate")
		private String lastApplicationDate;

		@JsonProperty(value = "lastApplicationOfficer")
		private String lastApplicationOfficer;

		@JsonProperty(value = "lastApplicationStatus")
		private String lastApplicationStatus;

		@JsonProperty(value = "lastActivityDate")
		private String lastActivityDate;

		@JsonProperty(value = "ready")
		private String ready;

		@JsonProperty(value = "amendmentDate")
		private String amendmentDate;

		@JsonProperty(value = "amendmentOfficer")
		private String amendmentOfficer;

		@JsonProperty(value = "id")
		private String id;

		@JsonProperty(value = "accountingParent")
		private String accountingParent;

		@JsonProperty(value = "clientFullName")
		private String clientFullName;

		@JsonProperty(value = "productCode")
		private String productCode;

		@JsonProperty(value = "parentProductCode")
		private String parentProductCode;

		@JsonProperty(value = "mainProductCode")
		private String mainProductCode;
	}
}
