package core.model.contract.request;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import core.constant.OneWayConstant;
import jakarta.validation.constraints.NotBlank;
import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "GetContractsByClientV2", namespace = OneWayConstant.WAY4_NAMESPACE_WSIN)
public class GetContractByClientV2Request {

	@NotBlank(message = "cannot null or empty")
	@XmlElement(name = "ClientSearchMethod", namespace = OneWayConstant.WAY4_NAMESPACE_WSIN)
	@JsonProperty(value = "clientSearchMethod")
	private String clientSearchMethod;

	@NotBlank(message = "cannot null or empty")
	@XmlElement(name = "ClientIdentifier", namespace = OneWayConstant.WAY4_NAMESPACE_WSIN)
	@JsonProperty(value = "clientIdentifier")
	private String clientIdentifier;

	@XmlElement(name = "ClientScope", namespace = OneWayConstant.WAY4_NAMESPACE_WSIN)
	@JsonProperty(value = "clientScope")
	private String clientScope;

	@XmlElement(name = "ClientSearchType", namespace = OneWayConstant.WAY4_NAMESPACE_WSIN)
	@JsonProperty(value = "clientSearchType")
	private String clientSearchType;

	@XmlElement(name = "ClientSearchCategory", namespace = OneWayConstant.WAY4_NAMESPACE_WSIN)
	@JsonProperty(value = "clientSearchCategory")
	private String clientSearchCategory;

	@XmlElement(name = "ContractRelation", namespace = OneWayConstant.WAY4_NAMESPACE_WSIN)
	@JsonProperty(value = "contractRelation")
	private String contractRelation;

	@XmlElement(name = "IncludeSupplementry", namespace = OneWayConstant.WAY4_NAMESPACE_WSIN)
	@JsonProperty(value = "includeSupplementry")
	private String includeSupplementry;
}
