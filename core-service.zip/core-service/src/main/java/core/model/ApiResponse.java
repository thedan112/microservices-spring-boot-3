package core.model;

import java.time.LocalDateTime;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonIgnore;

import core.enums.StatusCode;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ApiResponse<T> {

	private String code;
	private String message;
	private LocalDateTime timestamp;
	private T data;
	
	@JsonIgnore(value = true)
	public Boolean isError() {
		if (this.code != StatusCode.SUCCESS.getStatus())
			return true;
		return false;
	}
	
	public static <T> ApiResponse<T> success(T data) {
		return new ApiResponse<T>(StatusCode.SUCCESS.getStatus(), StatusCode.SUCCESS.getMessage(), LocalDateTime.now(), data);
	}

	public static <T> ApiResponse<T> success(String code, String message, T data) {
		return new ApiResponse<T>(code, message, LocalDateTime.now(), data);
	}

	public static <T> ApiResponse<T> success(String message, T data) {
		return new ApiResponse<T>(StatusCode.SUCCESS.getStatus(), message, LocalDateTime.now(), data);
	}

	public static <T> ApiResponse<T> error(StatusCode asc) {
		return new ApiResponse<T>(asc.getStatus(), asc.getMessage(), LocalDateTime.now(), null);
	}
	
	public static <T> ApiResponse<T> error(String code, String message) {
		return new ApiResponse<T>(code, message, LocalDateTime.now(), null);
	}
	
	public static <T> ApiResponse<T> error(String code, String message, T data) {
		return new ApiResponse<T>(code, message, LocalDateTime.now(), data);
	}
	
	public static <T> ApiResponse<T> internalError() {
		return new ApiResponse<T>(StatusCode.INTERNAL_ERROR.getStatus(), StatusCode.INTERNAL_ERROR.getMessage(), LocalDateTime.now(), null);
	}
	
	public static <T> Map<String, Object> accessDenined(String path){
		Map<String, Object> errors = new HashMap<>();
		errors.put("status", 403);
		errors.put("message", StatusCode.FORBIDEN.toString());
		errors.put("timestamp", new Date());
		errors.put("path", path);
		return errors;
	}
}