package core.model.card.request;

import com.fasterxml.jackson.annotation.JsonProperty;

import core.mapper.SoapPrefixMapper;
import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "GetCardByID", namespace = SoapPrefixMapper.SOAP_NAMESPACE_WSIN)
public class GetCardByIdRequest {

	@XmlElement(name = "ID", namespace = SoapPrefixMapper.SOAP_NAMESPACE_WSIN)
	@JsonProperty(value = "id")
	private String id;
}
