package core.model.card.request;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import core.mapper.SoapPrefixMapper;
import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "SetPinV2", namespace = SoapPrefixMapper.SOAP_NAMESPACE_WSIN)
public class SetPINRequest {

	@XmlElement(name = "ContractSearchMethod", namespace = SoapPrefixMapper.SOAP_NAMESPACE_WSIN)
	@JsonProperty(value = "contractSearchMethod")
	private String contractSearchMethod;
	
	@XmlElement(name = "ContractIdentifier", namespace = SoapPrefixMapper.SOAP_NAMESPACE_WSIN)
	@JsonProperty(value = "contractIdentifier")
	private String contractIdentifier;
	
	@XmlElement(name = "SourceContractNumber", namespace = SoapPrefixMapper.SOAP_NAMESPACE_WSIN)
	@JsonProperty(value = "sourceContractNumber")
	private String sourceContractNumber;
	
	@XmlElement(name = "OverrideOldPIN", namespace = SoapPrefixMapper.SOAP_NAMESPACE_WSIN)
	@JsonProperty(value = "overrideOldPIN")
	private String overrideOldPIN;
	
	@XmlElement(name = "NewPinBlock", namespace = SoapPrefixMapper.SOAP_NAMESPACE_WSIN)
	@JsonProperty(value = "newPinBlock")
	private String newPinBlock;
	
	@XmlElement(name = "CardExpirationDate", namespace = SoapPrefixMapper.SOAP_NAMESPACE_WSIN)
	@JsonProperty(value = "cardExpirationDate")
	private String cardExpirationDate;
}
