package core.model.card.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class GetCardByNumberResponse {

	@JsonProperty(value = "Body")
	private Body body;

	@Data
	public static class Body {
		@JsonProperty(value = "GetCardByNumberResponse")
		private GetCardByNumber response;
	}

	@Data
	public static class GetCardByNumber {
		@JsonProperty(value = "GetCardByNumberResult")
		private GetCardByNumberResult result;
	}

	@Data
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class GetCardByNumberResult {
		@JsonProperty(value = "RetCode")
		private String retCode;

		@JsonProperty(value = "RetMsg")
		private String retMsg;
		
		@JsonProperty(value = "ResultInfo")
		private String resultInfo;

		@JsonProperty(value = "OutObject")
		private OutObject outObject;
	}

	@Data
	public static class OutObject {
		@JsonProperty(value = "CardDetailsAPIRecord")
		private CardDetailsAPIRecord record;
	}

	@Data
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class CardDetailsAPIRecord {
		@JsonProperty(value = "Institution")
		private String institution;

		@JsonProperty(value = "ProductCategory")
		private String productCategory;

		@JsonProperty(value = "ContractCategory")
		private String contractCategory;

		@JsonProperty(value = "ParentProduct")
		private String parentProduct;

		@JsonProperty(value = "CounterpartChannel")
		private String counterpartChannel;

		@JsonProperty(value = "CardNumber")
		private String cardNumber;

		@JsonProperty(value = "CardName")
		private String cardName;

		@JsonProperty(value = "Product")
		private String product;

		@JsonProperty(value = "DateOpen")
		private String dateOpen;

		@JsonProperty(value = "ExpirationDate")
		private String expirationDate;

		@JsonProperty(value = "Available")
		private String available;

		@JsonProperty(value = "Currency")
		private String currency;

		@JsonProperty(value = "Blocked")
		private String blocked;

		@JsonProperty(value = "CreditLimit")
		private String creditLimit;

		@JsonProperty(value = "AddLimit")
		private String addLimit;

		@JsonProperty(value = "SequenceNumber")
		private String sequenceNumber;

		@JsonProperty(value = "OrderReason")
		private String orderReason;

		@JsonProperty(value = "AvailableProductionAction")
		private String availableProductionAction;

		@JsonProperty(value = "ProductCode")
		private String productCode;

		@JsonProperty(value = "ParentProductCode")
		private String parentProductCode;

		@JsonProperty(value = "MaxPinAttempts")
		private String maxPinAttempts;

		@JsonProperty(value = "PinAttemptsCounter")
		private String pinAttemptsCounter;

		@JsonProperty(value = "RiskFactor")
		private String riskFactor;

		@JsonProperty(value = "EmbossedFirstName")
		private String embossedFirstName;

		@JsonProperty(value = "EmbossedLastName")
		private String embossedLastName;

		@JsonProperty(value = "CustomRules")
		private String customRules;

		@JsonProperty(value = "Status")
		private String status;

		@JsonProperty(value = "StatusCode")
		private String statusCode;

		@JsonProperty(value = "ProductionStatus")
		private String productionStatus;

		@JsonProperty(value = "Ready")
		private String ready;

		@JsonProperty(value = "ExternalCode")
		private String externalCode;

		@JsonProperty(value = "ID")
		private String id;

		@JsonProperty(value = "AmendmentDate")
		private String amendmentDate;

		@JsonProperty(value = "Client")
		private String client;

		@JsonProperty(value = "Parent")
		private String parent;

		@JsonProperty(value = "ServPack")
		private String servPack;

		@JsonProperty(value = "AmendmentOfficer")
		private String amendmentOfficer;
	}
}
