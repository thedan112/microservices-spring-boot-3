package core.model.transaction.request;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import core.constant.OneWayConstant;
import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "GetInstalmentPlansByContract", namespace = OneWayConstant.WAY4_NAMESPACE_WSIN)
public class GetInstallmentPlansByContractRequest {

	@XmlElement(name = "ContractSearchMethod", namespace = OneWayConstant.WAY4_NAMESPACE_WSIN)
	@JsonProperty(value = "contractSearchMethod")
	private String contractSearchMethod;
	
	@XmlElement(name = "ContractIdentifier", namespace = OneWayConstant.WAY4_NAMESPACE_WSIN)
	@JsonProperty(value = "contractIdentifier")
	private String contractIdentifier;
}
