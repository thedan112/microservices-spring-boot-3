package core.model.transaction.request;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import core.constant.OneWayConstant;
import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "IssPaymentToContract", namespace = OneWayConstant.WAY4_NAMESPACE_WSIN)
public class PaymentIssueRequest {

	@XmlElement(name = "MsgCode", namespace = OneWayConstant.WAY4_NAMESPACE_WSIN)
	@JsonProperty(value = "msgCode")
	private String msgCode;
	
	@XmlElement(name = "RRN", namespace = OneWayConstant.WAY4_NAMESPACE_WSIN)
	@JsonProperty(value = "rrn")
	private String rrn;
	
	@XmlElement(name = "SRN", namespace = OneWayConstant.WAY4_NAMESPACE_WSIN)
	@JsonProperty(value = "srn")
	private String srn;
	
	@XmlElement(name = "ContractSearchMethod", namespace = OneWayConstant.WAY4_NAMESPACE_WSIN)
	@JsonProperty(value = "contractSearchMethod")
	private String contractSearchMethod;
	
	@XmlElement(name = "ContractIdentifier", namespace = OneWayConstant.WAY4_NAMESPACE_WSIN)
	@JsonProperty(value = "contractIdentifier")
	private String contractIdentifier;
	
	@XmlElement(name = "SourceMemberID", namespace = OneWayConstant.WAY4_NAMESPACE_WSIN)
	@JsonProperty(value = "sourceMemberID")
	private String sourceMemberID;
	
	@XmlElement(name = "SourceContractNumber", namespace = OneWayConstant.WAY4_NAMESPACE_WSIN)
	@JsonProperty(value = "sourceContractNumber")
	private String sourceContractNumber;
	
	@XmlElement(name = "Amount", namespace = OneWayConstant.WAY4_NAMESPACE_WSIN)
	@JsonProperty(value = "amount")
	private String amount;
	
	@XmlElement(name = "Currency", namespace = OneWayConstant.WAY4_NAMESPACE_WSIN)
	@JsonProperty(value = "currency")
	private String currency;
}

