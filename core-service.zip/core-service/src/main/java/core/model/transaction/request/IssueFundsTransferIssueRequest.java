package core.model.transaction.request;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import core.constant.OneWayConstant;
import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "IssFundsTransfer", namespace = OneWayConstant.WAY4_NAMESPACE_WSIN)
public class IssueFundsTransferIssueRequest {

	@XmlElement(name = "MsgCode", namespace = OneWayConstant.WAY4_NAMESPACE_WSIN)
	@JsonProperty(value = "msgCode")
	private String msgCode;
	
	@XmlElement(name = "PayerContractSearchMethod", namespace = OneWayConstant.WAY4_NAMESPACE_WSIN)
	@JsonProperty(value = "payerContractSearchMethod")
	private String payerContractSearchMethod;
	
	@XmlElement(name = "PayerContractIdentifier", namespace = OneWayConstant.WAY4_NAMESPACE_WSIN)
	@JsonProperty(value = "payerContractIdentifier")
	private String payerContractIdentifier;
	
	@XmlElement(name = "PayeeContractSearchMethod", namespace = OneWayConstant.WAY4_NAMESPACE_WSIN)
	@JsonProperty(value = "payeeContractSearchMethod")
	private String payeeContractSearchMethod;
	
	@XmlElement(name = "PayeeContractIdentifier", namespace = OneWayConstant.WAY4_NAMESPACE_WSIN)
	@JsonProperty(value = "payeeContractIdentifier")
	private String payeeContractIdentifier;
	
	@XmlElement(name = "Amount", namespace = OneWayConstant.WAY4_NAMESPACE_WSIN)
	@JsonProperty(value = "amount")
	private String amount;
	
	@XmlElement(name = "Currency", namespace = OneWayConstant.WAY4_NAMESPACE_WSIN)
	@JsonProperty(value = "currency")
	private String currency;
}
