package core.model.transaction.response;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class GetDocsByContractV2Response {

	@JsonProperty(value = "Body")
	private Body body;

	@Data
	public static class Body {
		@JsonProperty(value = "GetDocsByContractV2Response")
		private GetDocsByContractV2 response;
	}

	@Data
	public static class GetDocsByContractV2 {
		@JsonProperty(value = "GetDocsByContractV2Result")
		private GetDocsByContractV2Result result;
	}

	@Data
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class GetDocsByContractV2Result {
		@JsonProperty(value = "RetCode")
		private String retCode;

		@JsonProperty(value = "RetMsg")
		private String retMsg;

		@JsonProperty(value = "ResultInfo")
		private String resultInfo;

		@JsonProperty(value = "OutObject")
		private OutObject outObject;
	}

	@Data
	public static class OutObject {
		@JsonProperty(value = "GenericDocDetailsV2APIRecord")
		private List<GenericDocDetailsV2APIRecord> records;
	}

	@Data
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class GenericDocDetailsV2APIRecord {
		@JsonProperty(value = "ServiceClass")
		private String serviceClass;

		@JsonProperty(value = "DocCategory")
		private String docCategory;

		@JsonProperty(value = "RequestCategory")
		private String requestCategory;

		@JsonProperty(value = "SourceCategory")
		private String sourceCategory;

		@JsonProperty(value = "TargetCategory")
		private String targetCategory;

		@JsonProperty(value = "TransType")
		private String transType;

		@JsonProperty(value = "Direction")
		private String direction;

		@JsonProperty(value = "TransTypeCode")
		private String transTypeCode;

		@JsonProperty(value = "TransCode")
		private String transCode;

		@JsonProperty(value = "SourceChannel")
		private String sourceChannel;

		@JsonProperty(value = "SourceIDTScheme")
		private String sourceIDTScheme;

		@JsonProperty(value = "SourceMemberID")
		private String sourceMemberID;

		@JsonProperty(value = "SourceNumber")
		private String sourceNumber;

		@JsonProperty(value = "SourceContract")
		private String sourceContract;

		@JsonProperty(value = "TargetChannel")
		private String targetChannel;

		@JsonProperty(value = "TargetIDTScheme")
		private String targetIDTScheme;

		@JsonProperty(value = "TargetNumber")
		private String targetNumber;

		@JsonProperty(value = "TargetContract")
		private String targetContract;

		@JsonProperty(value = "TransDate")
		private String transDate;

		@JsonProperty(value = "SettlDate")
		private String settlDate;

		@JsonProperty(value = "PSRefDate")
		private String psRefDate;

		@JsonProperty(value = "TransAmount")
		private String transAmount;

		@JsonProperty(value = "TransCurr")
		private String transCurr;

		@JsonProperty(value = "SettlAmount")
		private String settlAmount;

		@JsonProperty(value = "SettlCurr")
		private String settlCurr;

		@JsonProperty(value = "ReconcAmount")
		private String reconcAmount;

		@JsonProperty(value = "ReconcCurr")
		private String reconcCurr;

		@JsonProperty(value = "SourceFeeAmount")
		private String sourceFeeAmount;

		@JsonProperty(value = "TargetFeeAmount")
		private String targetFeeAmount;

		@JsonProperty(value = "TransDetails")
		private String transDetails;

		@JsonProperty(value = "City")
		private String city;

		@JsonProperty(value = "Merchant")
		private String merchant;

		@JsonProperty(value = "MCC")
		private String mcc;

		@JsonProperty(value = "AuthCode")
		private String athCode;

		@JsonProperty(value = "RetRefNumber")
		private String retRefNumber;

		@JsonProperty(value = "SourceRegNum")
		private String sourceRegNum;

		@JsonProperty(value = "AddInfo")
		private String addInfo;

		@JsonProperty(value = "AncillaryCharges")
		private String ancillaryCharges;

		@JsonProperty(value = "ResponseCode")
		private String responseCode;

		@JsonProperty(value = "PostingStatus")
		private String postingStatus;

		@JsonProperty(value = "OutwardStatus")
		private String outwardStatus;

		@JsonProperty(value = "ID")
		private String id;

		@JsonProperty(value = "AmendmentDate")
		private String amendmentDate;

		@JsonProperty(value = "AmendmentOfficer")
		private String amendmentOfficer;

		@JsonProperty(value = "OriginalDoc")
		private String originalDoc;

		@JsonProperty(value = "PrevDoc")
		private String prevDoc;
	}
}
