package core.filter;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import core.config.AuthorityConfig;
import core.dto.GrantedAuthorityDto;
import core.dto.UserDetailDto;

@Service
public class JwtUserDetailService implements UserDetailsService {
	private static final BCryptPasswordEncoder PASSWORD_ENCODER = new BCryptPasswordEncoder();

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		String clientSecret = AuthorityConfig.getClientSecretByKey(username);
		if (clientSecret == null || clientSecret == "")
			throw new UsernameNotFoundException("clientId [" + username + "] not found");
		Set<String> scopes = new HashSet<>();
		List<String> roles = AuthorityConfig.getRolesByClient(username);
		if (!CollectionUtils.isEmpty(roles)) 
			scopes = roles.stream().flatMap(role -> AuthorityConfig.getScopesByRole(role).stream())
					.map(String::new)
					.collect(Collectors.toSet());
		GrantedAuthorityDto authority = new GrantedAuthorityDto(roles, scopes);
		return new UserDetailDto(username, PASSWORD_ENCODER.encode(clientSecret), authority);
	}
}
