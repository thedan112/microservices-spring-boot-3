package core.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(value = HttpStatus.BAD_REQUEST)
public class MissingPathVariableException extends RuntimeException {
	private static final long serialVersionUID = -2238371993130411674L;

	private String pathVariable;

	public MissingPathVariableException(String pathVariable) {
		this.pathVariable = pathVariable;
	}

	public String getPathVariable() {
		return pathVariable;
	}

	public void setPathVariable(String pathVariable) {
		this.pathVariable = pathVariable;
	}
}
