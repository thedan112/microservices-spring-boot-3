package core.exception;

public class ExecuteWebServiceException extends RuntimeException {
	private static final long serialVersionUID = 7816373728236219854L;

	private String httpStatusCode;
	private String body;
	private String uri;

	public ExecuteWebServiceException(String httpStatusCode, String body, String uri) {
		this.httpStatusCode = httpStatusCode;
		this.body = body;
		this.uri = uri;
	}

	public String getHttpStatusCode() {
		return httpStatusCode;
	}

	public void setHttpStatusCode(String httpStatusCode) {
		this.httpStatusCode = httpStatusCode;
	}

	public String getBody() {
		return body;
	}

	public void setBody(String body) {
		this.body = body;
	}

	public String getUri() {
		return uri;
	}

	public void setMessage(String uri) {
		this.uri = uri;
	}
}
