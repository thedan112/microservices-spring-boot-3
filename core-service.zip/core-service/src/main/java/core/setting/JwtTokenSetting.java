package core.setting;

import org.springframework.context.annotation.Configuration;

import lombok.Data;

@Configuration
@Data
public class JwtTokenSetting {

	private String partnerId;
	private String partnerSecret;
}
