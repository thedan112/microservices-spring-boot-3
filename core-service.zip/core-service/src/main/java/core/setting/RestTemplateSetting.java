package core.setting;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.ws.transport.http.HttpComponentsMessageSender;

import lombok.Data;

@Data
@Configuration
@ConfigurationProperties(prefix = "rest-template")
public class RestTemplateSetting {

	private int connectionTimeout;
	private int readTimeout;

	public HttpComponentsMessageSender httpComponentsMessageSender(Integer secondsTimeout) {
		HttpComponentsMessageSender sender = new HttpComponentsMessageSender();
		sender.setConnectionTimeout(connectionTimeout);
		if (secondsTimeout == null) {
			sender.setReadTimeout(readTimeout); // default
		} else {
			sender.setReadTimeout(secondsTimeout * 1000);
		}
		return sender;
	}
}
