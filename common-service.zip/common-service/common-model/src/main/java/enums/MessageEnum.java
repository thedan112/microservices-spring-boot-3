package enums;

public enum MessageEnum {

	SUCCESS("000000", "Success"),
	INTERNAL_SERVER_ERROR("000001", "Internal Server Error"),
	;

	private String code;
	private String message;

	MessageEnum(String code, String message) {
		this.code = code;
		this.message = message;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
}
