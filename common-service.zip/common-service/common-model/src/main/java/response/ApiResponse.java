package response;

import java.time.LocalDateTime;

import enums.MessageEnum;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ApiResponse<T> {

	private String code;
	private String message;
	private LocalDateTime timestamp;
	private T data;

	public static <T> ApiResponse<T> success(T data) {
		return new ApiResponse<T>(MessageEnum.SUCCESS.getCode(), MessageEnum.SUCCESS.getMessage(), LocalDateTime.now(),
				data);
	}

	public static <T> ApiResponse<T> success(String code, String message, T data) {
		return new ApiResponse<T>(code, message, LocalDateTime.now(), data);
	}

	public static <T> ApiResponse<T> error(String code, String message, T data) {
		return new ApiResponse<T>(code, message, LocalDateTime.now(), data);
	}
}